// fruit_slice_game.h

#ifndef FRUIT_SLICE_GAME_H
#define FRUIT_SLICE_GAME_H

// Include the necessary external headers used for types/macros
// #include "pt_cornell_rp2040_v1_4.h" // For PT_THREAD struct pt
#include "vga16_graphics_v2.h"    // For drawPixel, drawEllipse, fillRect, and color constants
#include "mpu6050.h"

// ===============================
// ===== FIXED-POINT DEFINITIONS =====
// ===============================

// 16-bit signed fixed-point type with 15 bits for the fractional part
// typedef signed int fix15;

// // Fixed-point conversion/math macros
// #define multfix15(a, b) ((fix15)((((signed long long)(a)) * ((signed long long)(b))) >> 15))
// #define float2fix15(a) ((fix15)((a) * 32768.0))
// #define fix2int15(a) ((int)(a >> 15))
// #define int2fix15(a) ((fix15)(a << 15))

// ===============================
// ===== CONSTANTS AND MACROS =====
// ===============================

#define FRAME_RATE 33000 // Target frame duration in microseconds
#define HIT_BOTTOM(b) (b > int2fix15(430)) // Screen boundary for fruit to go inactive (y > 430)
#define MAX_POPUPS 8

// Global gravity constant (extern if needed in other files, otherwise static const/local)
extern fix15 gravity; // Declared as extern to match the usage in your C file

// Slice trigger flags (extern since they are volatile global state)
extern volatile int force_slice_vertical;
extern volatile int force_slice_horizontal;
extern volatile int force_slice_diag_slash;     // '/' -> top-left + bottom-right
extern volatile int force_slice_diag_backslash; // '\' -> top-right + bottom-left

extern int num_fruit_sliced;
extern int score;

extern int lastFruitType;
extern int comboCount;

typedef struct {
    fix15 x, y;
    fix15 prior_x, prior_y;
    fix15 vx, vy;
    int type;      // 0 apple, 1 watermelon, 2 orange, 3 blueberry
    int sliced;    // 0 whole, 1 is half
    int half_id;   // 0 left, 1 right, 2 top, 3 bottom, 4 diagSlashA, 5 diagSlashB, 6 diagBackslashA, 7 diagBackslashB
    fix15 theta;   // rotation angle
    fix15 omega;   // angular velocity
    int active;    // 1 on screen, 0 offscreen
} Boid;

typedef struct
{
  int active;
  int points;
  int x, y;
  int life; // frames remaining
} ScorePopup;


extern Boid boid_main;
extern Boid boid_halfL;
extern Boid boid_halfR;
extern Boid boid_halfTop;
extern Boid boid_halfBottom;
extern Boid boid_halfDiagA;
extern Boid boid_halfDiagB;
extern Boid boid_extra1;
extern Boid boid_extra2;
extern Boid boid_extra3;

// Fixed-Point Math
fix15 fix_sin(fix15 a);
fix15 fix_cos(fix15 a);

// Drawing Primitives (only those not from vga16_graphics_v2.h)
void drawStats();
void drawEllipse(short x0, short y0, short rx, short ry, char color);
static inline void drawRotatedPixel(short cx, short cy, short dx, short dy, fix15 theta, unsigned char color);
static inline void eraseRotatedPixel(short cx, short cy, short dx, short dy, fix15 theta);

// Original Fruit Drawing
void drawApple(short x0, short y0);
void drawWatermelon(short x0, short y0);
void drawOrange(short x0, short y0);
void drawBlueberry(short x0, short y0);

// Sliced Fruit Drawing (Prototypes for all half drawing functions)
// Vertical halves
void drawAppleHalfLeft(short x0, short y0, fix15 th);
void drawAppleHalfRight(short x0, short y0, fix15 th);
void drawWatermelonHalfLeft(short x0, short y0, fix15 t);
void drawWatermelonHalfRight(short x0, short y0, fix15 t);
void drawOrangeHalfLeft(short x0, short y0, fix15 t);
void drawOrangeHalfRight(short x0, short y0, fix15 t);
void drawBlueberryHalfLeft(short x0, short y0, fix15 t);
void drawBlueberryHalfRight(short x0, short y0, fix15 t);
// Horizontal halves
void drawAppleHalfTop(short x0, short y0, fix15 th);
void drawAppleHalfBottom(short x0, short y0, fix15 th);
void drawWatermelonHalfTop(short x0, short y0, fix15 t);
void drawWatermelonHalfBottom(short x0, short y0, fix15 t);
void drawOrangeHalfTop(short x0, short y0, fix15 t);
void drawOrangeHalfBottom(short x0, short y0, fix15 t);
void drawBlueberryHalfTop(short x0, short y0, fix15 t);
void drawBlueberryHalfBottom(short x0, short y0, fix15 t);
// Diagonal halves (slash)
void drawAppleHalfDiagSlashA(short x0, short y0, fix15 th);
void drawAppleHalfDiagSlashB(short x0, short y0, fix15 th);
void drawWatermelonHalfDiagSlashA(short x0, short y0, fix15 t);
void drawWatermelonHalfDiagSlashB(short x0, short y0, fix15 t);
void drawOrangeHalfDiagSlashA(short x0, short y0, fix15 t);
void drawOrangeHalfDiagSlashB(short x0, short y0, fix15 t);
void drawBlueberryHalfDiagSlashA(short x0, short y0, fix15 t);
void drawBlueberryHalfDiagSlashB(short x0, short y0, fix15 t);
// Diagonal halves (backslash)
void drawAppleHalfDiagBackslashA(short x0, short y0, fix15 th);
void drawAppleHalfDiagBackslashB(short x0, short y0, fix15 th);
void drawWatermelonHalfDiagBackslashA(short x0, short y0, fix15 t);
void drawWatermelonHalfDiagBackslashB(short x0, short y0, fix15 t);
void drawOrangeHalfDiagBackslashA(short x0, short y0, fix15 t);
void drawOrangeHalfDiagBackslashB(short x0, short y0, fix15 t);
void drawBlueberryHalfDiagBackslashA(short x0, short y0, fix15 t);
void drawBlueberryHalfDiagBackslashB(short x0, short y0, fix15 t);

// Erase / Draw Routines
void eraseBigSquare(short x0, short y0);
void eraseBoid(Boid *b);
void drawBoid(Boid *b);

// Spawn / Update Logic
void spawnMainFruit(Boid *b);
void spawnHalvesVertical();
void spawnHalvesHorizontal();
void spawnHalvesDiagSlash();
void spawnHalvesDiagBackslash();
void updateBoid(Boid *b);

void addPopup(int x, int y, int pts);
void addComboPopup(int x, int y);
void updatePopups();
void drawPopups();
int getFruitPoints(int type);
int getComboBonus(int comboCount);

void drawInstructions();
void drawCombos();

void spawnRandomPattern();
void initFruit(Boid *b, int x, int y);
void spawnTripleSimultaneous();
void spawnTripleConsecutive();
void spawnTripleDiagonal();

#endif // FRUIT_SLICE_GAME_H