/// * RP2040 PINOUT CONFIGURATIONS
// * KEYPAD CONNECTIONS
// * - GPIO 9   -->  330 ohms  --> Pin 12 (button row 1)
// * - GPIO 10  -->  330 ohms  --> Pin 14 (button row 2)
// * - GPIO 11  -->  330 ohms  --> Pin 15 (button row 3)
// * - GPIO 12  -->  330 ohms  --> Pin 16 (button row 4)
// * - GPIO 13  -->    Pin 17 (button col 1)
// * - GPIO 14  -->    Pin 19 (button col 2)
// * - GPIO 15  -->    Pin 20 (button col 3)
// *
// * VGA CONNECTIONS
// * - GPIO 16 --> VGA Hsync --> Pin 21
// * - GPIO 17 --> VGA Vsync --> Pin 22
// * - RP2040 GND ---> VGA GND --> Pin 23
// * - GPIO 18 --> 470 ohm resistor --> VGA Green --> Pin 24
// * - GPIO 19 --> 330 ohm resistor --> VGA Green --> Pin 25
// * - GPIO 20 --> 330 ohm resistor --> VGA Blue --> Pin 26
// * - GPIO 21 --> 330 ohm resistor --> VGA Red --> Pin 27
// *
// * SERIAL CONNECTIONS
// * - GPIO 0 --> UART RX (white) --> Pin 1
// * - GPIO 1 --> UART TX (green) --> Pin 2
// * - RP2040 GND --> UART GND --> Pin 3
// *
// * PWM CONNECTIONS
// * - GPIO 2 --> Pin 4
// * - GPIO 3 --> Pin 5
// * - GPIO 6 --> Pin 9
// * - GPIO 7 --> Pin 10
// *
// * IMU CONNECTIONS
// * - GPIO 4 --> MPU6050 SDA --> Pin 6
// * - GPIO 5 --> MPU6050 SCL --> Pin 7
// * - GPIO 26 --> MPU6050 VCC --> Pin 36
// * - RP2040 GND --> MPU6050 GND --> Pin 38

// GPIO 27, 28 for internal PWM -> timing

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>

#include "pico/stdlib.h"
#include "pico/divider.h"
#include "pico/multicore.h"

#include "hardware/pwm.h"
#include "hardware/pio.h"
#include "hardware/dma.h"
#include "hardware/irq.h"
#include "hardware/adc.h"
#include "hardware/sync.h"
#include "hardware/pll.h"
#include "hardware/clocks.h"
#include "hardware/i2c.h"

// VGA graphics library
#include "mpu6050.h"
#include "pt_cornell_rp2040_v1_4.h"

// Image arrays
#include "logo.h"
#include "move1.h"
#include "move2.h"
#include "move3.h"
#include "drawfruits.h"

// Keypad pin configurations
#define BASE_KEYPAD_PIN 9
#define KEYROWS 4
#define NUMKEYS 12
#define LED 25
#define SWITCH_PIN 22 // from imu code
#define IMU_POWER_PIN 26

// GPIO we're using for PWM
#define PWM_TL 2 // A
#define PWM_BL 3 // B
#define PWM_TR 6 // A
#define PWM_BR 7 // B

// timing
uint32_t last_time_us = 0;
uint32_t current_time_us = 0;

// Variable to hold PWM slice number
uint slice_num_TL;
uint slice_num_BL;
uint slice_num_TR;
uint slice_num_BR;
uint slice_num;

// PWM duty cycle
volatile int control_TL = 0;
volatile int control_BL = 0;
volatile int control_TR = 0;
volatile int control_BR = 0;

volatile int old_control_TL;
volatile int old_control_BL;
volatile int old_control_TR;
volatile int old_control_BR;

// Arrays in which raw measurements will be stored
fix15 acceleration[3], gyro[3];

// Character array
char screentext[40];

// fix15 gravity = 0; // MUST BE DEFINED ONCE
fix15 gravity = float2fix15(0.75);

// Fruit Ninja Gameplay globals
volatile int force_slice_vertical = 0;
volatile int force_slice_horizontal = 0;
volatile int force_slice_diag_slash = 0;
volatile int force_slice_diag_backslash = 0;
int num_fruit_sliced = 0;
int score = 0;
int lastFruitType = -1;
int comboCount = 0;
int slice_type;

// Boid definition for graphics generation
Boid boid_main;
Boid boid_halfL;
Boid boid_halfR;
Boid boid_halfTop;
Boid boid_halfBottom;
Boid boid_halfDiagA;
Boid boid_halfDiagB;

// Draw speed (from IMU code)
int threshold = 10;
int stats_idx;

// Some macros for max/min/abs
#define min(a, b) ((a < b) ? a : b)
#define max(a, b) ((a < b) ? b : a)
#define abs(a) ((a > 0) ? a : -a)

// Semaphore -> VGA creation
static struct pt_sem vga_semaphore;

// Some paramters for PWM
#define WRAPVAL 5000
#define CLKDIV 25.0

#define PI 3.14159265358979323846

// state estimation for complementary angles
fix15 accel_angle_x;
fix15 accel_angle_y;
fix15 accel_angle_z;

fix15 complementary_angle_x = 0;
fix15 complementary_angle_y = 0;
fix15 complementary_angle_z = 0;

fix15 prev_complementary_angle_x = 0;
fix15 prev_complementary_angle_y = 0;
fix15 prev_complementary_angle_z = 0;

float complementary_angle_delta_x = 0;
float complementary_angle_delta_y = 0;
float complementary_angle_delta_z = 0;

fix15 filtered_ax;
fix15 filtered_ay;
fix15 filtered_az;

fix15 gyro_angle_delta_x;
fix15 gyro_angle_delta_y;
fix15 gyro_angle_delta_z;

// Training global vars
uint32_t time_ms_t = 0;
uint32_t last_time_ms_t = 0;
int max_deg_s = 1500; // human limit
int max_vibe = 5000; // limit of pwm to haptic motors

// handle timing with nulcear_reset
int ms_elapsed = 0;
bool nuclear_resetting = false;

unsigned int keycodes[12] = {0x28, 0x11, 0x21, 0x41, 0x12,
                             0x22, 0x42, 0x14, 0x24, 0x44,
                             0x18, 0x48};
unsigned int scancodes[4] = {0x01, 0x02, 0x04, 0x08};
unsigned int button = 0x70;

char keytext[40];
int prev_key = 0;

static int last_stable_key = -1;
volatile int menu_key = -1;

// noise handling variables
// when set below to 5 it breaks bc perma rst
#define STALL_LIMIT 20 // If data corrupted for x interrupts -> RESET
static int stall_counter = 0;
static fix15 last_accel_x = 0;

void nuclear_reset()
{
    nuclear_resetting = true;
    ms_elapsed += 25;

    // turn motors off (noise source)
    pwm_set_chan_level(slice_num_TL, PWM_CHAN_A, 0);
    pwm_set_chan_level(slice_num_BL, PWM_CHAN_B, 0);
    pwm_set_chan_level(slice_num_TR, PWM_CHAN_A, 0);
    pwm_set_chan_level(slice_num_BR, PWM_CHAN_B, 0);

    // disconnect I2C Pins
    gpio_set_function(SDA_PIN, GPIO_FUNC_SIO);
    gpio_set_function(SCL_PIN, GPIO_FUNC_SIO);
    gpio_set_dir(SDA_PIN, GPIO_IN);
    gpio_set_dir(SCL_PIN, GPIO_IN);

    // power cycle off GPIO (tune minimum acceptable delay - capacitance?)
    gpio_put(IMU_POWER_PIN, 0);
    busy_wait_ms(5); // TODO tune this value
    gpio_put(IMU_POWER_PIN, 1);
    busy_wait_ms(20); // TODO tune this value (works at 25 ms)

    // re-initialize I2C
    i2c_init(I2C_CHAN, I2C_BAUD_RATE);
    gpio_set_function(SDA_PIN, GPIO_FUNC_I2C);
    gpio_set_function(SCL_PIN, GPIO_FUNC_I2C);

    // reset -> should be good to go!
    mpu6050_reset();
    // allow state estimation in interrupt now that we're done
    nuclear_resetting = false;
}

// calculate angular velocity. Clamp to reasonable max and min
float calculate_angle_deltas(fix15 angle, fix15 old_angle)
{
    float angle_f = fix2float15(angle);
    float old_angle_f = fix2float15(old_angle);

    // had to switch to fabsf bc truncation (?)
    float delta = fabsf(angle_f - old_angle_f);

    // will account for longer than 1 ms period bc nuclear_reset() 
    uint32_t t_delta = time_ms_t - last_time_ms_t;

    // shouldn't be possible, jus a safety check
    if (t_delta < 1)
    {
        t_delta = 1; // avoid div by 0
    }

    // convert to deg/s
    delta = delta * 1000.0 / (t_delta);

    // handle spikes in data or atan2 wraparound
    if (delta > max_deg_s)
    {
        delta = 0; // test this logic!
    }
    return delta;
}


// mode: 0 is symmetric, 1 is strictly less than, 2 is strictly greater than
// proportional control calculations by desired error symmetry type
int calculate_correction(float angle, float threshold, float desired_angle, float multiplier, int mode)
{
    int correction = 0;
    
    // symmetric
    if (mode == 0)
    {
        if (fabsf(angle - desired_angle) > threshold)
        {
            correction = (int)(multiplier * fabsf(angle - desired_angle));
        }
    }
    // "should be" slt
    else if (mode == 1)
    {
        if (angle > desired_angle + threshold)
        {
            correction = (int)(multiplier * fabsf(angle - desired_angle));
        }
    }
    // "should be" sgt
    else if (mode == 2)
    {
        if (angle < desired_angle - threshold)
        {
            correction = (int)(multiplier * fabsf(angle - desired_angle));
        }
    }
    return correction;
}


// cost function to calculate correct vibration correction based on IMU state
// mode = 0 -> vertical, 1 -> horizontal, 2 -> diagonal slash
int slice_tutor(int mode)
{
    // get angular velocities for evaluation
    complementary_angle_delta_x = calculate_angle_deltas(complementary_angle_x, prev_complementary_angle_x);
    complementary_angle_delta_y = calculate_angle_deltas(complementary_angle_y, prev_complementary_angle_y);
    complementary_angle_delta_z = calculate_angle_deltas(complementary_angle_z, prev_complementary_angle_z);

    int correction = 0;

    float desired_theta_x = 200;                     // prev 150
    float x_multiplier = max_vibe / desired_theta_x; // kill it by 0
    float threshold_x = 0;                           // 50
    int correction_x = 0;
    // // calculate x component of error
    correction_x = calculate_correction(complementary_angle_delta_x, threshold_x, desired_theta_x, x_multiplier, 2);
    // // y component
    float desired_theta_y = 1.0 / 3.0 * complementary_angle_delta_x;
    float y_multiplier = max_vibe / (3 * desired_theta_y); // 10 // kill it by 3x
    float threshold_y = 0;                                 // 50
    int correction_y = 0;
    // // calculate y component of error
    correction_y = calculate_correction(complementary_angle_delta_y, threshold_y, desired_theta_y, y_multiplier, 1);
    // // z component
    float desired_theta_z = 1.0 / 4.0 * complementary_angle_delta_x;
    float z_multiplier = max_vibe / (3 * desired_theta_z); // kill it by 3x
    float threshold_z = 0;                                 // 0
    int correction_z = 0;
    correction_z = calculate_correction(complementary_angle_delta_z, threshold_z, desired_theta_z, z_multiplier, 1);
    // absolute yaw, calculate depend on slice type (this component differentiates slice type)
    float desired_y_abs = 0;
    float y_abs_multiplier = 65; // kill it by 45 off
    float threshold_y_abs = 20;
    int correction_y_abs = 0;
    if (mode == 0) // vertical
    {
        desired_y_abs = 180;
        correction_y_abs = calculate_correction(fix2float15(complementary_angle_y), threshold_y_abs, desired_y_abs, y_abs_multiplier, 0);
    }
    else if (mode == 1) // horizontal
    {
        desired_y_abs = 90;
        float correction_y_abs_1 = calculate_correction(fix2float15(complementary_angle_y), threshold_y_abs, desired_y_abs, y_abs_multiplier, 0);
        desired_y_abs = 270;
        float correction_y_abs_2 = calculate_correction(fix2float15(complementary_angle_y), threshold_y_abs, desired_y_abs, y_abs_multiplier, 0);
        correction_y_abs = min(correction_y_abs_1, correction_y_abs_2);
    }
    else if (mode == 2) // diagonal slash
    {
        desired_y_abs = 135;
        float correction_y_abs_1 = calculate_correction(fix2float15(complementary_angle_y), threshold_y_abs, desired_y_abs, y_abs_multiplier, 0);
        desired_y_abs = 225;
        float correction_y_abs_2 = calculate_correction(fix2float15(complementary_angle_y), threshold_y_abs, desired_y_abs, y_abs_multiplier, 0);
        correction_y_abs = min(correction_y_abs_1, correction_y_abs_2);
    }
    else{
        return 0;
    }

    // clamp each correction to be 0 -> 5000 (max pwm)
    if (correction_x > max_vibe)
    {
        correction_x = max_vibe;
    }
    if (correction_x < 0)
    {
        correction_x = 0;
    }

    if (correction_y > max_vibe)
    {
        correction_y = max_vibe;
    }
    if (correction_y < 0)
    {
        correction_y = 0;
    }

    if (correction_z > max_vibe)
    {
        correction_z = max_vibe;
    }
    if (correction_z < 0)
    {
        correction_z = 0;
    }

    if (correction_y_abs > max_vibe)
    {
        correction_y_abs = max_vibe;
    }
    if (correction_y_abs < 0)
    {
        correction_y_abs = 0;
    }

    // max correction with fabs 
    int max_correction = max(max(fabs(correction_x), fabs(correction_y_abs)), max(fabsf(correction_y), fabsf(correction_z)));
    // subtract from max_vibe (5000) for positive feedback
    return (max_vibe - max_correction);
}

// For real-time slice detection and reward function calculation
int slice_grader()
{
    // absolute yaw
    float desired_y_abs = 0;
    float y_abs_multiplier = 65; // kill it by 45 off
    float threshold_y_abs = 15;
    int correction_y_abs = 0;
    // detect the roll orientation
    classifier[0] = 99999999; // nothing - won't be selected
                              // 0 -> nothing, 1 -> vertical, 2 -> horizontal from left, 3 -> horizontal frm right
                              // 4 -> diagonal from left, 5 -> diagonal from right


    // populate classifier with score for each possible slice type
    desired_y_abs = 180;
    classifier[1] = calculate_correction(fix2float15(complementary_angle_y), threshold_y_abs, desired_y_abs, y_abs_multiplier, 0);
    desired_y_abs = 90;
    classifier[2] = calculate_correction(fix2float15(complementary_angle_y), threshold_y_abs, desired_y_abs, y_abs_multiplier, 0);
    desired_y_abs = 270;
    classifier[3] = calculate_correction(fix2float15(complementary_angle_y), threshold_y_abs, desired_y_abs, y_abs_multiplier, 0);
    desired_y_abs = 135;
    classifier[4] = calculate_correction(fix2float15(complementary_angle_y), threshold_y_abs, desired_y_abs, y_abs_multiplier, 0);
    desired_y_abs = 225;
    classifier[5] = calculate_correction(fix2float15(complementary_angle_y), threshold_y_abs, desired_y_abs, y_abs_multiplier, 0);


    // find the best match
    int lowest_correction = classifier[0]; // really big number
    int lowest_correction_type = 0;
    for (int i = 1; i < 6; i++)
    {
        if (classifier[i] < lowest_correction)
        {
            lowest_correction = classifier[i];
            lowest_correction_type = i;
        }
    }
    // prepare for consec classification
    prev_consec_type = consec_type;
    consec_type = lowest_correction_type;


    complementary_angle_delta_x = calculate_angle_deltas(complementary_angle_x, prev_complementary_angle_x);
    complementary_angle_delta_y = calculate_angle_deltas(complementary_angle_y, prev_complementary_angle_y);
    complementary_angle_delta_z = calculate_angle_deltas(complementary_angle_z, prev_complementary_angle_z);


    // calculate reward function
    int correction = 0;
    float desired_theta_x = 200;                     // 150
    float x_multiplier = max_vibe / desired_theta_x; // 15 // kill it by 0
    float threshold_x = 0;                           // 50
    int correction_x = 0;
    // // calculate x component of error
    correction_x = calculate_correction(complementary_angle_delta_x, threshold_x, desired_theta_x, x_multiplier, 2);
    // // y component
    float desired_theta_y = 1.0 / 3.0 * complementary_angle_delta_x;
    float y_multiplier = max_vibe / (3 * desired_theta_y); // 10 // kill it by 3x
    float threshold_y = 0;                                 // 50
    int correction_y = 0;
    // // calculate y component of error
    correction_y = calculate_correction(complementary_angle_delta_y, threshold_y, desired_theta_y, y_multiplier, 1);
    // // z component
    float desired_theta_z = 1.0 / 4.0 * complementary_angle_delta_x;
    float z_multiplier = max_vibe / (3 * desired_theta_z); // kill it by 3x
    float threshold_z = 0;                                 // 0
    int correction_z = 0;
    correction_z = calculate_correction(complementary_angle_delta_z, threshold_z, desired_theta_z, z_multiplier, 1);
    // clamp each error component
    if (correction_x > max_vibe)
    {
        correction_x = max_vibe;
    }
    if (correction_x < 0)
    {
        correction_x = 0;
    }


    if (correction_y > max_vibe)
    {
        correction_y = max_vibe;
    }
    if (correction_y < 0)
    {
        correction_y = 0;
    }


    if (correction_z > max_vibe)
    {
        correction_z = max_vibe;
    }
    if (correction_z < 0)
    {
        correction_z = 0;
    }


    if (lowest_correction > max_vibe)
    {
        lowest_correction = max_vibe;
    }
    if (lowest_correction < 0)
    {
        lowest_correction = 0;
    }


    // ms_elapsed = 0; // reset timer


    int max_correction = max(max(fabs(correction_x), fabs(lowest_correction)), max(fabsf(correction_y), fabsf(correction_z)));
   
    // determine consec eligibility
    if ((consec_type == prev_consec_type) && (max_correction < max_acceptable_penalty))
    {
        consec++;
        consec_fail = 0;
    }
    else
    {
        consec_fail++;
        if (consec_fail == consec_fail_needed)
        {
            consec = 0;
        }
    }
    // return slice type if criteria met, else return 0
    if (consec >= consec_needed)
    {
        return consec_type;
    }
    return 0;
}

// standard complementary angle calculation
void calculate_angle()
{
    // No small angle approximation
    accel_angle_x = multfix15(float2fix15(atan2(filtered_az, filtered_ay)), oneeightyoverpi);
    accel_angle_y = multfix15(float2fix15(atan2(filtered_ax, filtered_az) + PI), oneeightyoverpi);

    // Gyro angle delta
    gyro_angle_delta_x = multfix15(gyro[0], zeropt001);
    gyro_angle_delta_y = multfix15(gyro[1], zeropt001);
    gyro_angle_delta_z = multfix15(gyro[2], zeropt001); // bc 1 Khz interrupt

    // Past complementary angle
    prev_complementary_angle_x = complementary_angle_x;
    prev_complementary_angle_y = complementary_angle_y;
    prev_complementary_angle_z = complementary_angle_z;

    // Complementary angle
    complementary_angle_x = multfix15(complementary_angle_x - gyro_angle_delta_x, zeropt999) + multfix15(accel_angle_x, zeropt001);
    complementary_angle_y = multfix15(complementary_angle_y - gyro_angle_delta_y, zeropt999) + multfix15(accel_angle_y, zeropt001);
    // todo reset logic on the below /handling drift
    complementary_angle_z = complementary_angle_z - gyro_angle_delta_z; // simple gyro accumulation
}

//-----New IMU detection slice code------//
#define SLICE_COOLDOWN_MS 150
#define SLICE_ACCEL_MAG_THRESH 7000 // fix15
#define SLICE_DEG_S_THRESH 200.0f
#define SLICE_DIAG_RARIO 0.55f
#define AX_DOMINANCE 1.20f
static uint32_t last_slice_time_ms = 0;
// simpler slice detection for fruit ninja game mode
void detect_slice()
{
    uint32_t now = time_us_64() / 1000;

    if (now - last_slice_time_ms < SLICE_COOLDOWN_MS)
    {
        return;
    }

    // 1) Check that swing is strong enough to prevent small motions from being accepted (these are fix15)
    int accel_mag = abs(filtered_ax) + abs(filtered_ay) + abs(filtered_az);
    if (accel_mag < SLICE_ACCEL_MAG_THRESH)
    {
        return;
    }

    // 2) Use float deltas (degrees/sec)
    float dx = complementary_angle_delta_x;
    float dy = complementary_angle_delta_y;
    float dz = complementary_angle_delta_z;

    float ax = fabsf(dx);
    float ay = fabsf(dy);
    float az = fabsf(dz);

    if (ax < SLICE_DEG_S_THRESH && ay < SLICE_DEG_S_THRESH && az < SLICE_DEG_S_THRESH)
    {
        return;
    }

    if (ax > az * AX_DOMINANCE && ax > ay * AX_DOMINANCE && ax >= SLICE_DEG_S_THRESH)
    {
        force_slice_vertical = 1;
        last_slice_time_ms = now;
        return;
    }

    // 5) Detect horizontal slice
    if (ay > ax * AX_DOMINANCE && ay > az * AX_DOMINANCE && ay >= SLICE_DEG_S_THRESH)
    {
        force_slice_horizontal = 1;
        last_slice_time_ms = now;
    }
}

//-----New IMU detection slice code------//
void drawLogo()
{
    int index = 0;
    for (int y = 0; y < LOGO_HEIGHT; y++)
    {
        for (int x = 0; x < LOGO_WIDTH; x++)
        {
            drawPixel(x + 40, y + 50, LOGO[index++]);
        }
    }
}

// primary menu screen
void drawMenu()
{
    setCursor(200, 50);
    setTextColor2(DARK_GREEN, BLACK);
    setTextSize(10);
    writeString("Menu");

    setCursor(150, 150);
    setTextColor2(DARK_GREEN, BLACK);
    setTextSize(7);
    writeString("1) Train");

    setCursor(150, 225);
    setTextColor2(DARK_GREEN, BLACK);
    setTextSize(7);
    writeString("2) Play");
}

#define move1_size (sizeof(Move1) / sizeof(Move))
#define move2_size (sizeof(Move2) / sizeof(Move))
#define move3_size (sizeof(Move3) / sizeof(Move))

// generalized image array handling
typedef struct
{
    const unsigned char *img_array;
    int width;
    int height;
} Move;

// slice structs for VGA
Move Move1[] = {
    {MOVE1_1, MOVE1_WIDTH, MOVE1_HEIGHT},
    {MOVE1_2, MOVE1_WIDTH, MOVE1_HEIGHT},
    {MOVE1_3, MOVE1_WIDTH, MOVE1_HEIGHT},
    {MOVE1_4, MOVE1_WIDTH, MOVE1_HEIGHT}};

Move Move2[] = {
    {MOVE2_1, MOVE2_WIDTH, MOVE2_HEIGHT},
    {MOVE2_2, MOVE2_WIDTH, MOVE2_HEIGHT},
    {MOVE2_3, MOVE2_WIDTH, MOVE2_HEIGHT}};

Move Move3[] = {
    {MOVE3_1, MOVE3_WIDTH, MOVE3_HEIGHT},
    {MOVE3_2, MOVE3_WIDTH, MOVE3_HEIGHT}};

// draw training screen slice training given position, image array, and size
void drawMove(int startX, int startY,
              const unsigned char *data,
              int width, int height)
{
    int bytesPerRow = (width + 7) >> 3; // round up to full bytes

    int index = 0;
    for (int y = 0; y < height; y++)
    {
        for (int bx = 0; bx < bytesPerRow; bx++)
        {

            unsigned char byte = data[index++];

            for (int bit = 7; bit >= 0; bit--)
            {
                int pixelX = bx * 8 + (7 - bit);

                if (pixelX >= width)
                    continue; // padding bits

                int color = (byte >> bit) & 1;
                drawPixel(startX + pixelX, startY + y, color);
            }
        }
    }
}

// menu option for game mode not implemented
// vision was to have 3rd level of application wherein
// fighting a real-time user with pseudo-random or adaptive
// strategy. haptic feedback to indicate successful strik or defense
void drawSpar()
{
    setCursor(200, 50);
    setTextColor2(GREEN, BLACK);
    setTextSize(10);
    writeString("Spar");
}
// menu helpers
void drawPlay()
{
    setCursor(200, 50);
    setTextColor2(GREEN, BLACK);
    setTextSize(10);
    writeString("Play");
}
// initial interface for gameplay before keypad implemented
static PT_THREAD(protothread_serial(struct pt *pt))
{
    PT_BEGIN(pt);
    static char classifier;
    while (1)
    {
        sprintf(pt_serial_out_buffer, "input a command (1:vertical 2:horizontal 3:slash 4:backslash): ");
        serial_write;

        serial_read;
        // read the first char of input
        sscanf(pt_serial_in_buffer, " %c", &classifier);

        if (classifier == '1')
        {
            force_slice_vertical = 1;
            sprintf(pt_serial_out_buffer, "Vertical slice queued.\n");
            serial_write;
        }
        else if (classifier == '2')
        {
            force_slice_horizontal = 1;
            sprintf(pt_serial_out_buffer, "Horizontal slice queued.\n");
            serial_write;
        }
        else if (classifier == '3')
        {
            force_slice_diag_slash = 1;
            sprintf(pt_serial_out_buffer, "Diagonal (/) slice queued.\n");
            serial_write;
        }
        else if (classifier == '4')
        {
            force_slice_diag_backslash = 1;
            sprintf(pt_serial_out_buffer, "Diagonal (\\) slice queued.\n");
            serial_write;
        }
        // small yield so serial thread doesn't hog CPU
        PT_YIELD_usec(1000);
    }
    PT_END(pt);
}

volatile int valid_press = 0;
static int last_button_state = 0;
static int stable_state = 0;
static int debounce_counter = 0;
const int debounce_threshold = 3;
// debounce logic for breakwire
static PT_THREAD(protothread_debounce(struct pt *pt))
{
    PT_BEGIN(pt);

    while (1)
    {
        int current_state = gpio_get(SWITCH_PIN);

        if (current_state == stable_state)
        {
            debounce_counter = 0;
        }
        else
        {
            debounce_counter++;
            if (debounce_counter >= debounce_threshold)
            {
                last_button_state = stable_state;
                stable_state = current_state;
                debounce_counter = 0;

                // Detect rising edge (button press)
                if (stable_state == 1 && last_button_state == 0)
                {
                    valid_press = 1; // flag a valid button press
                }
            }
        }

        PT_YIELD_usec(10000); // sample every 10 ms (~100 Hz)

    } // end while(1)

    PT_END(pt);
}

// primary enum to control graphic and background logic for the different modes
typedef enum
{
    START_SCREEN,
    LOGO_SCREEN,
    MENU_SCREEN,
    CHOOSEMOVE_SCREEN,
    MOVE1_SCREEN,
    MOVE2_SCREEN,
    MOVE3_SCREEN,
    POSITION_SCREEN,
    INSTRUCTIONS_SCREEN,
    COMBOS_SCREEN,
    PLAY_SCREEN,
    OPTIONS_SCREEN,
    TRAIN_SCREEN,
    TRAIN_RESULTS_SCREEN
} ScreenState;

// start in logo screen and no desired slice
static ScreenState screen = LOGO_SCREEN;
int cut_mode = 4; // 0 = vertical cut, 1 = horizontal cut, 2 = diagonal cut
// all graphics live here, protected by semaphore from interrupt
static PT_THREAD(protothread_vga(struct pt *pt))
{
    PT_BEGIN(pt);
    static int move1_frame = 0;
    static int move2_frame = 0;
    static int move3_frame = 0;
    uint32_t start_time = 0;
    static int begin_time, spare_time;
    static ScreenState last_screen = (ScreenState)-1; // Ensure first run triggers initialization

    static int move1_cycles = 0;
    static int move2_cycles = 0;
    static int move3_cycles = 0;

    int cut1_stats_idx = 0;

    while (1)
    {
        if (screen != last_screen)
        {
            if (screen == LOGO_SCREEN)
            {
                start_time = time_us_32();
            }
            // === START FIX: One-time setup for PLAY_SCREEN ===
            else if (screen == PLAY_SCREEN)
            {
                fillRect(0, 0, 640, 480, BLACK); // Clear screen when entering
                spawnMainFruit(&boid_main);      // Spawn first fruit
            }
            // === END FIX ===
            last_screen = screen;
        }
        // draw correct graphics depending on enum state
        switch (screen)
        {
        case LOGO_SCREEN:
            drawLogo();

            // stay on logo for 5 seconds
            if (time_us_32() - start_time > 5000000)
            {
                fillRect(0, 0, 500, 500, BLACK);
                screen = MENU_SCREEN;
            }

            PT_YIELD_usec(300000);
            break;
        // main menu to take user action
        case MENU_SCREEN:
            drawMenu();

            if (menu_key == 1)
            {
                fillRect(0, 0, 500, 300, BLACK);
                screen = CHOOSEMOVE_SCREEN;
                menu_key = -1;
            }
            else if (menu_key == 2)
            {
                fillRect(0, 0, 500, 300, BLACK);
                screen = POSITION_SCREEN; // PRESS 2 ON KEYPAD TO LOOK AT POSITION
                menu_key = -1;
            }
            else if (menu_key == 3)
            {
                fillRect(0, 0, 500, 300, BLACK);
                screen = PLAY_SCREEN; // This triggers the setup code in the `if(screen != last_screen)` block
                menu_key = -1;
            }
            PT_YIELD_usec(100000);
            break;
        // training mode, user decides which slice to train
        case CHOOSEMOVE_SCREEN:
            setCursor(65, 50);
            setTextColor2(DARK_GREEN, BLACK);
            setTextSize(6);
            writeString("Choose a move");

            setCursor(65, 125);
            setTextColor2(DARK_GREEN, BLACK);
            setTextSize(4);
            writeString("7) Vertical Cut");

            setCursor(65, 175);
            setTextColor2(DARK_GREEN, BLACK);
            setTextSize(4);
            writeString("8) Horizontal Cut");

            setCursor(65, 225);
            setTextColor2(DARK_GREEN, BLACK);
            setTextSize(4);
            writeString("9) Diagonal Cut");

            if (menu_key == 7)
            {
                fillRect(0, 0, 640, 480, BLACK);
                screen = MOVE1_SCREEN;
                menu_key = -1;
            }
            else if (menu_key == 8)
            {
                fillRect(0, 0, 640, 480, BLACK);
                screen = MOVE2_SCREEN;
                menu_key = -1;
            }
            else if (menu_key == 9)
            {
                fillRect(0, 0, 640, 480, BLACK);
                screen = MOVE3_SCREEN;
                menu_key = -1;
            }
            PT_YIELD_usec(100000);
            break;
        // vertical cut training
        case MOVE1_SCREEN:
            cut_mode = 0;
            setCursor(75, 45);
            setTextColor2(DARK_GREEN, BLACK);
            setTextSize(6);
            writeString("Vertical Cut");

            setCursor(200, 100);
            setTextColor2(DARK_GREEN, BLACK);
            setTextSize(2);
            writeString("Press 4 to exit");

            // clear screen each frame
            fillRect(0, 125, 640, 425, BLACK);

            // Draw current frame
            drawMove(75, 125, Move1[move1_frame].img_array,
                     MOVE1_WIDTH,
                     MOVE1_HEIGHT);

            move1_frame++;
            // delta time loop so we're not erasing/redrawing stats every 1 ms (flicker)
            if ((cut1_stats_idx % 25) == 0)
            {
                // Erase old stats
                fillRect(0, 0, 100, 45, BLACK);

                setCursor(0, 10);
                setTextColor2(WHITE, BLACK);
                setTextSize(1);
                writeString(" Delta x: ");
                char x_text[20] = {0};
                sprintf(x_text, "%.1f", complementary_angle_delta_x); // %d for unsigned int
                writeString(x_text);

                setCursor(0, 20);
                setTextColor2(WHITE, BLACK);
                setTextSize(1);
                writeString(" Delta y: ");
                char y_text[20] = {0};
                sprintf(y_text, "%.1f", complementary_angle_delta_y); // %d for unsigned int
                writeString(y_text);

                setCursor(0, 30);
                setTextColor2(WHITE, BLACK);
                setTextSize(1);
                writeString(" Delta z: ");
                char z_text[20] = {0};
                sprintf(z_text, "%.1f", complementary_angle_delta_z); // %d for unsigned int
                writeString(z_text);

                setCursor(100, 10);
                setTextColor2(WHITE, BLACK);
                setTextSize(1);
                writeString(" Absolute y: ");
                char absy_text[20] = {0};
                sprintf(absy_text, "%.1f", fix2float15(complementary_angle_y)); // %d for unsigned int
                writeString(absy_text);
            }

            // Loop animation forever
            if (move1_frame >= move1_size)
            {
                move1_frame = 0;
            }

            // Exit when pressing key 4
            if (menu_key == 4)
            {
                fillRect(0, 0, 640, 480, BLACK);
                move1_frame = 0; // reset for next time this screen is used
                screen = MENU_SCREEN;
                menu_key = -1;
            }

            PT_YIELD_usec(500000); // 10 FPS
            break;
        // horiztonal cut training
        case MOVE2_SCREEN:
            cut_mode = 1;
            setCursor(75, 45);
            setTextColor2(DARK_GREEN, BLACK);
            setTextSize(6);
            writeString("Horizontal Cut");

            setCursor(200, 100);
            setTextColor2(DARK_GREEN, BLACK);
            setTextSize(2);
            writeString("Press 4 to exit");

            // clear screen each frame
            fillRect(0, 125, 640, 425, BLACK);

            // Draw current frame
            drawMove(125, 125, Move2[move2_frame].img_array,
                     MOVE2_WIDTH,
                     MOVE2_HEIGHT);

            move2_frame++;

            if ((cut1_stats_idx % 25) == 0)
            {
                // Erase old stats
                fillRect(0, 0, 100, 45, BLACK);

                setCursor(0, 10);
                setTextColor2(WHITE, BLACK);
                setTextSize(1);
                writeString(" Delta x: ");
                char x_text[20] = {0};
                sprintf(x_text, "%.1f", complementary_angle_delta_x); // %d for unsigned int
                writeString(x_text);

                setCursor(0, 20);
                setTextColor2(WHITE, BLACK);
                setTextSize(1);
                writeString(" Delta y: ");
                char y_text[20] = {0};
                sprintf(y_text, "%.1f", complementary_angle_delta_y); // %d for unsigned int
                writeString(y_text);

                setCursor(0, 30);
                setTextColor2(WHITE, BLACK);
                setTextSize(1);
                writeString(" Delta z: ");
                char z_text[20] = {0};
                sprintf(z_text, "%.1f", complementary_angle_delta_z); // %d for unsigned int
                writeString(z_text);

                setCursor(100, 10);
                setTextColor2(WHITE, BLACK);
                setTextSize(1);
                writeString(" Absolute y: ");
                char absy_text[20] = {0};
                sprintf(absy_text, "%.1f", fix2float15(complementary_angle_y)); // %d for unsigned int
                writeString(absy_text);
            }

            if (move2_frame >= move2_size)
            {
                move2_frame = 0;
            }

            if (menu_key == 4)
            {
                fillRect(0, 0, 640, 480, BLACK);
                move2_frame = 0;
                screen = MENU_SCREEN;
                menu_key = -1;
            }

            PT_YIELD_usec(500000); // 10 FPS
            break;
        // diagonal cut training
        case MOVE3_SCREEN:
            cut_mode = 2;
            setCursor(75, 45);
            setTextColor2(DARK_GREEN, BLACK);
            setTextSize(6);
            writeString("Diagonal Cut");

            setCursor(200, 100);
            setTextColor2(DARK_GREEN, BLACK);
            setTextSize(2);
            writeString("Press 4 to exit");

            // clear screen each frame
            fillRect(0, 125, 640, 425, BLACK);

            // Draw current frame
            drawMove(100, 125, Move3[move3_frame].img_array,
                     MOVE3_WIDTH,
                     MOVE3_HEIGHT);

            move3_frame++;

            if ((cut1_stats_idx % 25) == 0)
            {
                // Erase old stats
                fillRect(0, 0, 100, 45, BLACK);

                setCursor(0, 10);
                setTextColor2(WHITE, BLACK);
                setTextSize(1);
                writeString(" Delta x: ");
                char x_text[20] = {0};
                sprintf(x_text, "%.1f", complementary_angle_delta_x); // %d for unsigned int
                writeString(x_text);

                setCursor(0, 20);
                setTextColor2(WHITE, BLACK);
                setTextSize(1);
                writeString(" Delta y: ");
                char y_text[20] = {0};
                sprintf(y_text, "%.1f", complementary_angle_delta_y); // %d for unsigned int
                writeString(y_text);

                setCursor(0, 30);
                setTextColor2(WHITE, BLACK);
                setTextSize(1);
                writeString(" Delta z: ");
                char z_text[20] = {0};
                sprintf(z_text, "%.1f", complementary_angle_delta_z); // %d for unsigned int
                writeString(z_text);

                setCursor(100, 10);
                setTextColor2(WHITE, BLACK);
                setTextSize(1);
                writeString(" Absolute y: ");
                char absy_text[20] = {0};
                sprintf(absy_text, "%.1f", fix2float15(complementary_angle_y)); // %d for unsigned int
                writeString(absy_text);
            }

            if (move3_frame >= move3_size)
            {
                move3_frame = 0;
            }
            // take you back to menu 
            if (menu_key == 4)
            {
                fillRect(0, 0, 640, 480, BLACK);
                move3_frame = 0;
                screen = MENU_SCREEN;
                menu_key = -1;
            }

            PT_YIELD_usec(500000); // 10 FPS
            break;
        // fruit ninja game mode
        case PLAY_SCREEN:
        {
            begin_time = time_us_32();

            // Slice triggers
            int sliced_now = 0;
            if (force_slice_vertical)
            {
                force_slice_vertical = 0;
                sliced_now = 1;
                slice_type = 1;
            }
            if (force_slice_horizontal)
            {
                force_slice_horizontal = 0;
                sliced_now = 1;
                slice_type = 2;
            }
            if (force_slice_diag_slash)
            {
                force_slice_diag_slash = 0;
                sliced_now = 1;
                slice_type = 3;
            }
            if (force_slice_diag_backslash)
            {
                force_slice_diag_backslash = 0;
                sliced_now = 1;
                slice_type = 4;
            }

            if (sliced_now && boid_main.active)
            {
                int type = boid_main.type;
                int pts = getFruitPoints(boid_main.type);

                if (type == lastFruitType)
                {
                    comboCount++;
                }
                else
                {
                    comboCount = 1;
                }

                lastFruitType = type;
                // Trigger COMBO popup if 2 or more same fruit
                if (comboCount >= 2)
                {
                    addComboPopup(fix2int15(boid_main.x) - 20, fix2int15(boid_main.y) - 20);
                }

                int comboBonus = getComboBonus(comboCount);

                // Add popup
                addPopup(fix2int15(boid_main.x), fix2int15(boid_main.y), pts + comboBonus);

                // Increment counters
                num_fruit_sliced += 1;     // increment by 1 per fruit
                score += pts + comboBonus; // add points depending on fruit type

                // render correct fruit slice graphic depending on orientation of slice
                if (slice_type == 1)
                {
                    spawnHalvesVertical();
                }
                else if (slice_type == 2)
                {
                    spawnHalvesHorizontal();
                }
                else if (slice_type == 3)
                {
                    spawnHalvesDiagSlash();
                }
                else if (slice_type == 4)
                {
                    spawnHalvesDiagBackslash();
                }
            }

            // Update movement
            updateBoid(&boid_main);
            updateBoid(&boid_halfL);
            updateBoid(&boid_halfR);
            updateBoid(&boid_halfTop);
            updateBoid(&boid_halfBottom);
            updateBoid(&boid_halfDiagA);
            updateBoid(&boid_halfDiagB);

            // Erase previous frames
            eraseBoid(&boid_main);
            eraseBoid(&boid_halfL);
            eraseBoid(&boid_halfR);
            eraseBoid(&boid_halfTop);
            eraseBoid(&boid_halfBottom);
            eraseBoid(&boid_halfDiagA);
            eraseBoid(&boid_halfDiagB);

            // Draw new frames
            drawBoid(&boid_main);
            drawBoid(&boid_halfL);
            drawBoid(&boid_halfR);
            drawBoid(&boid_halfTop);
            drawBoid(&boid_halfBottom);
            drawBoid(&boid_halfDiagA);
            drawBoid(&boid_halfDiagB);

            updatePopups();
            drawStats();

            // Respawn
            if (!boid_main.active &&
                !boid_halfL.active && !boid_halfR.active &&
                !boid_halfTop.active && !boid_halfBottom.active &&
                !boid_halfDiagA.active && !boid_halfDiagB.active)
            {
                spawnMainFruit(&boid_main);
            }
            // indicate slipping timing constraints for debugging
            spare_time = FRAME_RATE - (time_us_32() - begin_time);
            if (spare_time < 0) {
                //warn designers;
            }
            PT_YIELD_usec(spare_time);

            break; // End of PLAY_SCREEN case
        }
        // user information
        case INSTRUCTIONS_SCREEN:
            drawInstructions();
            break;
        
            // prompt user to perform the move and display real time movement?
        case TRAIN_SCREEN:
            setCursor(100, 100);
            setTextColor2(DARK_GREEN, BLACK);
            setTextSize(10);
            writeString("Placeholder");
        
            // post training menu
        case OPTIONS_SCREEN:
            // fillRect(0, 0, 640, 480, BLACK);

            setCursor(100, 100);
            setTextColor2(DARK_GREEN, BLACK);
            setTextSize(10);
            writeString("Options");

            setCursor(0, 200);
            setTextColor2(DARK_GREEN, BLACK);
            setTextSize(6);
            writeString("Press 4 to replay demo");

            setCursor(0, 275);
            setTextColor2(DARK_GREEN, BLACK);
            setTextSize(6);
            writeString("Press 5 to train");
            // go back
            if (menu_key == 4)
            {
                fillRect(0, 0, 640, 480, BLACK);
                screen = CHOOSEMOVE_SCREEN;
                menu_key = -1;
            }
            else if (menu_key == 5)
            {
                fillRect(0, 0, 640, 480, BLACK);
                screen = TRAIN_RESULTS_SCREEN;
                menu_key = -1;
            }

            PT_YIELD_usec(100000);
            break;
        case TRAIN_RESULTS_SCREEN:
            setCursor(100, 100);
            setTextColor2(DARK_GREEN, BLACK);
            setTextSize(10);
            writeString("Score Summary");

            setCursor(0, 200);
            setTextColor2(DARK_GREEN, BLACK);
            setTextSize(6);
            writeString("Press 6 to try again");
            break;
        }
    }
    PT_END(pt);
}
// 1 KHz interrupt with all state estimation/corrction/classification
// can be superceded by nuclear reset -> stil run but no state estimation
void on_pwm_wrap()
{
    // clear all interrupts
    pwm_clear_irq(pwm_gpio_to_slice_num(PWM_TL)); // do motors need their own irqs?
    pwm_clear_irq(pwm_gpio_to_slice_num(PWM_BL)); // add back in if necessary
    pwm_clear_irq(pwm_gpio_to_slice_num(PWM_TR));
    pwm_clear_irq(pwm_gpio_to_slice_num(PWM_BR));
    pwm_clear_irq(slice_num);

    // do NOT try and estimate state if IMU cannot talk
    if (!nuclear_resetting)
    {

        // turn off motors during send (put back in if helpful) ->
        // wait for any capacitance/dissipation
        pwm_set_chan_level(slice_num_TL, PWM_CHAN_A, 0);
        pwm_set_chan_level(slice_num_BL, PWM_CHAN_B, 0);
        pwm_set_chan_level(slice_num_TR, PWM_CHAN_A, 0);
        pwm_set_chan_level(slice_num_BR, PWM_CHAN_B, 0);
        busy_wait_us(150);

        // set up I2C to read and init
        gpio_set_function(SDA_PIN, GPIO_FUNC_I2C);
        gpio_set_function(SCL_PIN, GPIO_FUNC_I2C);
        i2c_init(I2C_CHAN, I2C_BAUD_RATE);

        // read IMU - adapted to be non-blocking (se mpu6050.c)
        bool read_status = mpu6050_read_raw(acceleration, gyro);

        // instant error detection through mpu6050 returned read status
        if (!read_status)
        {
            stall_counter++;
            if (stall_counter >= STALL_LIMIT)
            {
                // bus hangup
                stall_counter = 0;
                nuclear_reset();
            }
            return;
        }
        else
        {
            stall_counter = 0;
        }

        // complementary filter update, gyro handling for z
        filtered_ax = filtered_ax + ((acceleration[0] - filtered_ax) >> 2);
        filtered_ay = filtered_ay + ((acceleration[1] - filtered_ay) >> 2);
        filtered_az = filtered_az + ((acceleration[2] - filtered_az) >> 2);

        // reset I2C pins before we use motors
        gpio_set_function(SDA_PIN, GPIO_FUNC_SIO);
        gpio_set_function(SCL_PIN, GPIO_FUNC_SIO);
        gpio_set_dir(SDA_PIN, GPIO_IN);
        gpio_set_dir(SCL_PIN, GPIO_IN);

        calculate_angle();
        // for angular velocity calculations
        // adaps to actual time elapsed between calls
        last_time_ms_t = time_ms_t;
        time_ms_t = time_us_64() / 1000;

        // fruit ninja game mode
        detect_slice();

        // compute motor corrections
        int correction = slice_tutor(cut_mode); // COME BACK HERE


        // // set motors to correct value based on user action
        pwm_set_chan_level(slice_num_TL, PWM_CHAN_A, correction);
        pwm_set_chan_level(slice_num_BL, PWM_CHAN_B, correction);
        pwm_set_chan_level(slice_num_TR, PWM_CHAN_A, correction);
        pwm_set_chan_level(slice_num_BR, PWM_CHAN_B, correction);

    }
    PT_SEM_SIGNAL(pt, &vga_semaphore); // signal graphics
}

// Entry point for core 1
void core1_entry()
{
    pt_add_thread(protothread_vga);
    pt_add_thread(protothread_debounce);
    pt_schedule_start;
}

// This thread runs on core 0 - keypad and LED
static PT_THREAD(protothread_core_0(struct pt *pt))
{
    // Indicate thread beginning
    PT_BEGIN(pt);

    // Variales for keypad
    static int i;
    static uint32_t keypad;

    // Variables for debouncing
    static int stable_key = -1;
    static int debounce_count = 0;
    const int debounce_kp_threshold = 2;

    while (1)
    {
        gpio_put(LED, !gpio_get(LED));

        // Scan the keypad!
        for (i = 0; i < KEYROWS; i++)
        {
            // Set a row high
            gpio_put_masked((0xF << BASE_KEYPAD_PIN),
                            (scancodes[i] << BASE_KEYPAD_PIN));
            // Small delay required
            sleep_us(1);
            // Read the keycode
            keypad = ((gpio_get_all() >> BASE_KEYPAD_PIN) & 0x7F);
            // Break if button(s) are pressed
            if (keypad & button)
                break;
        }
        // If we found a button . . .
        if (keypad & button)
        {
            // Look for a valid keycode.
            for (i = 0; i < NUMKEYS; i++)
            {
                if (keypad == keycodes[i])
                {
                    break;
                }
            }
            // If we don't find one, report invalid keycode
            if (i == NUMKEYS)
                (i = -1);
        }
        // Otherwise, indicate invalid/non-pressed buttons
        else
            (i = -1);

        // Write key to VGA
        if (i == stable_key)
        { // if the new reading i == stable_key then no change
            debounce_count = 0;
        }
        else
        { // otherwise don't immediately accept the new reading i
            debounce_count++;
            if (debounce_count >= debounce_kp_threshold)
            { // wait til we see the same new value for the threshold # of scans in a row
                stable_key = i;
                last_stable_key = stable_key;
                debounce_count = 0;

                if (stable_key != prev_key)
                {
                    prev_key = stable_key;
                    if (screen == MENU_SCREEN)
                    {
                        if (stable_key == 1 || stable_key == 2 || stable_key == 3)
                        {
                            menu_key = stable_key;
                        }
                    }
                    if (screen == MOVE1_SCREEN || screen == MOVE2_SCREEN || screen == MOVE3_SCREEN)
                    {
                        if (stable_key == 4)
                        {
                            menu_key = stable_key;
                        }
                    }
                    if (screen == CHOOSEMOVE_SCREEN)
                    {
                        if (stable_key == 7 || stable_key == 8 || stable_key == 9)
                        {
                            menu_key = stable_key;
                        }
                    }
                }
            }
        }
        PT_YIELD_usec(30000);
    }
    PT_END(pt);
}

// initialization of hardware and launch protothreads
int main()
{
    // Overclock
    set_sys_clock_khz(150000, true);

    // Initialize stdio
    stdio_init_all();

    // Initialize the VGA screen
    initVGA();

    // Map LED to GPIO port, make it low
    gpio_init(LED);
    gpio_set_dir(LED, GPIO_OUT);
    gpio_put(LED, 0);

    gpio_init(SWITCH_PIN);
    gpio_set_dir(SWITCH_PIN, GPIO_IN);
    gpio_pull_up(SWITCH_PIN);

    gpio_init(IMU_POWER_PIN);
    gpio_set_dir(IMU_POWER_PIN, GPIO_OUT);
    gpio_set_drive_strength(IMU_POWER_PIN, GPIO_DRIVE_STRENGTH_12MA);
    gpio_put(IMU_POWER_PIN, 1);

    busy_wait_us(1000000);

    ////////////////// KEYPAD INITS ///////////////////////
    // Initialize the keypad GPIO's
    gpio_init_mask((0x7F << BASE_KEYPAD_PIN));
    // Set row-pins to output
    gpio_set_dir_out_masked((0xF << BASE_KEYPAD_PIN));
    // Set all output pins to low
    gpio_put_masked((0xF << BASE_KEYPAD_PIN), (0x0 << BASE_KEYPAD_PIN));
    // Turn on pulldown resistors for column pins (on by default)
    gpio_pull_down((BASE_KEYPAD_PIN + 4));
    gpio_pull_down((BASE_KEYPAD_PIN + 5));
    gpio_pull_down((BASE_KEYPAD_PIN + 6));

    for (int pin = 0; pin < 30; pin++)
    {
        printf("After keypad init: GPIO %d FUNCSEL = %d\n", pin,
               (int)gpio_get_function(pin));
    }

    //////////////////////// I2C CONFIGURATION ////////////////////////////
    i2c_init(I2C_CHAN, I2C_BAUD_RATE);
    gpio_set_function(SDA_PIN, GPIO_FUNC_I2C); // SDA_PIN = GPIO 4, GPIO_FUNC_I2C = GPIO 3
    gpio_set_function(SCL_PIN, GPIO_FUNC_I2C); // SCL_PIN = GPIO 5, GPIO_FUNC_I2C = GPIO 3

    // Pullup resistors on breakout board, don't need to turn on internals
    gpio_pull_up(SDA_PIN);
    gpio_pull_up(SCL_PIN);

    // MPU6050 initialization
    mpu6050_reset();
    mpu6050_read_raw(acceleration, gyro);

    //////////////////////////// PWM CONFIGURATION FOR 1KHZ ////////////////////////////
    // Tell GPIO PWM_OUT that it is allocated to the PWM
    gpio_set_function(PWM_TL, GPIO_FUNC_PWM); // PWM_TL = GPIO 2, GPIO_FUNC_PWM = GPIO 4
    gpio_set_function(PWM_BL, GPIO_FUNC_PWM); // PWM_BL = GPIO 3, GPIO_FUNC_PWM = GPIO 4
    gpio_set_function(PWM_TR, GPIO_FUNC_PWM); // PWM_BL = GPIO 6, GPIO_FUNC_PWM = GPIO 4
    gpio_set_function(PWM_BR, GPIO_FUNC_PWM); // PWM_BL = GPIO 7, GPIO_FUNC_PWM = GPIO 4

    // Tell GPIO's 4,5 that they allocated to the PWM
    gpio_set_function(27, GPIO_FUNC_PWM);
    gpio_set_function(28, GPIO_FUNC_PWM);

    // Find out which PWM slice is connected to GPIO 5
    slice_num_TL = pwm_gpio_to_slice_num(PWM_TL);
    slice_num_BL = pwm_gpio_to_slice_num(PWM_BL);
    slice_num_TR = pwm_gpio_to_slice_num(PWM_TR);
    slice_num_BR = pwm_gpio_to_slice_num(PWM_BR);
    // From IMU code
    slice_num = pwm_gpio_to_slice_num(28);

    // This section configures the period of the PWM signals
    pwm_set_wrap(slice_num_TL, WRAPVAL);
    pwm_set_clkdiv(slice_num_TL, CLKDIV);

    pwm_set_wrap(slice_num_BL, WRAPVAL);
    pwm_set_clkdiv(slice_num_BL, CLKDIV);

    pwm_set_wrap(slice_num_TR, WRAPVAL);
    pwm_set_clkdiv(slice_num_TR, CLKDIV);

    pwm_set_wrap(slice_num_BR, WRAPVAL);
    pwm_set_clkdiv(slice_num_BR, CLKDIV);

    pwm_set_wrap(slice_num, WRAPVAL);
    pwm_set_clkdiv(slice_num, CLKDIV);

    // Enable IRQ for 1kHz slice
    pwm_clear_irq(slice_num_TL);
    pwm_set_irq_enabled(slice_num_TL, true);

    pwm_clear_irq(slice_num_BL);
    pwm_set_irq_enabled(slice_num_BL, true);

    pwm_clear_irq(slice_num_TR);
    pwm_set_irq_enabled(slice_num_TR, true);

    pwm_clear_irq(slice_num_BR);
    pwm_set_irq_enabled(slice_num_BR, true);

    pwm_clear_irq(slice_num);
    pwm_set_irq_enabled(slice_num, true);

    pwm_set_chan_level(slice_num, PWM_CHAN_B, 0);
    pwm_set_chan_level(slice_num, PWM_CHAN_A, 0);

    //////////////////////////// HANDLE MOTOR & 1kHz ////////////////////////////
    irq_set_exclusive_handler(PWM_IRQ_WRAP, on_pwm_wrap);
    irq_set_enabled(PWM_IRQ_WRAP, true);

    uint32_t mask = (1u << slice_num) | (1u << slice_num_TL) | (1u << slice_num_TR) | (1u << slice_num_BL) | (1u << slice_num_BR);
    pwm_set_mask_enabled(mask);

    // Start core 1
    multicore_reset_core1();
    multicore_launch_core1(core1_entry);

    // Add core 0 threads
    // pt_add_thread(protothread_anim); // REMOVED
    pt_add_thread(protothread_core_0);
    pt_add_thread(protothread_serial);

    // Start scheduling core 0 threads
    pt_schedule_start;
}