// #ifndef ANIMATION_H
// #define ANIMATION_H

// #include "vga16_graphics_v2.h"   // Required for drawPixel(), drawApple(), etc.
// #include <stdlib.h>
// #include <stdio.h>

// // ===============================
// // ===== Fixed-point types ======
// // ===============================
// typedef signed int fix15;
// #define multfix15(a, b) ((fix15)((((signed long long)(a)) * ((signed long long)(b))) >> 15))
// #define float2fix15(a) ((fix15)((a) * 32768.0))
// #define fix2int15(a) ((int)(a >> 15))
// #define int2fix15(a) ((fix15)(a << 15))

// // ===============================
// // ===== Frame timing / gravity ===
// // ===============================
// #define FRAME_RATE 33000
// #define HIT_BOTTOM(b) (b > int2fix15(430))
// extern fix15 gravity;

// // ===============================
// // ===== Slice triggers =========
// // ===============================
// extern volatile int force_slice_vertical;
// extern volatile int force_slice_horizontal;
// extern volatile int force_slice_diag_slash;      // '/'
// extern volatile int force_slice_diag_backslash;  // '\'

// // ===============================
// // ======== Boid struct =========
// // ===============================
// typedef struct {
//     fix15 x, y;
//     fix15 prior_x, prior_y;
//     fix15 vx, vy;
//     int type;        // 0 apple, 1 watermelon, 2 orange
//     int sliced;      // 0 whole, 1 half
//     int half_id;     // 0 left, 1 right, 2 top, 3 bottom, 4 diagA, 5 diagB, 6 backslashA, 7 backslashB
//     fix15 theta;     // rotation angle
//     fix15 omega;     // angular velocity
//     int active;      // 1 on screen, 0 offscreen
// } Boid;

// // ===============================
// // ===== Global boids ============
// // ===============================
// extern Boid boid_main;
// extern Boid boid_halfL;
// extern Boid boid_halfR;
// extern Boid boid_halfTop;
// extern Boid boid_halfBottom;
// extern Boid boid_halfDiagA;
// extern Boid boid_halfDiagB;

// // ===============================
// // ===== Function prototypes =====
// // ===============================

// // ===== Erase / Draw =====
// void eraseBigSquare(short x0, short y0);
// void eraseBoid(Boid *b);
// void drawBoid(Boid *b);

// // ===== Spawn / Slice =====
// void spawnMainFruit(Boid *b);
// void spawnHalvesVertical();
// void spawnHalvesHorizontal();
// void spawnHalvesDiagSlash();
// void spawnHalvesDiagBackslash();

// // ===== Update =====
// void updateBoid(Boid *b);

// // ===== Stats =====
// extern int num_fruit_sliced;
// void drawStats();

// #endif // DRAWFRUITS_BOIDS_H
