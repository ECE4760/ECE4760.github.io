// #include "vga16_graphics_v2.h"
// Standard libs
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
// Pico libs
#include "pico/stdlib.h"
#include "pico/divider.h"
#include "pico/multicore.h"
#include "hardware/pio.h"
#include "hardware/dma.h"
#include "hardware/clocks.h"
#include "hardware/pll.h"

#include "drawfruits.h"

fix15 fix_sin(fix15 a) { return float2fix15(sinf((float)a / 32768.0f)); }
fix15 fix_cos(fix15 a) { return float2fix15(cosf((float)a / 32768.0f)); }

void drawStats()
{
    fillRect(0, 10, 200, 50, BLACK); // increase width for two stats

    setCursor(10, 10);
    setTextColor2(WHITE, BLACK);
    setTextSize(3);
    writeString("Fruits: ");
    char buf[20];
    sprintf(buf, "%u", num_fruit_sliced);
    writeString(buf);

    setCursor(10, 45);
    writeString("Score: ");
    sprintf(buf, "%u", score);
    writeString(buf);

    drawPopups();
}

// ===== Generic ellipse drawing =====
void drawEllipse(short x0, short y0, short rx, short ry, char color)
{
    for (short dy = -ry; dy <= ry; dy++)
    {
        for (short dx = -rx; dx <= rx; dx++)
        {
            if ((dx * dx) * (ry * ry) + (dy * dy) * (rx * rx) <= (rx * rx) * (ry * ry))
            {
                drawPixel(x0 + dx, y0 + dy, color);
            }
        }
    }
}

// ===================================
// ==== ROTATED PIXEL DRAW HELPERS ====
// ===================================
static inline void drawRotatedPixel(short cx, short cy, short dx, short dy, fix15 theta, unsigned char color)
{
    fix15 s = fix_sin(theta);
    fix15 c = fix_cos(theta);

    fix15 rdx = multfix15(int2fix15(dx), c) - multfix15(int2fix15(dy), s);
    fix15 rdy = multfix15(int2fix15(dx), s) + multfix15(int2fix15(dy), c);

    short px = cx + fix2int15(rdx);
    short py = cy + fix2int15(rdy);

    // bounds-check optional (not required if fruit stays inside screen)
    if (px >= 0 && px < 640 && py >= 0 && py < 480)
        drawPixel(px, py, color);
}

static inline void eraseRotatedPixel(short cx, short cy, short dx, short dy, fix15 theta)
{
    drawRotatedPixel(cx, cy, dx, dy, theta, BLACK);
}

// ================================
// ===== ORIGINAL FRUIT DRAW =====
// ================================
// Apple
void drawApple(short x0, short y0)
{
    for (short dy = -40; dy <= 40; dy++)
    {
        short localW = 32 - ((abs(dy) * (32 - 28)) / 40);
        for (short dx = -localW; dx <= localW; dx++)
        {
            if ((dx * dx) * (40 * 40) + (dy * dy) * (localW * localW) <= (40 * 40) * (localW * localW))
                drawPixel(x0 + dx, y0 + dy, RED);
        }
    }
    for (short dy = 0; dy < 22; dy++)
        for (short dx = -3; dx <= 3; dx++)
            drawPixel(x0 + dx, y0 - 45 + dy, DARK_GREEN);
    drawEllipse(x0 + 14, y0 - 38 + 12, 14, 8, MED_GREEN);
}

// Watermelon
void drawWatermelon(short x0, short y0)
{
    // Outer green shell
    for (short dy = 0; dy <= 40; dy++)
        for (short dx = -40; dx <= 40; dx++)
            if ((dx * dx + dy * dy) <= (40 * 40))
                drawPixel(x0 + dx, y0 + dy, MED_GREEN);

    // Inner red flesh
    for (short dy = 0; dy <= 35; dy++)
        for (short dx = -35; dx <= 35; dx++)
            if ((dx * dx + dy * dy) <= (35 * 35))
                drawPixel(x0 + dx, y0 + dy, RED);

    // Seed positions relative to center
    const short seedPos[][2] = {
        {-10, 10}, {10, 10}, {-15, 20}, {15, 20}, {-5, 25}, {5, 25}, {0, 18}};

    for (int i = 0; i < 7; i++)
    {
        short sx = seedPos[i][0];
        short sy = seedPos[i][1];

        // Only draw if inside the red circle
        if ((sx * sx + sy * sy) <= (35 * 35))
        {
            drawPixel(x0 + sx, y0 + sy, BLACK);
            drawPixel(x0 + sx, y0 + sy + 1, BLACK);
            drawPixel(x0 + sx + 1, y0 + sy + 1, BLACK);
        }
    }
}

// Orange
void drawOrange(short x0, short y0)
{
    drawEllipse(x0, y0, 40, 40, ORANGE);
    drawEllipse(x0, y0 - 30, 3, 3, DARK_GREEN);
}

void drawBlueberry(short x0, short y0)
{
    // Outer dark skin
    for (short dy = -40; dy <= 40; dy++)
    {
        for (short dx = -40; dx <= 40; dx++)
        {
            if ((dx * dx + dy * dy) <= 1600) // r = 40
                drawPixel(x0 + dx, y0 + dy, DARK_BLUE);
        }
    }

    // Inner body (slightly lighter)
    for (short dy = -32; dy <= 32; dy++)
    {
        for (short dx = -32; dx <= 32; dx++)
        {
            if ((dx * dx + dy * dy) <= 1024) // r = 32
                drawPixel(x0 + dx, y0 + dy, BLUE);
        }
    }

    // Little blueberry top crown (like the star at the top)
    for (short dy = -40; dy <= -28; dy++)
    {
        for (short dx = -8; dx <= 8; dx++)
        {
            if ((dx * dx + (dy + 34) * (dy + 34)) <= 36) // small bump
                drawPixel(x0 + dx, y0 + dy, DARK_BLUE);
        }
    }

    // Highlight
    drawEllipse(x0 - 12, y0 - 12, 8, 5, LIGHT_BLUE);
}

// =========================================
// ======== SLICED FRUIT DRAWING ===========
// =========================================

// Vertical halves (already used)
void drawAppleHalfLeft(short x0, short y0, fix15 th)
{
    for (short dy = -40; dy <= 40; dy++)
    {
        short localW = 32 - ((abs(dy) * (32 - 28)) / 40);
        for (short dx = -localW; dx <= 0; dx++)
            if ((dx * dx) * (40 * 40) + (dy * dy) * (localW * localW) <= (40 * 40) * (localW * localW))
                drawRotatedPixel(x0, y0, dx, dy, th, RED);
    }
}
void drawAppleHalfRight(short x0, short y0, fix15 th)
{
    for (short dy = -40; dy <= 40; dy++)
    {
        short localW = 32 - ((abs(dy) * (32 - 28)) / 40);
        for (short dx = 0; dx <= localW; dx++)
            if ((dx * dx) * (40 * 40) + (dy * dy) * (localW * localW) <= (40 * 40) * (localW * localW))
                drawRotatedPixel(x0, y0, dx, dy, th, RED);
    }
}

// void drawAppleHalfTop(short x0, short y0, fix15 th)
// {
//     for (short dy = -40; dy <= 0; dy++)
//     {
//         short localW = 32 - ((abs(dy) * (32 - 28)) / 40);
//         for (short dx = -localW; dx <= localW; dx++)
//             if ((dx * dx) * (40 * 40) + (dy * dy) * (localW * localW) <= (40 * 40) * (localW * localW))
//                 drawRotatedPixel(x0, y0, dx, dy, th, RED);
//     }
// }

void drawAppleHalfTop(short x0, short y0, fix15 th)
{
    short pivotY = y0 + 12;

    for (short dy = -40; dy <= 0; dy++)
    {
        short localW = 32 - ((abs(dy) * 4) / 40);
        for (short dx = -localW; dx <= localW; dx++)
            if ((dx * dx) * 1600 + (dy * dy) * (localW * localW) <= 1600 * (localW * localW))
                drawRotatedPixel(x0, pivotY, dx, dy, th, RED);
    }

    // Stem
    for (short dy = 0; dy < 22; dy++)
        for (short dx = -3; dx <= 3; dx++)
            drawRotatedPixel(x0, pivotY, dx, dy - 45, th, DARK_GREEN);

    // Leaf
    for (short dy = -8; dy <= 8; dy++)
        for (short dx = -14; dx <= 14; dx++)
            if ((dx * dx) * 64 + (dy * dy) * 196 <= 64 * 196)
                drawRotatedPixel(x0, pivotY, dx + 14, dy - 26, th, MED_GREEN);
}

// void drawAppleHalfBottom(short x0, short y0, fix15 th)
// {
//     for (short dy = 0; dy <= 40; dy++)
//     {
//         short localW = 32 - ((abs(dy) * (32 - 28)) / 40);
//         for (short dx = -localW; dx <= localW; dx++)
//             if ((dx * dx) * (40 * 40) + (dy * dy) * (localW * localW) <= (40 * 40) * (localW * localW))
//                 drawRotatedPixel(x0, y0, dx, dy, th, RED);
//     }
// }

void drawAppleHalfBottom(short x0, short y0, fix15 th)
{
    short pivotY = y0 - 12;

    for (short dy = 0; dy <= 40; dy++)
    {
        short localW = 32 - ((abs(dy) * 4) / 40);
        for (short dx = -localW; dx <= localW; dx++)
            if ((dx * dx) * 1600 + (dy * dy) * (localW * localW) <= 1600 * (localW * localW))
                drawRotatedPixel(x0, pivotY, dx, dy, th, RED);
    }
}

// Watermelon vertical halves
void drawWatermelonHalfLeft(short x0, short y0, fix15 t)
{
    for (short dy = 0; dy <= 40; dy++)
        for (short dx = -40; dx <= 0; dx++)
            if (dx * dx + dy * dy <= 1600)
                drawRotatedPixel(x0, y0, dx, dy, t, MED_GREEN);
    for (short dy = 0; dy <= 35; dy++)
        for (short dx = -35; dx <= 0; dx++)
            if (dx * dx + dy * dy <= 1225)
                drawRotatedPixel(x0, y0, dx, dy, t, RED);
}
void drawWatermelonHalfRight(short x0, short y0, fix15 t)
{
    for (short dy = 0; dy <= 40; dy++)
        for (short dx = 0; dx <= 40; dx++)
            if (dx * dx + dy * dy <= 1600)
                drawRotatedPixel(x0, y0, dx, dy, t, MED_GREEN);
    for (short dy = 0; dy <= 35; dy++)
        for (short dx = 0; dx <= 35; dx++)
            if (dx * dx + dy * dy <= 1225)
                drawRotatedPixel(x0, y0, dx, dy, t, RED);
}

// Watermelon horizontal halves (top/bottom)
void drawWatermelonHalfTop(short x0, short y0, fix15 t)
{
    for (short dy = -40; dy <= 0; dy++)
        for (short dx = -40; dx <= 40; dx++)
            if (dx * dx + dy * dy <= 1600)
                drawRotatedPixel(x0, y0, dx, dy, t, MED_GREEN);
    for (short dy = -35; dy <= 0; dy++)
        for (short dx = -35; dx <= 35; dx++)
            if (dx * dx + dy * dy <= 1225)
                drawRotatedPixel(x0, y0, dx, dy, t, RED);
}
void drawWatermelonHalfBottom(short x0, short y0, fix15 t)
{
    for (short dy = 0; dy <= 40; dy++)
        for (short dx = -40; dx <= 40; dx++)
            if (dx * dx + dy * dy <= 1600)
                drawRotatedPixel(x0, y0, dx, dy, t, MED_GREEN);
    for (short dy = 0; dy <= 35; dy++)
        for (short dx = -35; dx <= 35; dx++)
            if (dx * dx + dy * dy <= 1225)
                drawRotatedPixel(x0, y0, dx, dy, t, RED);
}

// Orange vertical halves
void drawOrangeHalfLeft(short x0, short y0, fix15 t)
{
    for (short dy = -40; dy <= 40; dy++)
        for (short dx = -40; dx <= 0; dx++)
            if (dx * dx + dy * dy <= 1600)
                drawRotatedPixel(x0, y0, dx, dy, t, ORANGE);
}
void drawOrangeHalfRight(short x0, short y0, fix15 t)
{
    for (short dy = -40; dy <= 40; dy++)
        for (short dx = 0; dx <= 40; dx++)
            if (dx * dx + dy * dy <= 1600)
                drawRotatedPixel(x0, y0, dx, dy, t, ORANGE);
}

void drawOrangeHalfTop(short x0, short y0, fix15 t)
{
    for (short dy = -40; dy <= 0; dy++)
        for (short dx = -40; dx <= 40; dx++)
            if (dx * dx + dy * dy <= 1600)
                drawRotatedPixel(x0, y0, dx, dy, t, ORANGE);
}
void drawOrangeHalfBottom(short x0, short y0, fix15 t)
{
    for (short dy = 0; dy <= 40; dy++)
        for (short dx = -40; dx <= 40; dx++)
            if (dx * dx + dy * dy <= 1600)
                drawRotatedPixel(x0, y0, dx, dy, t, ORANGE);
}

void drawBlueberryHalfLeft(short x0, short y0, fix15 t)
{
    for (short dy = -40; dy <= 40; dy++)
        for (short dx = -40; dx <= 0; dx++)
            if (dx * dx + dy * dy <= 1600)
                drawRotatedPixel(x0, y0, dx, dy, t, DARK_BLUE);

    for (short dy = -32; dy <= 32; dy++)
        for (short dx = -32; dx <= 0; dx++)
            if (dx * dx + dy * dy <= 1024)
                drawRotatedPixel(x0, y0, dx, dy, t, BLUE);
}

void drawBlueberryHalfRight(short x0, short y0, fix15 t)
{
    for (short dy = -40; dy <= 40; dy++)
        for (short dx = 0; dx <= 40; dx++)
            if (dx * dx + dy * dy <= 1600)
                drawRotatedPixel(x0, y0, dx, dy, t, DARK_BLUE);

    for (short dy = -32; dy <= 32; dy++)
        for (short dx = 0; dx <= 32; dx++)
            if (dx * dx + dy * dy <= 1024)
                drawRotatedPixel(x0, y0, dx, dy, t, BLUE);
}

void drawBlueberryHalfTop(short x0, short y0, fix15 t)
{
    for (short dy = -40; dy <= 0; dy++)
        for (short dx = -40; dx <= 40; dx++)
            if (dx * dx + dy * dy <= 1600)
                drawRotatedPixel(x0, y0, dx, dy, t, DARK_BLUE);

    for (short dy = -32; dy <= 0; dy++)
        for (short dx = -32; dx <= 32; dx++)
            if (dx * dx + dy * dy <= 1024)
                drawRotatedPixel(x0, y0, dx, dy, t, BLUE);
}

void drawBlueberryHalfBottom(short x0, short y0, fix15 t)
{
    for (short dy = 0; dy <= 40; dy++)
        for (short dx = -40; dx <= 40; dx++)
            if (dx * dx + dy * dy <= 1600)
                drawRotatedPixel(x0, y0, dx, dy, t, DARK_BLUE);

    for (short dy = 0; dy <= 32; dy++)
        for (short dx = -32; dx <= 32; dx++)
            if (dx * dx + dy * dy <= 1024)
                drawRotatedPixel(x0, y0, dx, dy, t, BLUE);
}

// ================================
// === DIAGONAL (slash/backslash) ===
// ================================

// Apple diagonal halves (slash and backslash)
void drawAppleHalfDiagSlashA(short x0, short y0, fix15 th)
{ // top-left (dx+dy<=0)
    for (short dy = -40; dy <= 40; dy++)
    {
        short localW = 32 - ((abs(dy) * (32 - 28)) / 40);
        for (short dx = -localW; dx <= localW; dx++)
        {
            if ((dx * dx) * (40 * 40) + (dy * dy) * (localW * localW) <= (40 * 40) * (localW * localW))
            {
                if ((dx + dy) <= 0)
                    drawRotatedPixel(x0, y0, dx, dy, th, RED);
            }
        }
    }
}
void drawAppleHalfDiagSlashB(short x0, short y0, fix15 th)
{ // bottom-right (dx+dy>0)
    for (short dy = -40; dy <= 40; dy++)
    {
        short localW = 32 - ((abs(dy) * (32 - 28)) / 40);
        for (short dx = -localW; dx <= localW; dx++)
        {
            if ((dx * dx) * (40 * 40) + (dy * dy) * (localW * localW) <= (40 * 40) * (localW * localW))
            {
                if ((dx + dy) > 0)
                    drawRotatedPixel(x0, y0, dx, dy, th, RED);
            }
        }
    }
}
void drawAppleHalfDiagBackslashA(short x0, short y0, fix15 th)
{ // top-right (dx-dy>0)
    for (short dy = -40; dy <= 40; dy++)
    {
        short localW = 32 - ((abs(dy) * (32 - 28)) / 40);
        for (short dx = -localW; dx <= localW; dx++)
        {
            if ((dx * dx) * (40 * 40) + (dy * dy) * (localW * localW) <= (40 * 40) * (localW * localW))
            {
                if ((dx - dy) > 0)
                    drawRotatedPixel(x0, y0, dx, dy, th, RED);
            }
        }
    }
}
void drawAppleHalfDiagBackslashB(short x0, short y0, fix15 th)
{ // bottom-left (dx-dy<=0)
    for (short dy = -40; dy <= 40; dy++)
    {
        short localW = 32 - ((abs(dy) * (32 - 28)) / 40);
        for (short dx = -localW; dx <= localW; dx++)
        {
            if ((dx * dx) * (40 * 40) + (dy * dy) * (localW * localW) <= (40 * 40) * (localW * localW))
            {
                if ((dx - dy) <= 0)
                    drawRotatedPixel(x0, y0, dx, dy, th, RED);
            }
        }
    }
}

// Watermelon diagonal halves (slash)
void drawWatermelonHalfDiagSlashA(short x0, short y0, fix15 t)
{
    for (short dy = -40; dy <= 40; dy++)
        for (short dx = -40; dx <= 40; dx++)
            if ((dx * dx + dy * dy) <= 1600)
                if ((dx + dy) <= 0)
                    drawRotatedPixel(x0, y0, dx, dy, t, MED_GREEN);
    for (short dy = -35; dy <= 35; dy++)
        for (short dx = -35; dx <= 35; dx++)
            if ((dx * dx + dy * dy) <= 1225)
                if ((dx + dy) <= 0)
                    drawRotatedPixel(x0, y0, dx, dy, t, RED);
}
void drawWatermelonHalfDiagSlashB(short x0, short y0, fix15 t)
{
    for (short dy = -40; dy <= 40; dy++)
        for (short dx = -40; dx <= 40; dx++)
            if ((dx * dx + dy * dy) <= 1600)
                if ((dx + dy) > 0)
                    drawRotatedPixel(x0, y0, dx, dy, t, MED_GREEN);
    for (short dy = -35; dy <= 35; dy++)
        for (short dx = -35; dx <= 35; dx++)
            if ((dx * dx + dy * dy) <= 1225)
                if ((dx + dy) > 0)
                    drawRotatedPixel(x0, y0, dx, dy, t, RED);
}

// Watermelon diagonal (backslash)
void drawWatermelonHalfDiagBackslashA(short x0, short y0, fix15 t)
{
    for (short dy = -40; dy <= 40; dy++)
        for (short dx = -40; dx <= 40; dx++)
            if ((dx * dx + dy * dy) <= 1600)
                if ((dx - dy) > 0)
                    drawRotatedPixel(x0, y0, dx, dy, t, MED_GREEN);
    for (short dy = -35; dy <= 35; dy++)
        for (short dx = -35; dx <= 35; dx++)
            if ((dx * dx + dy * dy) <= 1225)
                if ((dx - dy) > 0)
                    drawRotatedPixel(x0, y0, dx, dy, t, RED);
}
void drawWatermelonHalfDiagBackslashB(short x0, short y0, fix15 t)
{
    for (short dy = -40; dy <= 40; dy++)
        for (short dx = -40; dx <= 40; dx++)
            if ((dx * dx + dy * dy) <= 1600)
                if ((dx - dy) <= 0)
                    drawRotatedPixel(x0, y0, dx, dy, t, MED_GREEN);
    for (short dy = -35; dy <= 35; dy++)
        for (short dx = -35; dx <= 35; dx++)
            if ((dx * dx + dy * dy) <= 1225)
                if ((dx - dy) <= 0)
                    drawRotatedPixel(x0, y0, dx, dy, t, RED);
}

// Orange diagonal halves (use same circles as oranges)
void drawOrangeHalfDiagSlashA(short x0, short y0, fix15 t)
{
    for (short dy = -40; dy <= 40; dy++)
        for (short dx = -40; dx <= 40; dx++)
            if ((dx * dx + dy * dy) <= 1600)
                if ((dx + dy) <= 0)
                    drawRotatedPixel(x0, y0, dx, dy, t, ORANGE);
}
void drawOrangeHalfDiagSlashB(short x0, short y0, fix15 t)
{
    for (short dy = -40; dy <= 40; dy++)
        for (short dx = -40; dx <= 40; dx++)
            if ((dx * dx + dy * dy) <= 1600)
                if ((dx + dy) > 0)
                    drawRotatedPixel(x0, y0, dx, dy, t, ORANGE);
}
void drawOrangeHalfDiagBackslashA(short x0, short y0, fix15 t)
{
    for (short dy = -40; dy <= 40; dy++)
        for (short dx = -40; dx <= 40; dx++)
            if ((dx * dx + dy * dy) <= 1600)
                if ((dx - dy) > 0)
                    drawRotatedPixel(x0, y0, dx, dy, t, ORANGE);
}
void drawOrangeHalfDiagBackslashB(short x0, short y0, fix15 t)
{
    for (short dy = -40; dy <= 40; dy++)
        for (short dx = -40; dx <= 40; dx++)
            if ((dx * dx + dy * dy) <= 1600)
                if ((dx - dy) <= 0)
                    drawRotatedPixel(x0, y0, dx, dy, t, ORANGE);
}

void drawBlueberryHalfDiagSlashA(short x0, short y0, fix15 t)
{
    for (short dy = -40; dy <= 40; dy++)
        for (short dx = -40; dx <= 40; dx++)
            if ((dx * dx + dy * dy) <= 1600 && (dx + dy) <= 0)
                drawRotatedPixel(x0, y0, dx, dy, t, DARK_BLUE);

    for (short dy = -32; dy <= 32; dy++)
        for (short dx = -32; dx <= 32; dx++)
            if ((dx * dx + dy * dy) <= 1024 && (dx + dy) <= 0)
                drawRotatedPixel(x0, y0, dx, dy, t, BLUE);
}

void drawBlueberryHalfDiagSlashB(short x0, short y0, fix15 t)
{
    for (short dy = -40; dy <= 40; dy++)
        for (short dx = -40; dx <= 40; dx++)
            if ((dx * dx + dy * dy) <= 1600 && (dx + dy) > 0)
                drawRotatedPixel(x0, y0, dx, dy, t, DARK_BLUE);

    for (short dy = -32; dy <= 32; dy++)
        for (short dx = -32; dx <= 32; dx++)
            if ((dx * dx + dy * dy) <= 1024 && (dx + dy) > 0)
                drawRotatedPixel(x0, y0, dx, dy, t, BLUE);
}

void drawBlueberryHalfDiagBackslashA(short x0, short y0, fix15 t)
{
    for (short dy = -40; dy <= 40; dy++)
        for (short dx = -40; dx <= 40; dx++)
            if ((dx * dx + dy * dy) <= 1600 && (dx - dy) > 0)
                drawRotatedPixel(x0, y0, dx, dy, t, DARK_BLUE);

    for (short dy = -32; dy <= 32; dy++)
        for (short dx = -32; dx <= 32; dx++)
            if ((dx * dx + dy * dy) <= 1024 && (dx - dy) > 0)
                drawRotatedPixel(x0, y0, dx, dy, t, BLUE);
}

void drawBlueberryHalfDiagBackslashB(short x0, short y0, fix15 t)
{
    for (short dy = -40; dy <= 40; dy++)
        for (short dx = -40; dx <= 40; dx++)
            if ((dx * dx + dy * dy) <= 1600 && (dx - dy) <= 0)
                drawRotatedPixel(x0, y0, dx, dy, t, DARK_BLUE);

    for (short dy = -32; dy <= 32; dy++)
        for (short dx = -32; dx <= 32; dx++)
            if ((dx * dx + dy * dy) <= 1024 && (dx - dy) <= 0)
                drawRotatedPixel(x0, y0, dx, dy, t, BLUE);
}

// ================================
// ===== ERASE + DRAW ROUTINES ====
// ================================
void eraseBigSquare(short x0, short y0)
{
    for (int dy = -60; dy <= 60; dy++)
    {
        for (int dx = -60; dx <= 56; dx++)
        {
            short px = x0 + dx;
            short py = y0 + dy;
            if (px >= 0 && px < 640 && py >= 0 && py < 480)
                drawPixel(px, py, BLACK);
        }
    }
}

void eraseBoid(Boid *b)
{
    if (!b->active)
        return;
    eraseBigSquare(fix2int15(b->prior_x), fix2int15(b->prior_y));
}

void drawBoid(Boid *b)
{
    if (!b->active)
        return;
    short x = fix2int15(b->x);
    short y = fix2int15(b->y);

    if (!b->sliced)
    {
        switch (b->type)
        {
        case 0:
            drawApple(x, y);
            break;
        case 1:
            drawWatermelon(x, y);
            break;
        case 2:
            drawOrange(x, y);
            break;
        case 3:
            drawBlueberry(x, y);
            break;
        }
    }
    else
    {
        // Sliced dispatch
        switch (b->type)
        {
        case 0:
            if (b->half_id == 0)
                drawAppleHalfLeft(x, y, b->theta);
            else if (b->half_id == 1)
                drawAppleHalfRight(x, y, b->theta);
            else if (b->half_id == 2)
                drawAppleHalfTop(x, y, b->theta);
            else if (b->half_id == 3)
                drawAppleHalfBottom(x, y, b->theta);
            else if (b->half_id == 4)
                drawAppleHalfDiagSlashA(x, y, b->theta);
            else if (b->half_id == 5)
                drawAppleHalfDiagSlashB(x, y, b->theta);
            else if (b->half_id == 6)
                drawAppleHalfDiagBackslashA(x, y, b->theta);
            else if (b->half_id == 7)
                drawAppleHalfDiagBackslashB(x, y, b->theta);
            break;
        case 1:
            if (b->half_id == 0)
                drawWatermelonHalfLeft(x, y, b->theta);
            else if (b->half_id == 1)
                drawWatermelonHalfRight(x, y, b->theta);
            else if (b->half_id == 2)
                drawWatermelonHalfTop(x, y, b->theta);
            else if (b->half_id == 3)
                drawWatermelonHalfBottom(x, y, b->theta);
            else if (b->half_id == 4)
                drawWatermelonHalfDiagSlashA(x, y, b->theta);
            else if (b->half_id == 5)
                drawWatermelonHalfDiagSlashB(x, y, b->theta);
            else if (b->half_id == 6)
                drawWatermelonHalfDiagBackslashA(x, y, b->theta);
            else if (b->half_id == 7)
                drawWatermelonHalfDiagBackslashB(x, y, b->theta);
            break;
        case 2:
            if (b->half_id == 0)
                drawOrangeHalfLeft(x, y, b->theta);
            else if (b->half_id == 1)
                drawOrangeHalfRight(x, y, b->theta);
            else if (b->half_id == 2)
                drawOrangeHalfTop(x, y, b->theta);
            else if (b->half_id == 3)
                drawOrangeHalfBottom(x, y, b->theta);
            else if (b->half_id == 4)
                drawOrangeHalfDiagSlashA(x, y, b->theta);
            else if (b->half_id == 5)
                drawOrangeHalfDiagSlashB(x, y, b->theta);
            else if (b->half_id == 6)
                drawOrangeHalfDiagBackslashA(x, y, b->theta);
            else if (b->half_id == 7)
                drawOrangeHalfDiagBackslashB(x, y, b->theta);
            break;
        case 3:
            if (b->half_id == 0)
                drawBlueberryHalfLeft(x, y, b->theta);
            else if (b->half_id == 1)
                drawBlueberryHalfRight(x, y, b->theta);
            else if (b->half_id == 2)
                drawBlueberryHalfTop(x, y, b->theta);
            else if (b->half_id == 3)
                drawBlueberryHalfBottom(x, y, b->theta);
            else if (b->half_id == 4)
                drawBlueberryHalfDiagSlashA(x, y, b->theta);
            else if (b->half_id == 5)
                drawBlueberryHalfDiagSlashB(x, y, b->theta);
            else if (b->half_id == 6)
                drawBlueberryHalfDiagBackslashA(x, y, b->theta);
            else if (b->half_id == 7)
                drawBlueberryHalfDiagBackslashB(x, y, b->theta);
            break;
        }
    }

    b->prior_x = b->x;
    b->prior_y = b->y;
}

// ===============================
// ====  SPAWN / UPDATE CODE  ====
// ===============================
void spawnMainFruit(Boid *b)
{
    b->x = int2fix15(320);
    b->y = int2fix15(0);
    b->prior_x = b->x;
    b->prior_y = b->y;

    b->vx = float2fix15(((rand() % 100) / 100.0) - 0.5);
    b->vy = 0;

    b->theta = 0;
    b->omega = 0;

    b->type = rand() % 4;
    b->sliced = 0;
    b->active = 1;
}

// Vertical (left/right)
void spawnHalvesVertical()
{
    fix15 x = boid_main.x;
    fix15 y = boid_main.y;
    int type = boid_main.type;

    boid_halfL.x = x - int2fix15(10);
    boid_halfL.y = y;
    boid_halfL.vx = boid_main.vx - float2fix15(0.5);
    boid_halfL.vy = boid_main.vy - float2fix15(1.0);
    boid_halfL.type = type;
    boid_halfL.sliced = 1;
    boid_halfL.half_id = 0;
    boid_halfL.theta = 0;
    boid_halfL.omega = float2fix15(0.10);
    boid_halfL.active = 1;

    boid_halfR.x = x + int2fix15(10);
    boid_halfR.y = y;
    boid_halfR.vx = boid_main.vx + float2fix15(0.5);
    boid_halfR.vy = boid_main.vy - float2fix15(1.0);
    boid_halfR.type = type;
    boid_halfR.sliced = 1;
    boid_halfR.half_id = 1;
    boid_halfR.theta = 0;
    boid_halfR.omega = float2fix15(-0.12);
    boid_halfR.active = 1;

    boid_main.active = 0;
}

// Horizontal (top/bottom)
void spawnHalvesHorizontal()
{
    fix15 x = boid_main.x;
    fix15 y = boid_main.y;
    int type = boid_main.type;

    boid_halfTop.x = x;
    boid_halfTop.y = y - int2fix15(10);
    boid_halfTop.vx = boid_main.vx - float2fix15(0.3);
    boid_halfTop.vy = boid_main.vy - float2fix15(1.3);
    boid_halfTop.type = type;
    boid_halfTop.sliced = 1;
    boid_halfTop.half_id = 2;
    boid_halfTop.theta = 0;
    boid_halfTop.omega = float2fix15(0.15);
    boid_halfTop.active = 1;

    boid_halfBottom.x = x;
    boid_halfBottom.y = y + int2fix15(10);
    boid_halfBottom.vx = boid_main.vx + float2fix15(0.3);
    boid_halfBottom.vy = boid_main.vy + float2fix15(0.5);
    boid_halfBottom.type = type;
    boid_halfBottom.sliced = 1;
    boid_halfBottom.half_id = 3;
    boid_halfBottom.theta = 0;
    boid_halfBottom.omega = float2fix15(-0.17);
    boid_halfBottom.active = 1;

    boid_main.active = 0;
}

// Diagonal slash ( / ) -> top-left (A) & bottom-right (B)
void spawnHalvesDiagSlash()
{
    fix15 x = boid_main.x;
    fix15 y = boid_main.y;
    int type = boid_main.type;

    boid_halfDiagA.x = x - int2fix15(6);
    boid_halfDiagA.y = y - int2fix15(6);
    boid_halfDiagA.vx = boid_main.vx - float2fix15(0.4);
    boid_halfDiagA.vy = boid_main.vy - float2fix15(1.0);
    boid_halfDiagA.type = type;
    boid_halfDiagA.sliced = 1;
    boid_halfDiagA.half_id = 4; // diag slash A
    boid_halfDiagA.theta = 0;
    boid_halfDiagA.omega = float2fix15(0.14);
    boid_halfDiagA.active = 1;

    boid_halfDiagB.x = x + int2fix15(6);
    boid_halfDiagB.y = y + int2fix15(6);
    boid_halfDiagB.vx = boid_main.vx + float2fix15(0.4);
    boid_halfDiagB.vy = boid_main.vy - float2fix15(1.0);
    boid_halfDiagB.type = type;
    boid_halfDiagB.sliced = 1;
    boid_halfDiagB.half_id = 5; // diag slash B
    boid_halfDiagB.theta = 0;
    boid_halfDiagB.omega = float2fix15(-0.16);
    boid_halfDiagB.active = 1;

    boid_main.active = 0;
}

// Diagonal backslash ( \ ) -> top-right (A) & bottom-left (B)
void spawnHalvesDiagBackslash()
{
    fix15 x = boid_main.x;
    fix15 y = boid_main.y;
    int type = boid_main.type;

    boid_halfDiagA.x = x + int2fix15(6);
    boid_halfDiagA.y = y - int2fix15(6);
    boid_halfDiagA.vx = boid_main.vx + float2fix15(0.4);
    boid_halfDiagA.vy = boid_main.vy - float2fix15(1.0);
    boid_halfDiagA.type = type;
    boid_halfDiagA.sliced = 1;
    boid_halfDiagA.half_id = 6; // diag backslash A
    boid_halfDiagA.theta = 0;
    boid_halfDiagA.omega = float2fix15(0.14);
    boid_halfDiagA.active = 1;

    boid_halfDiagB.x = x - int2fix15(6);
    boid_halfDiagB.y = y + int2fix15(6);
    boid_halfDiagB.vx = boid_main.vx - float2fix15(0.4);
    boid_halfDiagB.vy = boid_main.vy - float2fix15(1.0);
    boid_halfDiagB.type = type;
    boid_halfDiagB.sliced = 1;
    boid_halfDiagB.half_id = 7; // diag backslash B
    boid_halfDiagB.theta = 0;
    boid_halfDiagB.omega = float2fix15(-0.16);
    boid_halfDiagB.active = 1;

    boid_main.active = 0;
}

void updateBoid(Boid *b)
{
    if (!b->active)
        return;

    b->vy += gravity;
    b->x += b->vx;
    b->y += b->vy;
    b->theta += b->omega;

    if (HIT_BOTTOM(b->y))
    {
        b->active = 0;
        fillRect(240, 360, 150, 110, BLACK);
    }
}

ScorePopup popups[MAX_POPUPS];

void addPopup(int x, int y, int pts)
{
    for (int i = 0; i < MAX_POPUPS; i++)
    {
        if (!popups[i].active)
        {
            popups[i].active = 1;
            popups[i].x = x;
            popups[i].y = y;
            popups[i].points = pts;
            popups[i].life = 20; // 20 frames
            break;
        }
    }
}

void addComboPopup(int x, int y)
{
    for (int i = 0; i < MAX_POPUPS; i++)
    {
        if (!popups[i].active)
        {
            popups[i].active = 1;
            popups[i].x = x;
            popups[i].y = y;
            popups[i].points = -999; // special marker meaning COMBO!
            popups[i].life = 20;
            break;
        }
    }
}

void updatePopups()
{
    for (int i = 0; i < MAX_POPUPS; i++)
    {
        if (popups[i].active)
        {
            popups[i].y -= 1; // float up
            popups[i].life--;
            if (popups[i].life <= 0)
                popups[i].active = 0;
        }
    }
}

void drawPopups()
{
    for (int i = 0; i < MAX_POPUPS; i++)
    {
        if (popups[i].active)
        {
            setCursor(popups[i].x, popups[i].y);
            setTextSize(2);

            if (popups[i].points == -999)
            {
                // COMBO popup
                setTextColor2(YELLOW, BLACK);
                writeString("COMBO!");
            }
            else
            {
                // normal +points popup
                setTextColor2(GREEN, BLACK);
                char buf[8];
                sprintf(buf, "+%d", popups[i].points);
                writeString(buf);
            }
        }
    }
}

int getFruitPoints(int type)
{
    switch (type)
    {
    case 0:
        return 10; // Apple
    case 1:
        return 25; // Watermelon
    case 2:
        return 15; // Orange
    case 3:
        return 5; // Blueberry
    }
    return 0;
}

int getComboBonus(int comboCount)
{
    if (comboCount == 2)
        return 50; // 2 in a row
    if (comboCount == 3)
        return 100; // 3 in a row
    return 0;
}

void drawInstructions()
{
    setCursor(90, 60);
    setTextColor2(DARK_GREEN, BLACK);
    setTextSize(6);
    writeString("Instructions");

    setCursor(40, 150);
    setTextColor2(DARK_GREEN, BLACK);
    setTextSize(3);
    writeString("Slice as many fruit as possible!");

    drawApple(100, 250);
    drawOrange(250, 250);
    drawWatermelon(400, 250);
    drawBlueberry(550, 250);

    setCursor(60, 300);
    setTextColor2(DARK_GREEN, BLACK);
    setTextSize(2);
    writeString("+10 pts");

    setCursor(210, 300);
    setTextColor2(DARK_GREEN, BLACK);
    setTextSize(2);
    writeString("+15 pts");

    setCursor(360, 300);
    setTextColor2(DARK_GREEN, BLACK);
    setTextSize(2);
    writeString("+25 pts");

    setCursor(510, 300);
    setTextColor2(DARK_GREEN, BLACK);
    setTextSize(2);
    writeString("+5 pts");
}

void drawCombos()
{
    setCursor(200, 50);
    setTextColor2(DARK_GREEN, BLACK);
    setTextSize(6);
    writeString("Combos");

    setCursor(40, 110);
    setTextColor2(DARK_GREEN, BLACK);
    setTextSize(3);
    writeString("Slice combos for extra points!");

    drawApple(250, 200);
    drawApple(350, 200);

    setCursor(175, 250);
    setTextColor2(DARK_GREEN, BLACK);
    setTextSize(3);
    writeString("Pair: +50 pts");

    // drawApple(200, 300);
    // drawBlueberry(300, 300);
    // drawApple(400, 300);

    // setCursor(150, 350);
    // setTextColor2(DARK_GREEN, BLACK);
    // setTextSize(3);
    // writeString("Sandwich: +50 pts");
}
