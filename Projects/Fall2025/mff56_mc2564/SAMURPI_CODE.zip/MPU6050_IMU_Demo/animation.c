// #include "drawfruits.h"

// // ===== Fixed-point macros =====
// typedef signed int fix15;
// #define multfix15(a, b) ((fix15)((((signed long long)(a)) * ((signed long long)(b))) >> 15))
// #define float2fix15(a) ((fix15)((a) * 32768.0))
// #define fix2int15(a) ((int)(a >> 15))
// #define int2fix15(a) ((fix15)(a << 15))

// // ===== Frame timing =====
// #define FRAME_RATE 33000
// #define HIT_BOTTOM(b) (b > int2fix15(430))

// // ===== Gravity =====
// fix15 gravity = float2fix15(0.75);

// // ===== Slice triggers (set from serial/IMU) =====
// volatile int force_slice_vertical = 0;
// volatile int force_slice_horizontal = 0;
// volatile int force_slice_diag_slash = 0;     // '/'  -> top-left + bottom-right
// volatile int force_slice_diag_backslash = 0; // '\'  -> top-right + bottom-left

// // ===============================
// // ========  BOID STRUCT  ========
// // ===============================
// typedef struct {
//     fix15 x, y;
//     fix15 prior_x, prior_y;
//     fix15 vx, vy;
//     int type;        // 0 apple, 1 watermelon, 2 orange
//     int sliced;      // 0 whole, 1 is half
//     int half_id;     // 0 left, 1 right, 2 top, 3 bottom, 4 diagA, 5 diagB
//     fix15 theta;     // rotation angle
//     fix15 omega;     // angular velocity
//     int active;      // 1 on screen, 0 offscreen
// } Boid;

// // Single-fruit + halves (we keep several half slots)
// Boid boid_main;
// Boid boid_halfL;
// Boid boid_halfR;
// Boid boid_halfTop;
// Boid boid_halfBottom;
// Boid boid_halfDiagA; // slash or backslash first half
// Boid boid_halfDiagB; // second half

// // ================================
// // ===== ERASE + DRAW ROUTINES ====
// // ================================
// // ===================================================
// //   LARGE ERASE SQUARE — removes ALL leftovers
// // ===================================================
// void eraseBigSquare(short x0, short y0)
// {
//     for (int dy = -55; dy <= 55; dy++) {
//         for (int dx = -55; dx <= 55; dx++) {
//             short px = x0 + dx;
//             short py = y0 + dy;
//             if (px >= 0 && px < 640 && py >= 0 && py < 480)
//                 drawPixel(px, py, BLACK);
//         }
//     }
// }

// void eraseBoid(Boid *b) {
//     if (!b->active) return;
//     short x = fix2int15(b->prior_x);
//     short y = fix2int15(b->prior_y);
//     eraseBigSquare(x, y);
// }

// void drawBoid(Boid *b)
// {
//     if (!b->active) return;

//     short x = fix2int15(b->x);
//     short y = fix2int15(b->y);

//     if (!b->sliced) {
//         switch (b->type) {
//             case 0: drawApple(x,y); break;
//             case 1: drawWatermelon(x,y); break;
//             case 2: drawOrange(x,y); break;
//         }
//     } else {
//         // sliced: dispatch by type and half_id
//         switch (b->type) {
//             case 0: // apple
//                 if (b->half_id == 0) drawAppleHalfLeft(x,y,b->theta);
//                 else if (b->half_id == 1) drawAppleHalfRight(x,y,b->theta);
//                 else if (b->half_id == 2) drawAppleHalfTop(x,y,b->theta);
//                 else if (b->half_id == 3) drawAppleHalfBottom(x,y,b->theta);
//                 else if (b->half_id == 4) { /* top */ drawAppleHalfDiagSlashA(x,y,b->theta); } // reuse diag/top as simple top
//                 else if (b->half_id == 5) { /* bottom */ drawAppleHalfDiagSlashB(x,y,b->theta); } // reuse diag/bottom
//                 else if (b->half_id == 6) drawAppleHalfDiagSlashA(x,y,b->theta); // diag slash A
//                 else if (b->half_id == 7) drawAppleHalfDiagSlashB(x,y,b->theta); // diag slash B
//                 break;

//             case 1: // watermelon
//                 if (b->half_id == 0) drawWatermelonHalfLeft(x,y,b->theta);
//                 else if (b->half_id == 1) drawWatermelonHalfRight(x,y,b->theta);
//                 else if (b->half_id == 2) drawWatermelonHalfTop(x,y,b->theta);
//                 else if (b->half_id == 3) drawWatermelonHalfBottom(x,y,b->theta);
//                 else if (b->half_id == 4) drawWatermelonHalfDiagSlashA(x,y,b->theta);
//                 else if (b->half_id == 5) drawWatermelonHalfDiagSlashB(x,y,b->theta);
//                 else if (b->half_id == 6) drawWatermelonHalfDiagBackslashA(x,y,b->theta);
//                 else if (b->half_id == 7) drawWatermelonHalfDiagBackslashB(x,y,b->theta);
//                 break;

//             case 2: // orange
//                 if (b->half_id == 0) drawOrangeHalfLeft(x,y,b->theta);
//                 else if (b->half_id == 1) drawOrangeHalfRight(x,y,b->theta);
//                 else if (b->half_id == 2) drawOrangeHalfTop(x,y,b->theta);
//                 else if (b->half_id == 3) drawOrangeHalfBottom(x,y,b->theta);
//                 else if (b->half_id == 4) drawOrangeHalfDiagSlashA(x,y,b->theta);
//                 else if (b->half_id == 5) drawOrangeHalfDiagSlashB(x,y,b->theta);
//                 else if (b->half_id == 6) drawOrangeHalfDiagBackslashA(x,y,b->theta);
//                 else if (b->half_id == 7) drawOrangeHalfDiagBackslashB(x,y,b->theta);
//                 break;
//         }
//     }

//     b->prior_x = b->x;
//     b->prior_y = b->y;
// }

// // ===============================
// // ====  SPAWN / UPDATE CODE  ====
// // ===============================
// void spawnMainFruit(Boid *b)
// {
//     b->x = int2fix15(320);
//     b->y = int2fix15(0);
//     b->prior_x = b->x;
//     b->prior_y = b->y;

//     b->vx = float2fix15(((rand()%100)/100.0) - 0.5);
//     b->vy = 0;

//     b->theta = 0;
//     b->omega = 0;

//     b->type = rand() % 3;
//     b->sliced = 0;
//     b->active = 1;
// }

// // Vertical (left/right)
// void spawnHalvesVertical()
// {
//     fix15 x = boid_main.x;
//     fix15 y = boid_main.y;
//     int type = boid_main.type;

//     boid_halfL.x = x - int2fix15(10);
//     boid_halfL.y = y;
//     boid_halfL.vx = boid_main.vx - float2fix15(0.5);
//     boid_halfL.vy = boid_main.vy - float2fix15(1.0);
//     boid_halfL.type = type;
//     boid_halfL.sliced = 1;
//     boid_halfL.half_id = 0;
//     boid_halfL.theta = 0;
//     boid_halfL.omega = float2fix15(0.10);
//     boid_halfL.active = 1;

//     boid_halfR.x = x + int2fix15(10);
//     boid_halfR.y = y;
//     boid_halfR.vx = boid_main.vx + float2fix15(0.5);
//     boid_halfR.vy = boid_main.vy - float2fix15(1.0);
//     boid_halfR.type = type;
//     boid_halfR.sliced = 1;
//     boid_halfR.half_id = 1;
//     boid_halfR.theta = 0;
//     boid_halfR.omega = float2fix15(-0.12);
//     boid_halfR.active = 1;

//     boid_main.active = 0;
// }

// // Horizontal (top/bottom)
// void spawnHalvesHorizontal()
// {
//     fix15 x = boid_main.x;
//     fix15 y = boid_main.y;
//     int type = boid_main.type;

//     boid_halfTop.x = x;
//     boid_halfTop.y = y - int2fix15(10);
//     boid_halfTop.vx = boid_main.vx - float2fix15(0.3);
//     boid_halfTop.vy = boid_main.vy - float2fix15(1.3);
//     boid_halfTop.type = type;
//     boid_halfTop.sliced = 1;
//     boid_halfTop.half_id = 2;
//     boid_halfTop.theta = 0;
//     boid_halfTop.omega = float2fix15(0.15);
//     boid_halfTop.active = 1;

//     boid_halfBottom.x = x;
//     boid_halfBottom.y = y + int2fix15(10);
//     boid_halfBottom.vx = boid_main.vx + float2fix15(0.3);
//     boid_halfBottom.vy = boid_main.vy + float2fix15(0.5);
//     boid_halfBottom.type = type;
//     boid_halfBottom.sliced = 1;
//     boid_halfBottom.half_id = 3;
//     boid_halfBottom.theta = 0;
//     boid_halfBottom.omega = float2fix15(-0.17);
//     boid_halfBottom.active = 1;

//     boid_main.active = 0;
// }

// // Diagonal slash ( / ) -> top-left (A) & bottom-right (B)
// void spawnHalvesDiagSlash()
// {
//     fix15 x = boid_main.x;
//     fix15 y = boid_main.y;
//     int type = boid_main.type;

//     boid_halfDiagA.x = x - int2fix15(6);
//     boid_halfDiagA.y = y - int2fix15(6);
//     boid_halfDiagA.vx = boid_main.vx - float2fix15(0.4);
//     boid_halfDiagA.vy = boid_main.vy - float2fix15(1.0);
//     boid_halfDiagA.type = type;
//     boid_halfDiagA.sliced = 1;
//     boid_halfDiagA.half_id = 4; // diag slash A
//     boid_halfDiagA.theta = 0;
//     boid_halfDiagA.omega = float2fix15(0.14);
//     boid_halfDiagA.active = 1;

//     boid_halfDiagB.x = x + int2fix15(6);
//     boid_halfDiagB.y = y + int2fix15(6);
//     boid_halfDiagB.vx = boid_main.vx + float2fix15(0.4);
//     boid_halfDiagB.vy = boid_main.vy - float2fix15(1.0);
//     boid_halfDiagB.type = type;
//     boid_halfDiagB.sliced = 1;
//     boid_halfDiagB.half_id = 5; // diag slash B
//     boid_halfDiagB.theta = 0;
//     boid_halfDiagB.omega = float2fix15(-0.16);
//     boid_halfDiagB.active = 1;

//     boid_main.active = 0;
// }

// // Diagonal backslash ( \ ) -> top-right (A) & bottom-left (B)
// void spawnHalvesDiagBackslash()
// {
//     fix15 x = boid_main.x;
//     fix15 y = boid_main.y;
//     int type = boid_main.type;

//     boid_halfDiagA.x = x + int2fix15(6);
//     boid_halfDiagA.y = y - int2fix15(6);
//     boid_halfDiagA.vx = boid_main.vx + float2fix15(0.4);
//     boid_halfDiagA.vy = boid_main.vy - float2fix15(1.0);
//     boid_halfDiagA.type = type;
//     boid_halfDiagA.sliced = 1;
//     boid_halfDiagA.half_id = 6; // diag backslash A
//     boid_halfDiagA.theta = 0;
//     boid_halfDiagA.omega = float2fix15(0.14);
//     boid_halfDiagA.active = 1;

//     boid_halfDiagB.x = x - int2fix15(6);
//     boid_halfDiagB.y = y + int2fix15(6);
//     boid_halfDiagB.vx = boid_main.vx - float2fix15(0.4);
//     boid_halfDiagB.vy = boid_main.vy - float2fix15(1.0);
//     boid_halfDiagB.type = type;
//     boid_halfDiagB.sliced = 1;
//     boid_halfDiagB.half_id = 7; // diag backslash B
//     boid_halfDiagB.theta = 0;
//     boid_halfDiagB.omega = float2fix15(-0.16);
//     boid_halfDiagB.active = 1;

//     boid_main.active = 0;
// }

// void updateBoid(Boid *b)
// {
//     if (!b->active) return;

//     b->vy += gravity;
//     b->x += b->vx;
//     b->y += b->vy;
//     b->theta += b->omega;

//     if (HIT_BOTTOM(b->y)){
//       b->active = 0;
//       fillRect(240, 360, 150, 110, BLACK);
//     }
// }

// int num_fruit_sliced = 0;

// void drawStats()
// {
//   fillRect(160, 10, 100, 50, BLACK); 

//   setCursor(10, 10);
//   setTextColor2(WHITE, BLACK);
//   setTextSize(3);
//   writeString("Score: ");

//   char score_text[20] = {0};
//   sprintf(score_text, "%u", num_fruit_sliced); // %u for unsigned int
//   writeString(score_text);
// }