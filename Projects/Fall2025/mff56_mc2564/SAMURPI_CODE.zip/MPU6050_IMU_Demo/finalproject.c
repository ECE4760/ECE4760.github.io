// Include standard libraries
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
// Include PICO libraries
#include "pico/stdlib.h"
#include "pico/multicore.h"
// Include hardware libraries
#include "hardware/pwm.h"
#include "hardware/dma.h"
#include "hardware/irq.h"
#include "hardware/adc.h"
#include "hardware/pio.h"
#include "hardware/i2c.h"
#include "hardware/clocks.h"
// Include custom libraries
#include "vga16_graphics_v2.h"
#include "mpu6050.h"
#include "pt_cornell_rp2040_v1_4.h"
// Final project
#include "REAL_SAMURPI.h"

// hardware location of pushbutton to start demo
#define SWITCH_PIN 28

// Arrays in which raw measurements will be stored
fix15 acceleration[3], gyro[3];

// character array
char screentext[40];

// draw speed
int threshold = 10;

// Debouncing variables
volatile int valid_press = 0;     // Flag set to 1 on a confirmed rising edge
static int last_button_state = 0; // Last confirmed stable state of the button
static int stable_state = 0;      // Current debounced, stable state
static int debounce_counter = 0;  // Count consistent number of reads
const int debounce_threshold = 3; // Number of consistent reads required
int start_routine = 0;

// Some macros for max/min/abs
#define min(a, b) ((a < b) ? a : b)
#define max(a, b) ((a < b) ? b : a)
#define abs(a) ((a > 0) ? a : -a)

// semaphore
static struct pt_sem vga_semaphore;

// Some paramters for PWM
#define WRAPVAL 5000
#define CLKDIV 25.0
uint slice_num_1kHz;

#define PI 3.14159265358979323846

fix15 accel_angle;
fix15 complementary_angle;
fix15 filtered_ax;
fix15 filtered_ay;
fix15 gyro_angle_delta;

#define PWM_OUT_1kHz 4

//--------------------FROM PWM_DEMO.c----------------------
// GPIO we're using for PWM motor
// #define PWM_OUT_motor 4

// PWM duty cycle
volatile int control;
volatile int old_control;
//---------------------------------------------------------

// display and control metrics
int motor_disp = 0;
int theta_desired = 0;
volatile int final_control = 0;

// PID parameters
int Kp_gain = 200;
int Kd_gain = 50;
int Ki_gain = 3;

// solution to only display the stats every x cycles w/ % logic
int stats_idx;

// integral windup threshold
float iw_threshold = 1300;

// Combined ISR for both slices
void on_pwm_wrap_combined()
{
    float instant_error;
    // bug alert: we were previously resetting the sum every time -> need static! (whoops)
    static float sum_error = 0;
    float roc_error;

    // Clear the interrupt flag for this slice
    pwm_clear_irq(slice_num_1kHz);

    // Execute MPU6050 read and VGA signal logic
    mpu6050_read_raw(acceleration, gyro);
    filtered_ax = filtered_ax + ((acceleration[1] - filtered_ax) >> 2);
    filtered_ay = filtered_ay + ((acceleration[2] - filtered_ay) >> 2);

    // Execute Motor update logic
    // Instantaneous error for proportional term
    instant_error = (float)theta_desired - fix2float15(complementary_angle);

    // Sum error for integrator term. Clamp to iw_threshold and 0 to prevent windup
    sum_error += instant_error;
    if (sum_error > iw_threshold)
    {
        sum_error = iw_threshold;
    }
    else if (sum_error < 0)
    {
        sum_error = 0;
    }

    // Rate of change error for derivative term. Can be directly taken from gyro reading
    roc_error = fix2float15(gyro[0]);

    // PID math
    final_control = (int)instant_error * Kp_gain + (int)sum_error * Ki_gain + (int)roc_error * Kd_gain;

    // clamp to what the motor can actually output (no h bridge and 2A current limit)
    if (final_control > 4000)
    {
        final_control = 4000;
    }
    else if (final_control < 0)
    {
        final_control = 0;
    }

    // send the PWM!
    pwm_set_chan_level(slice_num_1kHz, PWM_CHAN_A, final_control);

    // LOW-PASS CODE
    motor_disp = motor_disp + ((final_control - motor_disp) >> 4);

    PT_SEM_SIGNAL(pt, &vga_semaphore);
}

void calculate_angle()
{
    // No small angle approximation
    accel_angle = multfix15(float2fix15(atan2(filtered_ay, filtered_ax)), oneeightyoverpi);

    // Gyro angle delta
    gyro_angle_delta = multfix15(gyro[0], zeropt01);

    // Complementary angle calculation
    complementary_angle = multfix15(complementary_angle - gyro_angle_delta, zeropt99) + multfix15(accel_angle, zeropt01);
    // clamp to 0-180 degrees (don't want negative angles, and can't physically go past 180)
    if (complementary_angle > int2fix15(180))
    {
        complementary_angle = int2fix15(180);
    }
    else if (complementary_angle < int2fix15(0))
    {
        complementary_angle = int2fix15(0);
    }
}

// Thread that draws to VGA display
static PT_THREAD(protothread_vga(struct pt *pt))
{
    // Indicate start of thread
    PT_BEGIN(pt);

    // Draw the static aspects of the display
    setTextSize(1);
    setTextColor(WHITE);

    int start_x = 0;
    int start_y = 0;

    for (int x = 0; x < LOGO_WIDTH; x++){
      for (int y = 0; y < LOGO_HEIGHT; y++){
        if (samurpi_logo[x][y] != 0){
          drawPixel(start_x, start_y, samurpi_logo[x][y]);
        }
      }
    }
    // Indicate end of thread
    PT_END(pt);
  
}

// User input thread. User can change Kp, Ki, Kd, and desired angle via serial terminal
static PT_THREAD(protothread_serial(struct pt *pt))
{
    PT_BEGIN(pt);
    static char classifier;
    static int test_in;
    static float float_in;

    while (1)
    {
        sprintf(pt_serial_out_buffer, "input a command: ");
        serial_write;
        // spawn a thread to do the non-blocking serial read
        serial_read;
        // convert input string to number
        sscanf(pt_serial_in_buffer, "%c", &classifier);

        // check classifier for known inputs
        // Kp gain
        if (classifier == 'p')
        {
            sprintf(pt_serial_out_buffer, "input Kp gain: ");
            serial_write;
            // spawn a thread to do the non-blocking serial read
            serial_read;
            // convert input string to number
            sscanf(pt_serial_in_buffer, "%d", &test_in);
            if (test_in > 1000)
                continue;
            else if (test_in < 0)
                continue;
            else
                Kp_gain = test_in;
        }
        // Ki gain
        else if (classifier == 'i')
        {
            sprintf(pt_serial_out_buffer, "input Ki gain: ");
            serial_write;
            // spawn a thread to do the non-blocking serial read
            serial_read;
            // convert input string to number
            sscanf(pt_serial_in_buffer, "%d", &test_in);
            if (test_in > 1000)
                continue;
            else if (test_in < 0)
                continue;
            else
                Ki_gain = test_in;
        }
        // Kd gain
        else if (classifier == 'd')
        {
            sprintf(pt_serial_out_buffer, "input Kd gain: ");
            serial_write;
            // spawn a thread to do the non-blocking serial read
            serial_read;
            // convert input string to number
            sscanf(pt_serial_in_buffer, "%d", &test_in);
            if (test_in > 1000)
                continue;
            else if (test_in < 0)
                continue;
            else
                Kd_gain = test_in;
        }
        // desired angle
        else if (classifier == 't')
        {
            sprintf(pt_serial_out_buffer, "input theta_desired angle (between 0-180): ");
            serial_write;
            // spawn a thread to do the non-blocking serial read
            serial_read;
            // convert input string to number
            sscanf(pt_serial_in_buffer, "%d", &test_in);
            if (test_in > 1000)
                continue;
            else if (test_in < 0)
                continue;
            else
                theta_desired = test_in;
        }
        else
        {
            continue;
        }
    }
    PT_END(pt);
}

// Protothread for button debouncing
// Runs periodically to check the state of a physical button, filtering out debouncing
static PT_THREAD(protothread_debounce(struct pt *pt))
{
    PT_BEGIN(pt);

    while (1)
    {
        // Read the current button state (active low → 1 when pressed)
        int current_state = !gpio_get(SWITCH_PIN);

        // If the current reading matches the stable state, reset the counter
        if (current_state == stable_state)
        {
            debounce_counter = 0;
        }
        // Otherwise increment the counter and wait til the counter reaches the threshold
        else
        {
            debounce_counter++;
            // If the counter reaches the threshold, the new state is stable
            if (debounce_counter >= debounce_threshold)
            {
                // Set the new stable state and reset the counter
                stable_state = current_state;
                debounce_counter = 0;

                // Detect rising edge on demo start button
                if (stable_state == 1 && last_button_state == 0)
                {
                    valid_press = 1; // Flag the valid button press
                    start_routine = 1;

                    final_control = 1;

                    // set angle, wait, set angle, wait, etc
                    // interrupt will handle motor control
                    theta_desired = 90;
                    PT_YIELD_usec(5e6);

                    theta_desired = 120;
                    PT_YIELD_usec(5e6);

                    theta_desired = 60;
                    PT_YIELD_usec(5e6);

                    theta_desired = 90;
                    PT_YIELD_usec(5e6);
                }
            }

            // Store the current stable state for the next edge detection
            last_button_state = stable_state;
        }
    }
    PT_END(pt);
}

// Entry point for core 1
void core1_entry()
{
    pt_add_thread(protothread_vga);
    pt_schedule_start;
}

int main()
{
    // Overclock
    set_sys_clock_khz(150000, true);

    // Initialize stdio
    stdio_init_all();

    // Initialize VGA
    initVGA();

    ///////////////////////// I2C CONFIGURATION ////////////////////////////
    i2c_init(I2C_CHAN, I2C_BAUD_RATE);
    gpio_set_function(SDA_PIN, GPIO_FUNC_I2C);
    gpio_set_function(SCL_PIN, GPIO_FUNC_I2C);

    // Pullup resistors on breakout board, don't need to turn on internals
    // gpio_pull_up(SDA_PIN) ;
    // gpio_pull_up(SCL_PIN) ;

    // MPU6050 initialization
    mpu6050_reset();
    mpu6050_read_raw(acceleration, gyro);

    //////////////////////////// PWM CONFIGURATION FOR 1KHZ ////////////////////////////
    // Tell GPIO 5 that it is allocated to the PWM
    gpio_set_function(PWM_OUT_1kHz, GPIO_FUNC_PWM);

    // Find out which PWM slice is connected to GPIO 5
    slice_num_1kHz = pwm_gpio_to_slice_num(PWM_OUT_1kHz);

    // This section configures the period of the PWM signals
    pwm_set_wrap(slice_num_1kHz, WRAPVAL);
    pwm_set_clkdiv(slice_num_1kHz, CLKDIV);

    // This sets duty cycle
    // pwm_set_chan_level(slice_num_1kHz, PWM_CHAN_A, 1500);

    // Enable IRQ for 1kHz slice
    pwm_clear_irq(slice_num_1kHz);
    pwm_set_irq_enabled(slice_num_1kHz, true);

    //////////////////////////// HANDLE MOTOR & 1kHz ////////////////////////////
    irq_set_exclusive_handler(PWM_IRQ_WRAP, on_pwm_wrap_combined);
    irq_set_enabled(PWM_IRQ_WRAP, true);

    // Start both channels
    pwm_set_mask_enabled((1u << slice_num_1kHz));

    // Initialize the switch pin
    gpio_init(SWITCH_PIN);
    // Set the switch pin direction to input
    gpio_set_dir(SWITCH_PIN, GPIO_IN);
    // Enable the internal pull-up resistor (required for active-low button)
    gpio_pull_up(SWITCH_PIN);

    // start core 1
    multicore_reset_core1();
    multicore_launch_core1(core1_entry);

    // start core 0
    pt_add_thread(protothread_serial);
    pt_add_thread(protothread_debounce);
    pt_schedule_start;
}