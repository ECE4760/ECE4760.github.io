// picow_udp_beacon_Wand.c
/**
 * Modified Code from V. Hunter Adams (vha3@cornell.edu)
 * 
 * Code for Wand controlling Bipedal Robot
 * IMU Data -> Pico W Calcuations -> Send UDP packet to Robot
 * 
 * HARDWARE CONNECTIONS
 *  - GPIO 8 ---> MPU6050 SDA (BLUE)
 *  - GPIO 9 ---> MPU6050 SCL (YELLOW)
 *  - 3.3v ---> MPU6050 VCC
 *  - RP2040 GND ---> MPU6050 GND
 */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>

#include "pico/stdlib.h"
#include "pico/cyw43_arch.h"
#include "pico/multicore.h"

// Include hardware libraries
#include "hardware/pwm.h"
#include "hardware/dma.h"
#include "hardware/irq.h"
#include "hardware/adc.h"
#include "hardware/pio.h"
#include "hardware/i2c.h"
#include "hardware/clocks.h"

// LWIP
#include "lwip/pbuf.h"
#include "lwip/udp.h"

// WiFi connect helper
// has WIFI_SSID, WIFI_PASSWORD, connectWifi(...)
#include "connect.h"   

#include "mpu6050.h"
#include "pt_cornell_rp2040_v1_4.h"

// Arrays in which raw measurements will be stored
fix15 acceleration[3], gyro[3];

// character array
char screentext[40];

// draw speed - controls how often the VGA display updates
int threshold = 10;

// Some macros for max/min/abs
#define min(a,b) ((a<b) ? a:b)
#define max(a,b) ((a<b) ? b:a)
#define abs(a) ((a>0) ? a:-a)

// semaphore for coordinating between threads
static struct pt_sem vga_semaphore;
static struct pt_sem button_semaphore;

// PWM configuration parameters
#define WRAPVAL 5000  // PWM counter wrap value
#define CLKDIV  25.0  // Clock divider for PWM

// GPIO we're using for PWM
#define PWM_OUT 4

// Variable to hold PWM slice number
uint slice_num;

// Orientation estimation variables
fix15 pitch, yaw, roll;              // Euler angles in degrees
fix15 phi, theta;                    // Spherical coordinates (phi=0 vertically up)

// Low-pass filtered accelerometer readings
static fix15 filtered_ax = 0, filtered_ay = 0, filtered_az = 0;
static fix15 filtered_gx = 0, filtered_gy = 0, filtered_gz = 0;

// Complementary filter coefficients
#define ALPHA float2fix15(0.98)   // Gyro trust factor
#define BETA float2fix15(0.02)    // Accel trust factor

#define PI 3.14159265359
#define RAD_TO_DEG (180.0/PI)
#define DEG_TO_RAD (PI/180.0)

// =====================
// Config
// =====================

// Set this to 1 when building/flashing the *sender* board,
// and to 0 when building/flashing the *receiver* board.
#define IS_SENDER 1

// UDP port that both boards will use
#define UDP_PORT 1234

// On the sender build, set this to the *receiver* Pico W's IP address
// (printed by the receiver when it connects to the hotspot).
#if IS_SENDER
#define RECEIVER_IP "172.20.10.2"   // <-- change this to receiver Pico's IP
#endif

// Global flag to track if UDP should send IMU data
bool send_imu_data = true;

// =====================
// Receiver side
// =====================

#if !IS_SENDER

static struct udp_pcb *rx_pcb;

// Simple receive callback: print whatever we got
static void udp_rx_callback(void *arg,
                            struct udp_pcb *upcb,
                            struct pbuf *p,
                            const ip_addr_t *addr,
                            u16_t port)
{
    LWIP_UNUSED_ARG(arg);
    LWIP_UNUSED_ARG(upcb);
    LWIP_UNUSED_ARG(port);

    if (!p) {
        printf("Received null pbuf\n");
        return;
    }

    // Copy payload into a local buffer so we can print it safely
    char buf[64];
    size_t to_copy = p->len;
    if (to_copy >= sizeof(buf)) {
        to_copy = sizeof(buf) - 1;
    }
    memcpy(buf, p->payload, to_copy);
    buf[to_copy] = '\0';

    printf("From %s:%u -> '%s'\n", ip4addr_ntoa(addr), port, buf);

    // Always free the pbuf when done
    pbuf_free(p);
}

static void udp_receiver_init(void)
{
    rx_pcb = udp_new_ip_type(IPADDR_TYPE_ANY);
    if (!rx_pcb) {
        printf("Failed to create UDP PCB for receiver\n");
        return;
    }

    // Bind to our IP (assigned by DHCP) on UDP_PORT
    err_t err = udp_bind(rx_pcb, netif_ip_addr4(netif_default), UDP_PORT);
    if (err != ERR_OK) {
        printf("udp_bind failed: %d\n", err);
        return;
    }

    // Register receive callback
    udp_recv(rx_pcb, udp_rx_callback, NULL);

    printf("Receiver listening on %s:%d\n",
           ip4addr_ntoa(netif_ip_addr4(netif_default)),
           UDP_PORT);
}

#endif // !IS_SENDER

// =====================
// Sender side
// =====================

#if IS_SENDER

static struct udp_pcb *tx_pcb;
static ip_addr_t dest_addr;

static void udp_sender_init(void)
{
    tx_pcb = udp_new();
    if (!tx_pcb) {
        printf("Failed to create UDP PCB for sender\n");
        return;
    }

    if (!ipaddr_aton(RECEIVER_IP, &dest_addr)) {
        printf("ipaddr_aton failed for '%s'\n", RECEIVER_IP);
        return;
    }

    printf("Sender will send to %s:%d\n", RECEIVER_IP, UDP_PORT);
}

static void udp_send_imu_data(void)
{
    char msg[128];
    int len = snprintf(msg, sizeof(msg), 
                       "Theta:%.1f,Phi:%.1f,Pitch:%.1f,Roll:%.1f,Yaw:%.1f",
                       fix2float15(theta),
                       fix2float15(phi),
                       fix2float15(pitch),
                       fix2float15(roll),
                       fix2float15(yaw));

    // Allocate a pbuf for the payload
    struct pbuf *p = pbuf_alloc(PBUF_TRANSPORT, len + 1, PBUF_RAM);
    if (!p) {
        printf("pbuf_alloc failed\n");
        return;
    }

    memcpy(p->payload, msg, len + 1);

    err_t err = udp_sendto(tx_pcb, p, &dest_addr, UDP_PORT);
    pbuf_free(p);

    if (err == ERR_OK) {
        printf("Sent: %s\n", msg);
    } else {
        printf("udp_sendto error: %d\n", err);
    }
}

static void udp_sender_tick(void)
{
    static uint32_t counter = 0;

    char msg[32];
    int len = snprintf(msg, sizeof(msg), "%lu",
                       (unsigned long)counter++);

    // Allocate a pbuf for the payload
    struct pbuf *p = pbuf_alloc(PBUF_TRANSPORT, len + 1, PBUF_RAM);
    if (!p) {
        printf("pbuf_alloc failed\n");
        return;
    }

    memcpy(p->payload, msg, len + 1);

    err_t err = udp_sendto(tx_pcb, p, &dest_addr, UDP_PORT);
    pbuf_free(p);

    if (err == ERR_OK) {
        printf("Sent counter: %s\n", msg);
    } else {
        printf("udp_sendto error: %d\n", err);
    }
}

#endif // IS_SENDER

// Function to convert accelerometer data to pitch and roll
void calculate_pitch_roll(fix15 ax, fix15 ay, fix15 az, fix15 *pitch_ptr, fix15 *roll_ptr) {
    // Convert to floating point for trig operations
    float ax_f = fix2float15(ax);
    float ay_f = fix2float15(ay);
    float az_f = fix2float15(az);
    
    // Calculate pitch (rotation around Y-axis)
    float pitch_rad = atan2(-ax_f, sqrt(ay_f * ay_f + az_f * az_f));
    
    // Calculate roll (rotation around X-axis)  
    float roll_rad = atan2(ay_f, az_f);
    
    *pitch_ptr = float2fix15(pitch_rad * RAD_TO_DEG);
    *roll_ptr = float2fix15(roll_rad * RAD_TO_DEG);
}

// Function to calculate spherical coordinates (phi, theta) from accelerometer
// phi = 0 when vertically up, ranges [0, 180]
// theta = azimuth angle, ranges [0, 360]
void calculate_spherical_coords(fix15 ax, fix15 ay, fix15 az, fix15 *phi_ptr, fix15 *theta_ptr) {
    float ax_f = fix2float15(ax);
    float ay_f = fix2float15(ay);
    float az_f = fix2float15(az);
    
    // Calculate magnitude
    float magnitude = sqrt(ax_f * ax_f + ay_f * ay_f + az_f * az_f);
    
    if (magnitude > 0.01) {  // Avoid division by zero
        // phi = angle from vertical (y-axis), 0 when pointing up
        // Using standard physics convention: phi from z-axis, theta from x-axis in xy-plane
        // But let's use: phi = angle from vertical (0° = up, 180° = down)
        float phi_rad = (acos(ay_f / magnitude) -  PI) * -1.0;
        
        // theta = azimuth angle in xz plane (0° = forward along z, 90° = right along x)
        float theta_rad = atan2(az_f, ax_f) + 0.5 * PI;
        
        // Convert to degrees and normalize
        *phi_ptr = float2fix15(phi_rad * RAD_TO_DEG);
        
        // Normalize theta to 0-360
        theta_rad = theta_rad * RAD_TO_DEG;
        if (theta_rad < 0) theta_rad += 360;
        *theta_ptr = float2fix15(theta_rad);
      
    } else {
        *phi_ptr = int2fix15(0);
        *theta_ptr = int2fix15(0);
    }
}

// Function to update orientation using complementary filter
void update_orientation() {
    static fix15 last_pitch = 0, last_roll = 0;
    static fix15 last_time = 0;
    fix15 accel_pitch, accel_roll;
    
    // Calculate pitch and roll from accelerometer
    calculate_pitch_roll(filtered_ax, filtered_ay, filtered_az, &accel_pitch, &accel_roll);
    
    // Calculate spherical coordinates
    calculate_spherical_coords(filtered_ax, filtered_ay, filtered_az, &phi, &theta);
    
    // For complementary filter, we need time delta
    // Since we're in an ISR with fixed frequency, assume 1ms = 0.001s
    fix15 dt = float2fix15(0.001); 
    
    // Integrate gyroscope readings (convert to degrees/s and multiply by dt)
    fix15 gyro_pitch_delta = multfix15(filtered_gy, dt);  // Y-axis gyro affects pitch
    fix15 gyro_roll_delta = multfix15(filtered_gx, dt);   // X-axis gyro affects roll
    
    // Apply complementary filter
    pitch = multfix15(ALPHA, (last_pitch + gyro_pitch_delta)) + multfix15(BETA, accel_pitch);
    roll = multfix15(ALPHA, (last_roll + gyro_roll_delta)) + multfix15(BETA, accel_roll);
    
    // Update last values
    last_pitch = pitch;
    last_roll = roll;
    
    // Yaw integration (only from gyro)
    static fix15 yaw_angle = 0;
    fix15 gyro_yaw_delta = multfix15(filtered_gz, dt);    // Z-axis gyro affects yaw
    yaw_angle = yaw_angle + gyro_yaw_delta;
    yaw = yaw_angle;
}

// Interrupt service routine - runs at PWM frequency for precise timing
void on_pwm_wrap() {
    // Clear the interrupt flag that brought us here
    pwm_clear_irq(pwm_gpio_to_slice_num(PWM_OUT));

    // Read the IMU - returns measurements in 15.16 fixed point format
    mpu6050_read_raw(acceleration, gyro);

    // Apply low-pass filter to all sensor readings (simple IIR filter)
    // Shift by 4 = divide by 16, giving alpha ≈ 0.9375
    filtered_ax = filtered_ax + ((acceleration[0] - filtered_ax) >> 4);
    filtered_ay = filtered_ay + ((acceleration[1] - filtered_ay) >> 4);
    filtered_az = filtered_az + ((acceleration[2] - filtered_az) >> 4);
    filtered_gx = filtered_gx + ((gyro[0] - filtered_gx) >> 4);
    filtered_gy = filtered_gy + ((gyro[1] - filtered_gy) >> 4);
    filtered_gz = filtered_gz + ((gyro[2] - filtered_gz) >> 4);
    
    // Update orientation estimates
    update_orientation();
}

// PWM setup function
void setup_pwm_imu(void) {
    // Set up PWM
    gpio_set_function(PWM_OUT, GPIO_FUNC_PWM);
    slice_num = pwm_gpio_to_slice_num(PWM_OUT);
    
    // Set divider and wrap value
    pwm_set_clkdiv(slice_num, CLKDIV);
    pwm_set_wrap(slice_num, WRAPVAL);
    
    // Set duty cycle
    pwm_set_chan_level(slice_num, PWM_CHAN_A, WRAPVAL/2);
    
    // Enable PWM interrupt
    pwm_clear_irq(slice_num);
    pwm_set_irq_enabled(slice_num, true);
    
    // Set up the interrupt handler
    irq_set_exclusive_handler(PWM_IRQ_WRAP, on_pwm_wrap);
    irq_set_enabled(PWM_IRQ_WRAP, true);
    
    // Start PWM
    pwm_set_enabled(slice_num, true);
}

// =====================
// main
// =====================

int main(void)
{
    // Overclock
    set_sys_clock_khz(150000, true);
    stdio_init_all();
    
    // Wait for USB to be ready
    sleep_ms(7500);
    printf("\n=== Pico W UDP Beacon with IMU ===\n");

    ////////////////////////////////////////////////////////////////////////
    ///////////////////////// I2C CONFIGURATION ////////////////////////////
    i2c_init(I2C_CHAN, I2C_BAUD_RATE);
    gpio_set_function(SDA_PIN, GPIO_FUNC_I2C);
    gpio_set_function(SCL_PIN, GPIO_FUNC_I2C);
    
    // Enable internal pull-ups if not using external ones
    gpio_pull_up(SDA_PIN);
    gpio_pull_up(SCL_PIN);

    // MPU6050 initialization
    printf("Initializing MPU6050...\n");
    mpu6050_reset();
    sleep_ms(100);
    
    // Test read
    mpu6050_read_raw(acceleration, gyro);
    printf("Initial IMU read - Accel: %d %d %d, Gyro: %d %d %d\n",
           fix2int15(acceleration[0]), fix2int15(acceleration[1]), fix2int15(acceleration[2]),
           fix2int15(gyro[0]), fix2int15(gyro[1]), fix2int15(gyro[2]));

    // Setup PWM for IMU sampling
    setup_pwm_imu();
    printf("PWM/IMU setup complete\n");

    printf("\n=== Pico W UDP %s ===\n", IS_SENDER ? "SENDER" : "RECEIVER");

    // Connect to WiFi
    printf("Connecting to WiFi...\n");
    if (connectWifi(country, WIFI_SSID, WIFI_PASSWORD, auth)) {
        printf("WiFi connection failed\n");
        while (true) { tight_loop_contents(); }
    }
    printf("WiFi connected\n");

#if IS_SENDER
    udp_sender_init();
#else
    udp_receiver_init();
#endif

    uint32_t last_print_time = 0;
    uint32_t last_send_time = 0;

    // Main loop
    while (true) {
        uint32_t current_time = to_ms_since_boot(get_absolute_time());
        
        // Print IMU data every 500ms
        if (current_time - last_print_time > 500) {
            printf("Theta: %.1f°, Phi: %.1f°, Pitch: %.1f°, Roll: %.1f°, Yaw: %.1f°\n",
                   fix2float15(theta),
                   fix2float15(phi),
                   fix2float15(pitch),
                   fix2float15(roll),
                   fix2float15(yaw));
            last_print_time = current_time;
        }
        
        // Send UDP data every second
        if (current_time - last_send_time > 1000) {
#if IS_SENDER
            if (send_imu_data) {
                udp_send_imu_data();
            } else {
                udp_sender_tick();
            }
#endif
            last_send_time = current_time;
        }
        sleep_ms(10);
    }

    return 0;
}