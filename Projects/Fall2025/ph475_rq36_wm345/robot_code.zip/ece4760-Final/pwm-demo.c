#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>

#include "pico/stdlib.h"
#include "pico/multicore.h"

#include "hardware/pwm.h"
#include "hardware/irq.h"
#include "hardware/spi.h"

// Include headers for Wi-Fi
#include "pt_cornell_rp2040_v1_4.h"
#include "pico/cyw43_arch.h"
#include "lwip/pbuf.h"
#include "lwip/udp.h"
#include "lwip/ip4_addr.h"
#include "connect.h"

// Include headers for robot eyes
#include "pico/rand.h"
#include "MD_MAX72xx.h"
#include "MD_RobotEyes.h"

#define UDP_PORT 1234

// IMU data
typedef struct {
    float theta;    // 0-360
    float phi;      // 0-180, 0 = up
    float pitch;
    float roll;
    float yaw;
    bool valid;
} imu_data_t;

// UDP receiver
static imu_data_t latest_imu_data = {0};
static uint32_t packet_count = 0;
static uint32_t imu_packet_count = 0;
static struct udp_pcb *rx_pcb = NULL;

// Walk state
volatile bool walk_mode = false;

// Servo config
#define SERVO_MIN_US   0u
#define SERVO_MAX_US   3000u
#define PWM_PERIOD     20000u
#define WRAPVAL        (PWM_PERIOD - 1)
#define CLKDIV         125.0f

// Servo IDs
typedef enum {
    LEFT_HIP    = 0,
    LEFT_KNEE   = 1,
    LEFT_ANKLE  = 2,
    RIGHT_HIP   = 3,
    RIGHT_KNEE  = 4,
    RIGHT_ANKLE = 5,
    NUM_SERVOS  = 6
} ServoID;

// Servo pins
const uint servo_pins[NUM_SERVOS] = {
    [LEFT_HIP]    = 12,
    [LEFT_KNEE]   = 11,
    [LEFT_ANKLE]  = 10,
    [RIGHT_HIP]   = 15,
    [RIGHT_KNEE]  = 14,
    [RIGHT_ANKLE] = 13
};

// Store slice and channel for each servo
uint servo_slices[NUM_SERVOS];
uint servo_channels[NUM_SERVOS];

// Control for each servo
volatile int control[NUM_SERVOS];
volatile int old_control[NUM_SERVOS];

// Calibrated mid-points
int mid_point_us[NUM_SERVOS] = {
    [LEFT_HIP]    = 1450,
    [LEFT_KNEE]   = 1350,
    [LEFT_ANKLE]  = 1450,
    [RIGHT_HIP]   = 1450,
    [RIGHT_KNEE]  = 1500,
    [RIGHT_ANKLE] = 1400
};

static const char *servo_names[NUM_SERVOS] = {
    [LEFT_HIP]    = "left_hip",
    [LEFT_KNEE]   = "left_knee",
    [LEFT_ANKLE]  = "left_ankle",
    [RIGHT_HIP]   = "right_hip",
    [RIGHT_KNEE]  = "right_knee",
    [RIGHT_ANKLE] = "right_ankle"
};

// Robot eyes
#define HARDWARE_TYPE PAROLA_HW
#define MAX_DEVICES   2

#define EYES_SPI_PORT spi0
#define EYES_MOSI_PIN 19
#define EYES_CS_PIN   17
#define EYES_CLK_PIN  18

static MD_MAX72XX eyesMatrix;
static MD_RobotEyes eyes;

static const struct {
    MD_RobotEyes_emotion_t e;
    uint16_t duration;  // ms
    bool autoReverse;
    bool startReverse;
} eyeSequence[] = {
    { E_HEART,   3800,  false, false },
    { E_BLINK,   225,   false, false },
    { E_NEUTRAL, 2000,  false, false },
    { E_WINK,    225,   false, false },
    { E_NEUTRAL, 1500,  false, false },
    { E_BLINK,   225,   false, false },
    { E_NEUTRAL, 1000,  false, false },
    { E_SLEEP,  12000,  false, false },
    { E_DEATH,   7000,  false, false },
};

#define NUM_ANIMATIONS (sizeof(eyeSequence) / sizeof(eyeSequence[0]))

// PWM IRQ
void on_pwm_wrap() {
    uint32_t status = pwm_get_irq_status_mask();

    // Clear IRQs for all slices
    if (status & (1u << 5)) {
        pwm_clear_irq(5);
    }
    if (status & (1u << 6)) {
        pwm_clear_irq(6);
    }
    if (status & (1u << 7)) {
        pwm_clear_irq(7);
    }   

    // Update servo positions
    for (int i = 0; i < NUM_SERVOS; i++) {
        if (control[i] != old_control[i]) {
            old_control[i] = control[i];
            pwm_set_chan_level(servo_slices[i], servo_channels[i], (uint16_t)control[i]);
        }
    }
}

// Servo helpers
static void move_all_servos_smooth(const int target[NUM_SERVOS], int duration_ms, int steps)
{
    if (steps <= 0) {
        return;
    }
    if (duration_ms < 0) {
        duration_ms = 0;
    }

    int   start[NUM_SERVOS];
    float delta[NUM_SERVOS];

    // Calculate start positions and deltas
    for (int i = 0; i < NUM_SERVOS; i++) {
        start[i] = control[i];
        delta[i] = (float)(target[i] - start[i]) / (float)steps;
    }

    // Calculate step delay
    int step_delay = duration_ms / steps;
    if (step_delay <= 0) {
        step_delay = 1;
    }

    // Perform the steps
    for (int s = 1; s <= steps; s++) {
        for (int i = 0; i < NUM_SERVOS; i++) {
            int val = (int)(start[i] + delta[i] * s);
            if (val < (int)SERVO_MIN_US) val = SERVO_MIN_US;
            if (val > (int)SERVO_MAX_US) val = SERVO_MAX_US;
            control[i] = val;
        }
        sleep_ms(step_delay);
    }
}

// Change pulse for mirrored joint
static int mirrored_joint_pulse(ServoID sid, int offset)
{
    bool is_left = (sid == LEFT_KNEE) || (sid == LEFT_ANKLE);

    int base = mid_point_us[sid];
    int val = base + (is_left ? offset : -offset);

    if (val < (int)SERVO_MIN_US) {
        val = SERVO_MIN_US;
    }
    if (val > (int)SERVO_MAX_US) {
        val = SERVO_MAX_US;
    }
    return val;
}

// Walk sequence
void walk(void)
{
    // Define PWM values for each pose
    const int KNEE_FWD     = 300;
    const int KNEE_BACK    = -300;
    const int ANKLE_FWD    = 300;
    const int ANKLE_BACK   = -200;

    int pose_neutral[NUM_SERVOS];
    int pose_step1[NUM_SERVOS];
    int pose_mid[NUM_SERVOS];
    int pose_step2[NUM_SERVOS];

    // Initialize all poses to mid-points
    for (int i = 0; i < NUM_SERVOS; i++) {
        pose_neutral[i] = mid_point_us[i];
        pose_step1[i]   = mid_point_us[i];
        pose_mid[i]     = mid_point_us[i];
        pose_step2[i]   = mid_point_us[i];
    }

    pose_neutral[LEFT_HIP]  = mid_point_us[LEFT_HIP];
    pose_neutral[RIGHT_HIP] = mid_point_us[RIGHT_HIP];

    move_all_servos_smooth(pose_neutral, 300, 30);

    pose_step1[RIGHT_KNEE]  = mirrored_joint_pulse(RIGHT_KNEE,  KNEE_FWD);
    pose_step1[RIGHT_ANKLE] = mirrored_joint_pulse(RIGHT_ANKLE, ANKLE_FWD);
    pose_step1[LEFT_KNEE]   = mirrored_joint_pulse(LEFT_KNEE,   KNEE_BACK);
    pose_step1[LEFT_ANKLE]  = mirrored_joint_pulse(LEFT_ANKLE,  ANKLE_BACK);

    move_all_servos_smooth(pose_step1, 500, 50);

    pose_mid[RIGHT_KNEE]  = mirrored_joint_pulse(RIGHT_KNEE,  KNEE_FWD / 2);
    pose_mid[RIGHT_ANKLE] = mirrored_joint_pulse(RIGHT_ANKLE, ANKLE_FWD / 2);
    pose_mid[LEFT_KNEE]   = mirrored_joint_pulse(LEFT_KNEE,   KNEE_BACK / 2);
    pose_mid[LEFT_ANKLE]  = mirrored_joint_pulse(LEFT_ANKLE,  ANKLE_BACK / 2);

    move_all_servos_smooth(pose_mid, 300, 30);

    pose_step2[LEFT_KNEE]   = mirrored_joint_pulse(LEFT_KNEE,   KNEE_FWD);
    pose_step2[LEFT_ANKLE]  = mirrored_joint_pulse(LEFT_ANKLE,  ANKLE_FWD);
    pose_step2[RIGHT_KNEE]  = mirrored_joint_pulse(RIGHT_KNEE,  KNEE_BACK);
    pose_step2[RIGHT_ANKLE] = mirrored_joint_pulse(RIGHT_ANKLE, ANKLE_BACK);

    move_all_servos_smooth(pose_step2, 500, 50);
    move_all_servos_smooth(pose_neutral, 500, 50);
}

// IMU parsing
static bool parse_imu_data(const char *data, imu_data_t *imu_data) {
    imu_data->valid = false;

    char buffer[128];
    if (strlen(data) >= sizeof(buffer)) return false;
    strcpy(buffer, data);

    char *token = strtok(buffer, ",");
    int fields_found = 0;

    while (token != NULL && fields_found < 5) {
        if (strstr(token, "Theta:") == token) {
            imu_data->theta = atof(token + 6);
            fields_found++;
        } 
        else if (strstr(token, "Phi:") == token) {
            imu_data->phi = atof(token + 4);
            fields_found++;
        } 
        else if (strstr(token, "Pitch:") == token) {
            imu_data->pitch = atof(token + 6);
            fields_found++;
        } 
        else if (strstr(token, "Roll:") == token) {
            imu_data->roll = atof(token + 5);
            fields_found++;
        } 
        else if (strstr(token, "Yaw:") == token) {
            imu_data->yaw = atof(token + 4);
            fields_found++;
        }
        token = strtok(NULL, ",");
    }

    if (fields_found == 5) {
        imu_data->valid = true;
        return true;
    }

    char *endptr;
    long value = strtol(data, &endptr, 10);
    if (endptr != data) {
        printf("Received old counter format: %ld\n", value);
    }

    return false;
}

static void print_imu_data(const imu_data_t *imu_data) {
    if (!imu_data->valid) return;

    printf("\nIMU DATA RECEIVED\n");
    printf("Theta: %.2f deg\n", imu_data->theta);
    printf("Phi:   %.2f deg\n", imu_data->phi);
    printf("Pitch: %.2f deg\n", imu_data->pitch);
    printf("Roll:  %.2f deg\n", imu_data->roll);
    printf("Yaw:   %.2f deg\n", imu_data->yaw);

    if (imu_data->phi < 45) {
        printf("Device is pointing UPWARD\n");
    } 
    else if (imu_data->phi > 135) {
        printf("Device is pointing DOWNWARD\n");
    } 
    else {
        printf("Device is HORIZONTAL\n");
    }

    printf("Facing: ");
    if (imu_data->theta >= 337.5 || imu_data->theta < 22.5)
        printf("FORWARD");
    else if (imu_data->theta < 67.5)
        printf("FORWARD-LEFT");
    else if (imu_data->theta < 112.5)
        printf("LEFT");
    else if (imu_data->theta < 157.5)
        printf("BACK-LEFT");
    else if (imu_data->theta < 202.5)
        printf("BACK");
    else if (imu_data->theta < 247.5)
        printf("BACK-RIGHT");
    else if (imu_data->theta < 292.5)
        printf("RIGHT");
    else
        printf("FORWARD-RIGHT");
    printf(" (%.0f deg)\n", imu_data->theta);

    float tilt_magnitude = sqrtf(imu_data->pitch * imu_data->pitch + imu_data->roll  * imu_data->roll);
    printf("Total tilt: %.1f deg\n", tilt_magnitude);
}

// UDP callback
static void udp_rx_callback(void *arg, struct udp_pcb *upcb, struct pbuf *p, const ip_addr_t *addr, u16_t port)
{
    LWIP_UNUSED_ARG(arg);
    LWIP_UNUSED_ARG(upcb);
    LWIP_UNUSED_ARG(port);

    if (!p) return;

    char buf[128];
    size_t to_copy = p->len;
    if (to_copy >= sizeof(buf)) to_copy = sizeof(buf) - 1;
    memcpy(buf, p->payload, to_copy);
    buf[to_copy] = '\0';

    packet_count++;

    printf("[Packet #%lu from %s:%u] '%s'\n", (unsigned long)packet_count, ip4addr_ntoa((const ip4_addr_t *)addr), port, buf);

    // Parse IMU data
    imu_data_t received;
    if (parse_imu_data(buf, &received)) {
        imu_packet_count++;
        latest_imu_data = received;
        printf("IMU packet #%lu\n", (unsigned long)imu_packet_count);
        print_imu_data(&received);

        float phi   = received.phi;
        float theta = received.theta;

        bool is_up = (phi < 45.0f);
        bool is_horizontal = (phi >= 45.0f && phi <= 135.0f);
        bool is_forward = (theta >= 337.5f || theta < 22.5f);

        if (is_horizontal && is_forward) {
            walk_mode = true;
            printf("Walk mode: ON (horizontal + forward)\n");
        } 
        else {
            walk_mode = false;
            if (is_up) {
                printf("Walk mode: OFF (upwards)\n");
            } else {
                printf("Walk mode: OFF (not horizontal+forward)\n");
            }
        }
    } 
    else {
        printf("Raw message (non-IMU): '%s'\n", buf);
        char *endptr = NULL;
        long value = strtol(buf, &endptr, 10);
        if (endptr != buf) {
            printf("Counter value: %ld\n", value);
        }
    }

    pbuf_free(p);
}

static void udp_receiver_init(void)
{
    rx_pcb = udp_new_ip_type(IPADDR_TYPE_ANY);
    if (!rx_pcb) {
        printf("Failed to create UDP PCB\n");
        return;
    }

    err_t err = udp_bind(rx_pcb, netif_ip_addr4(netif_default), UDP_PORT);
    if (err != ERR_OK) {
        printf("udp_bind failed: %d\n", err);
        return;
    }

    udp_recv(rx_pcb, udp_rx_callback, NULL);

    // Print the IP address
    printf("Receiver listening on %s:%d\n", ip4addr_ntoa(netif_ip_addr4(netif_default)), UDP_PORT);
}

static void imu_display_status(void) {
    static uint32_t last_status_time = 0;
    uint32_t now = to_ms_since_boot(get_absolute_time());

    if (now - last_status_time > 5000) {
        printf("\nIMU UDP STATUS\n");
        printf("Total packets received: %lu\n", (unsigned long)packet_count);
        printf("IMU packets received:   %lu\n", (unsigned long)imu_packet_count);
        printf("Last IMU data: ");
        if (latest_imu_data.valid) {
            printf("Theta=%.1f deg, Phi=%.1f deg\n",
                   latest_imu_data.theta,
                   latest_imu_data.phi);
        } else {
            printf("No valid IMU data yet\n");
        }
        last_status_time = now;
    }
}

// UDP protothread on core 0
static PT_THREAD (protothread_udp(struct pt *pt))
{
    PT_BEGIN(pt);

    printf("\nPico W UDP IMU Receiver Thread\n");
    // Connect to Wi-Fi
    int rc = connectWifi(country, WIFI_SSID, WIFI_PASSWORD, auth);
    if (rc) {
        printf("WiFi connection failed (rc=%d)\n", rc);
        while (1) {
            PT_YIELD_usec(1000000);
        }
    }
    printf("WiFi connected!\n");

    udp_receiver_init();
    printf("IMU receiver ready.\n\n");

    while (1) {
        if (walk_mode) {
            printf("walk_mode=ON -> walk()\n");
            walk();
        }
        imu_display_status();
        PT_YIELD_usec(10000);
    }

    PT_END(pt);
}

// Robot eyes helpers
static void reset_all_max72xx(MD_MAX72XX *m) {
    for (uint i = 0; i < MAX_DEVICES; i++) {
        MD_MAX72XX_control(m, i, SHUTDOWN, 1);
        MD_MAX72XX_control(m, i, DISPLAYTEST, 0);
        MD_MAX72XX_control(m, i, SCANLIMIT, 7);
        MD_MAX72XX_control(m, i, DECODEMODE, 0);
        MD_MAX72XX_control(m, i, INTENSITY, 7);
    }
    MD_MAX72XX_clear(m, 0, MAX_DEVICES - 1);
}

static void init_robot_eyes(void) {
    spi_init(EYES_SPI_PORT, 1000000);
    gpio_set_function(EYES_CLK_PIN,  GPIO_FUNC_SPI);
    gpio_set_function(EYES_MOSI_PIN, GPIO_FUNC_SPI);

    gpio_init(EYES_CS_PIN);
    gpio_set_dir(EYES_CS_PIN, GPIO_OUT);
    gpio_put(EYES_CS_PIN, 1);

    printf("Eyes SPI initialized\n");

    MD_MAX72XX_init(&eyesMatrix, HARDWARE_TYPE, EYES_SPI_PORT, EYES_CS_PIN, MAX_DEVICES);
    MD_MAX72XX_begin(&eyesMatrix);
    reset_all_max72xx(&eyesMatrix);

    for (int i = 0; i < MAX_DEVICES; i++) {
        MD_MAX72XX_control(&eyesMatrix, i, SHUTDOWN, 0);
        MD_MAX72XX_control(&eyesMatrix, i, DISPLAYTEST, 0);
        MD_MAX72XX_control(&eyesMatrix, i, SCANLIMIT, 7);
        MD_MAX72XX_control(&eyesMatrix, i, DECODEMODE, 0);
        MD_MAX72XX_clear(&eyesMatrix, i, i);
        MD_MAX72XX_control(&eyesMatrix, i, INTENSITY, 7);
        MD_MAX72XX_control(&eyesMatrix, i, SHUTDOWN, 1);
    }

    printf("MAX72XX for eyes initialized\n");

    MD_RobotEyes_init(&eyes);
    MD_RobotEyes_begin(&eyes, &eyesMatrix, 0);

    MD_RobotEyes_setAutoBlink(&eyes, true);
    MD_RobotEyes_setBlinkTime(&eyes, 3000);

    printf("Robot Eyes initialized\n");
}

// Core 1 main: runs eyes only
void core1_main() {
    init_robot_eyes();

    uint32_t sequenceStartTime = to_ms_since_boot(get_absolute_time());
    uint8_t currentAnimation = 0;

    MD_RobotEyes_setAnimation(&eyes,
                              eyeSequence[currentAnimation].e,
                              eyeSequence[currentAnimation].autoReverse,
                              eyeSequence[currentAnimation].startReverse);

    printf("Core 1: starting eyes animation\n");

    while (1) {
        uint32_t currentTime = to_ms_since_boot(get_absolute_time());
        uint32_t elapsed = currentTime - sequenceStartTime;
        uint16_t animDuration = eyeSequence[currentAnimation].duration;

        if (animDuration > 0 && elapsed >= animDuration) {
            currentAnimation = (currentAnimation + 1) % NUM_ANIMATIONS;
            sequenceStartTime = currentTime;

            MD_RobotEyes_setAnimation(&eyes,
                                      eyeSequence[currentAnimation].e,
                                      eyeSequence[currentAnimation].autoReverse,
                                      eyeSequence[currentAnimation].startReverse);
        }

        MD_RobotEyes_runAnimation(&eyes);
        sleep_ms(1);
    }
}

// Main on core 0
int main() {
    stdio_init_all();
    sleep_ms(2000);

    printf("\n=== PWM_Demo ===\n");

    // Launch eyes on core 1
    multicore_launch_core1(core1_main);

    // Servo init
    uint32_t global_slice_mask = 0;

    for (int i = 0; i < NUM_SERVOS; i++) {
        uint pin = servo_pins[i];
        gpio_set_function(pin, GPIO_FUNC_PWM);

        // Get slice and channel
        uint slice = pwm_gpio_to_slice_num(pin);
        uint chan  = pwm_gpio_to_channel(pin);

        servo_slices[i] = slice;
        servo_channels[i] = chan;

        control[i] = mid_point_us[i];
        old_control[i] = -1;

        global_slice_mask |= (1u << slice);

        pwm_set_wrap(slice, WRAPVAL);
        pwm_set_clkdiv(slice, CLKDIV);
        pwm_set_irq_enabled(slice, true);

        pwm_set_chan_level(slice, chan, mid_point_us[i]);
    }

    // Set up PWM IRQ
    irq_set_exclusive_handler(PWM_IRQ_WRAP, on_pwm_wrap);
    irq_set_enabled(PWM_IRQ_WRAP, true);

    pwm_set_mask_enabled(global_slice_mask);

    // Start protothread scheduler
    pt_sched_method = SCHED_PRIORITY;
    pt_add_thread(protothread_udp);

    printf("Core 0: starting scheduler\n");
    pt_schedule_start;

    return 0;
}
