# PicoMobile - Autonomous Drawing Car

An autonomous drawing car that turns mouse-drawn inputs displayed on a VGA GUI into real-world motion by wirelessly driving a robot car along digitally generated paths.

## Project Overview

This project consists of two main components:

1. **PC Side (`udp_and_vga/`)** - Raspberry Pi Pico W with VGA display and USB host capabilities
   - Displays a VGA GUI for drawing paths with mouse input
   - Captures mouse click coordinates as waypoints
   - Sends waypoint data wirelessly via UDP to the car

2. **Car Side (`car_and_udp/`)** - Raspberry Pi Pico W mounted on the robot car
   - Receives waypoint data via UDP
   - Controls motors to drive the car along the path
   - Uses BNO055 IMU for orientation sensing

## Hardware Requirements

### PC Side (udp_and_vga)
- Raspberry Pi Pico W
- VGA connector and resistor network (see `vga16_graphics.h` for pin connections)
- USB host capability (for mouse input)
- WiFi connection

### Car Side (car_and_udp)
- Raspberry Pi Pico W
- H-bridge motor driver
- Two DC motors
- BNO055 9-DOF IMU sensor (I2C)
- WiFi connection

## Software Dependencies

- Raspberry Pi Pico SDK (v2.2.0 or later)
- lwIP networking stack (included with Pico SDK)
- TinyUSB (for USB host functionality)
- Protothreads library (Cornell RP2040 version)

## Building the Project

### Prerequisites
1. Install the Raspberry Pi Pico SDK following the [official documentation](https://datasheets.raspberrypi.com/pico/getting-started-with-pico.pdf)
2. Set up the Pico C/C++ SDK environment

### Building PC Side
```bash
cd udp_and_vga
mkdir build
cd build
cmake ..
make
```

### Building Car Side
```bash
cd car_and_udp
mkdir build
cd build
cmake ..
make
```

## Configuration

### WiFi Configuration
**Important:** Before building, update the WiFi credentials in the source files:

- `udp_and_vga/picow_udp_send_recv_data.c`: Update `WIFI_SSID` and `WIFI_PASSWORD`
- `car_and_udp/picow_udp_send_recv_data.c`: Update `WIFI_SSID` and `WIFI_PASSWORD`

### Network Configuration
- Default UDP port: 4444
- The PC side automatically discovers and pairs with the car side
- Update IP addresses in the code if using static IPs

## Usage

1. **Flash the firmware:**
   - Flash `udp_and_vga/build/lwip_test.uf2` to the PC-side Pico W
   - Flash `car_and_udp/build/lwip_test.uf2` to the car-side Pico W

2. **Connect hardware:**
   - Connect VGA display to PC-side Pico
   - Connect USB mouse to PC-side Pico
   - Connect motors and IMU to car-side Pico

3. **Operation:**
   - Both devices connect to WiFi automatically
   - PC side displays VGA GUI
   - Left-click on VGA display to set waypoints
   - Right-click to send waypoints to car
   - Car receives waypoints and drives along the path

## Project Structure

```
picomobile/
├── udp_and_vga/          # PC side - VGA display and mouse input
│   ├── picow_udp_send_recv_data.c  # Main UDP communication and mouse handling
│   ├── vga16_graphics.c  # VGA graphics library
│   ├── my_hid_app.c      # USB HID (mouse) handling
│   └── ...
├── car_and_udp/          # Car side - motor control and navigation
│   ├── picow_udp_send_recv_data.c  # Main UDP communication and motor control
│   ├── motors.c           # Motor PWM control (test file)
│   ├── bno055.c           # IMU sensor driver
│   └── ...
├── README.md
└── ATTRIBUTIONS.md       # Third-party code attributions
```

## Features

- **VGA Graphics Display**: 640x480 resolution, 16-color display
- **Mouse Input**: USB HID mouse support for waypoint selection
- **Wireless Communication**: UDP-based communication between PC and car
- **Path Optimization**: Nearest-neighbor and 2-opt algorithms for path optimization
- **Real-time Control**: Protothreads-based multitasking for responsive control

## License

See individual file headers for specific licenses. This project incorporates code from multiple sources with various licenses (BSD-3-Clause, MIT, etc.). See `ATTRIBUTIONS.md` for detailed attribution information.

## Authors

**Sarah Zhong (sjz44)**  
**Gebran Kastoun (glk49)**  
**Ruby Wu (rcw253)**

This project was created in collaboration for ECE 4760, Fall 2025, Cornell University.

## Acknowledgments

This project was created by Sarah Zhong (sjz44), Gebran Kastoun (glk49), and Ruby Wu (rcw253) for ECE 4760, Fall 2025.

The project builds upon and integrates work from:
- Hunter Adams (Cornell) - VGA graphics library
- Bruce Land (BRL4) - Protothreads and VGA modifications
- Andrew McDonnell - UDP networking foundation
- Raspberry Pi Foundation - Pico SDK and examples
- lwIP project - Networking stack
- TinyUSB project - USB host functionality

See `ATTRIBUTIONS.md` for complete list of attributions and licenses.
