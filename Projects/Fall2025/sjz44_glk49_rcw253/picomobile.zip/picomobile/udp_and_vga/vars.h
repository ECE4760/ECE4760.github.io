/**
 * @file vars.h
 * @brief Global variable declarations for HID, video, and UDP communication
 * 
 * ECE 4760 Final Project, Fall 2025
 * Authors: Sarah Zhong (sjz44), Gebran Kastoun (glk49), Ruby Wu (rcw253)
 * Cornell University
 */

// globals for hid and video

// mouse status
extern int mouse_dx, mouse_x, mouse_dy, mouse_y ;
extern int mouse_update ;
extern int mouse_button, mouse_button_update ;
extern char keybd_char ;
extern int keybd_update ;

// UDP status variables (for VGA display)
extern int mode ;
extern int paired ;
extern short data_array[] ;
extern int max_data_size ;
extern int click_count ;
extern int continuously_sending ;
extern int use_optimized_route ;
extern char pairing_status_msg[] ;

// Function to reset waypoint state
void reset_waypoint_state(void) ;
void set_optimization_mode(int enable);
