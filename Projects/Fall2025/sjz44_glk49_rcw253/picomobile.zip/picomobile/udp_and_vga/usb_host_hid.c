/* 
 * The MIT License (MIT)
 *
 * Copyright (c) 2019 Ha Thach (tinyusb.org)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 * 
 * This version converts the demo program to use protothreads 1.3
 * then factors out the reporting from the usb handler and controls
 * the mouse and keyboard disply to VGA
 * The USB task is running as a protothread every 8 mSec to catch mouse events
 * YOu might need ot speed this up for gaming.
 * core 0 is handling USB and blinking an LED
 * core 1 is doing the drawing
 *
 */

#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "vars.h"
#include "bsp/board.h"
#include "tusb.h"

// ==========================================
// === VGA graphics library
// ==========================================
#include "vga16_graphics.h"
#include "pico/stdlib.h"
#include "hardware/pio.h"
#include "hardware/dma.h"

// ==========================================
// === protothreads globals
// ==========================================
#include "hardware/sync.h"
#include "hardware/timer.h"
#include "pico/multicore.h"
#include "string.h"
// protothreads header
#include "pt_cornell_rp2040_v1_1_2.h"
// global vars shared with HID code thru vars.h
int mouse_dx, mouse_x=320, mouse_dy, mouse_y=240 ;
int mouse_update ;
int mouse_button, mouse_button_update ;
char keybd_char ;
int keybd_update ;


//--------------------------------------------------------------------+
// TinyUSB Callbacks
//--------------------------------------------------------------------+

void tuh_mount_cb(uint8_t dev_addr)
{
  // application set-up
  (void) dev_addr;
}

void tuh_umount_cb(uint8_t dev_addr)
{
  // application tear-down
  (void) dev_addr;
}

// ==================================================
// === USB hid thread on core 0
// ==================================================
// handle mouaswe and keybd
PT_THREAD (protothread_hid(struct pt *pt))
{
    PT_BEGIN(pt);
     while (1) {
      // tinyusb host task
      tuh_task();
      // 8 mSec 125 Hz
      PT_YIELD_usec(8000) ;
    }
    PT_END(pt);
}

// ==================================================
// === toggle25 thread on core 0
// ==================================================
// the on-board LED blinks
static PT_THREAD (protothread_toggle25(struct pt *pt))
{
    PT_BEGIN(pt);
    static bool LED_state = false ;
    
     // set up LED p25 to blink
     gpio_init(25) ;	
     gpio_set_dir(25, GPIO_OUT) ;
     gpio_put(25, true);
     // data structure for interval timer
     PT_INTERVAL_INIT() ;

      while(1) {
        // yield time 0.5 second
        //PT_YIELD_usec(100000) ;
        PT_YIELD_INTERVAL(500000) ;

        // toggle the LED on PICO
        LED_state = LED_state? false : true ;
        gpio_put(25, LED_state);
        //
        // NEVER exit while
      } // END WHILE(1)
  PT_END(pt);
} // blink thread

// ===========================================
// Cursor  -- overlay conttol
// ===========================================

short cursor_pixel_x[5], cursor_pixel_y[5] ;


// replace cursor color with saved image colors
void erase_cursor(short x, short y){
    // first the x direction, then y
    for(int i=0; i<5; i++){
        drawPixel(x-2+i, y,  cursor_pixel_x[i]) ;
        drawPixel(x, y-2+i,  cursor_pixel_y[i]) ;
    }
}

// replace image with cursor color and save image pixels
void draw_cursor(short x, short y){
    for(int i=0; i<5; i++){
        cursor_pixel_x[i] = readPixel(x-2+i, y) ;
        cursor_pixel_y[i] = readPixel(x, y-2+i) ;
        drawPixel(x-2+i, y, WHITE) ;
        drawPixel(x, y-2+i, WHITE) ;
    }
}

// ==================================================
// === vga thread on core 1
// ==================================================
//vga display of mouse and keybd 
PT_THREAD (protothread_vga(struct pt *pt))
{
    PT_BEGIN(pt);
    static char video_str[64], mouse_str[10];
    static unsigned char draw_color = GREEN ;
    static int text_x, text_y, begin_text_x ;
    static int prev_mouse_button_vga = 0;  // Track previous button state for edge detection
    static int prev_dot_x = -1, prev_dot_y = -1;  // Track previous dot position for line drawing
    static int has_prev_dot = 0;  // Flag to indicate if we have a previous dot to connect
    static int skip_line_after_toggle = 0;
    const int opt_btn_x = 500;
    const int opt_btn_y = 60;
    const int opt_btn_w = 60;
    const int opt_btn_h = 15;
    static int prev_udp_mode = -1;
    static int prev_paired = -1;
    static int prev_waypoint_count = -1;
    static int prev_mode_title = -1;  // Track mode title state (0=DRAW MODE, 1=FOLLOW MODE)

    // Write some text
    setTextColor(WHITE) ;
    setCursor(65, 20) ;
    setTextSize(1) ;
    writeString("Sarah Zhong") ;
    setCursor(65, 30) ;
    writeString("Ruby Wu") ;
    setCursor(65, 40) ;
    writeString("Gebran Kastoun") ;
    //
    // UDP Status Display
    setCursor(445, 10) ;
    setTextColor(WHITE) ;
    setTextSize(1) ;
    // Include UDP status variables
    extern int mode, paired;
    extern short data_array[];
    extern int use_optimized_route;
    extern char pairing_status_msg[];
    extern int continuously_sending;
    
    // Get waypoint count from data_array[0]
    // Format: [0]=waypoint_count, [1]=robot_x, [2]=robot_y, [3]=wp1_x, [4]=wp1_y, [5]=wp2_x, [6]=wp2_y, ...
    int waypoint_count = (data_array[0] >= 0) ? (int)data_array[0] : 0;
    
    // Display UDP status
    // Clear areas before writing (initial display)
    fillRect(500, 10, 200, 8, BLACK);  // Clear UDP Mode line
    fillRect(490, 20, 200, 8, BLACK);  // Clear Paired line
    fillRect(505, 30, 200, 8, BLACK);  // Clear Waypoints line
    
    setCursor(445, 10) ;
    setTextColor2(WHITE, BLACK) ;
    setTextSize(1) ;
    sprintf(video_str, "UDP Mode: %s", (mode == 1) ? "SEND" : "ECHO");
    writeString(video_str);
    setCursor(445, 20) ;
    sprintf(video_str, "Paired: %s", paired ? "YES" : "NO");
    writeString(video_str);
    setCursor(445, 30) ;
    sprintf(video_str, "Waypoints: %d", waypoint_count);
    writeString(video_str);
    //
    // Display mode title: "DRAW MODE" before first right click, "FOLLOW MODE" after
    setCursor(270, 20) ;
    setTextColor2(WHITE, BLACK) ;
    // Initially show DRAW MODE (continuously_sending will be 0 before first right click)
    int current_mode_title = continuously_sending ? 1 : 0;  // 0=DRAW MODE, 1=FOLLOW MODE
    // Always display on initial setup (prev_mode_title is -1)
    // Clear rectangle width reduced to 150 to avoid overlapping UDP status text at x=445
    fillRect(270, 20, 150, 20, BLACK);
    if (current_mode_title == 0) {
        writeStringBig("DRAW MODE");
    } else {
        writeStringBig("FOLLOW MODE");
    }
    prev_mode_title = current_mode_title;
    setCursor(270, 37) ;
    setTextColor2(WHITE, BLACK) ;
    
    draw_cursor(mouse_x, mouse_y);
    drawRect(15,90,623, 389, WHITE) ;
    setCursor(290, 92) ;
    setTextColor2(WHITE, BLACK) ;
    sprintf(video_str, "%s","Draw Area") ;
    writeStringBold(video_str) ;
    drawHLine(15,100,623, WHITE) ;

     while (1) {
      
      // 30 mSec
      PT_YIELD_usec(30000) ;
      
      // Update UDP status display only when values change to avoid flicker
      int waypoint_count = (data_array[0] >= 0) ? (int)data_array[0] : 0;
      setTextSize(1);
      setTextColor2(WHITE, BLACK);
      if (prev_udp_mode != mode) {
        setCursor(445, 10);
        sprintf(video_str, "UDP Mode: %s  ", (mode == 1) ? "SEND" : "ECHO");
        writeString(video_str);
        prev_udp_mode = mode;
      }
      if (prev_paired != paired) {
        setCursor(445, 20);
        sprintf(video_str, "Paired: %s   ", paired ? "YES" : "NO");
        writeString(video_str);
        prev_paired = paired;
      }
      if (prev_waypoint_count != waypoint_count) {
        setCursor(445, 30);
        sprintf(video_str, "Waypoints: %d   ", waypoint_count);
        writeString(video_str);
        prev_waypoint_count = waypoint_count;
      }
      
      // Update mode title: "DRAW MODE" before first right click, "FOLLOW MODE" after
      int current_mode_title = continuously_sending ? 1 : 0;  // 0=DRAW MODE, 1=FOLLOW MODE
      if (prev_mode_title != current_mode_title) {
        setCursor(270, 20);
        setTextColor2(WHITE, BLACK);
        // Clear the title area before writing
        // Clear rectangle width reduced to 150 to avoid overlapping UDP status text at x=445
        fillRect(270, 20, 150, 20, BLACK);
        if (current_mode_title == 0) {
            writeStringBig("DRAW MODE");
        } else {
            writeStringBig("FOLLOW MODE");
        }
        prev_mode_title = current_mode_title;
      }

      setCursor(20, 60) ;
      setTextColor2(GREEN, BLACK) ;
      sprintf(video_str, "mouse x = %03d   mouse y = %03d", mouse_x, mouse_y) ;
      writeStringBig(video_str) ;
      // Optimized routing toggle indicator
      fillRect(opt_btn_x, opt_btn_y, opt_btn_w, opt_btn_h, BLACK);
      setCursor(opt_btn_x + 4, opt_btn_y + 4);
      setTextColor2(use_optimized_route ? GREEN : RED, BLACK);
      writeStringBold(use_optimized_route ? "opt on" : "opt off");

     // cursor motion update
     if(mouse_update){
      erase_cursor(mouse_x, mouse_y);
      mouse_x += mouse_dx ;
      if (mouse_x < 5) mouse_x = 5;
      if (mouse_x > 635) mouse_x = 635;
      mouse_y += mouse_dy ;
      if (mouse_y < 5) mouse_y = 5;
      if (mouse_y > 475) mouse_y = 475;
      mouse_update = 0 ;
      draw_cursor(mouse_x, mouse_y);
     }

     // mouse buttons
     // left -- draw (only on click, not while held)
     // right -- text instetion point
     // middle -- grab color fro mouse position
     if(mouse_button_update || mouse_button==0){
        const int left_click_edge = ((mouse_button & 1) && !(prev_mouse_button_vga & 1)) ? 1 : 0;
        const int middle_click_edge = ((mouse_button & 4) && !(prev_mouse_button_vga & 4)) ? 1 : 0;
        if (middle_click_edge) {
            int new_mode = !use_optimized_route;
            int turning_off = use_optimized_route && !new_mode;
            set_optimization_mode(new_mode);
            if (turning_off) {
                skip_line_after_toggle = 1;
            }
            sprintf(pairing_status_msg, new_mode ? "Optimized route ON" : "Optimized route OFF");
        }
        // Only draw on edge detection (button just pressed, not held)
        if(left_click_edge) {
          strcpy(mouse_str, "left    ");
          //15,90,623, 389, - rectangle extends from x=15 to x=638 (15+623)
          if(mouse_x>15 && mouse_x<638 && mouse_y>101 && mouse_y<478){
            // Draw a line from previous dot to current dot (if previous dot exists)
            if(has_prev_dot && prev_dot_x >= 0 && prev_dot_y >= 0 && !use_optimized_route) {
              if (skip_line_after_toggle) {
                skip_line_after_toggle = 0;
              } else {
                drawLine(prev_dot_x, prev_dot_y, mouse_x, mouse_y, draw_color);
              }
            }
            int dot_color = use_optimized_route ? RED : draw_color;
            fillCircle(mouse_x, mouse_y, 2, dot_color) ;
            // Update previous dot position for next line
            prev_dot_x = mouse_x;
            prev_dot_y = mouse_y;
            has_prev_dot = 1;  // Now we have a previous dot
            for(int i=0; i<5; i++){
              cursor_pixel_x[i] = dot_color ;
              cursor_pixel_y[i] = dot_color ;
            }  
          }      
        }
        else if(mouse_button & 1) {
          // Button is held but already drew - just update string
          strcpy(mouse_str, "left    ");
        }    
        // 
        else if(mouse_button & 2) {
          strcpy(mouse_str, "right   ");
          // Right click now triggers waypoint sending (handled in mouse_sender thread)
        }
        else if(mouse_button & 4) {
          strcpy(mouse_str, "middle  ");
        }
        //
        else strcpy(mouse_str, "none    ");
        setCursor(20, 75) ;
        setTextColor2(GREEN, BLACK) ;
        sprintf(video_str, "mouse button = %s  ", mouse_str) ;
        writeStringBig(video_str) ;
        prev_mouse_button_vga = mouse_button;  // Update previous state for edge detection
        mouse_button_update = false ;
     } 

    // keyboard event
    if (keybd_update){
      // <enter>
      if(keybd_char == '\r') {
        text_y += 15; 
        text_x = begin_text_x; 
      }
      // delete a char on the same line
      // <backspace>
      else if(keybd_char == '\b') {
        text_x -= 8 ;
        // draw a spacw over the previous char
        drawCharBig(text_x, text_y, 0x20, WHITE, BLACK) ;
      }
      // regular char
      else {
        drawCharBig(text_x, text_y, keybd_char, draw_color, BLACK) ;
        text_x += 8 ; 
      }   
      keybd_update = false ;
    }    
    }
    PT_END(pt);
}

// ========================================
// === core 1 main -- started in main below
// ========================================
void core1_main(){ 
  //
  //  === add threads  ====================
  // for core 1
  pt_add_thread(protothread_vga) ;
  //pt_add_thread(protothread_serial) ;
  //
  // === initalize the scheduler ==========
  pt_schedule_start ;
  // NEVER exits
  // ======================================
}

// ========================================
// === core 0 main - REMOVED
// Main function is now in picow_udp_send_recv_data.c
// ========================================
