# Code Attributions

This document lists all third-party code, libraries, and resources used in this project.

## Project Authors

**Sarah Zhong (sjz44)**  
**Gebran Kastoun (glk49)**  
**Ruby Wu (rcw253)**

ECE 4760 Final Project, Fall 2025, Cornell University

The students integrated, modified, and extended the third-party code listed below to create the PicoMobile autonomous drawing car system. All original copyrights and attributions are preserved in the source files.

## Core Libraries and Frameworks

### Raspberry Pi Pico SDK
- **Source**: Raspberry Pi Foundation
- **License**: BSD-3-Clause
- **Files**: All files using Pico SDK APIs
- **URL**: https://github.com/raspberrypi/pico-sdk
- **Note**: Included via `pico_sdk_import.cmake`

### lwIP (Lightweight IP)
- **Source**: lwIP project
- **License**: BSD-3-Clause
- **Files**: All UDP networking code
- **URL**: https://savannah.nongnu.org/projects/lwip/
- **Note**: Included with Pico SDK

### TinyUSB
- **Source**: Ha Thach (tinyusb.org)
- **License**: MIT License
- **Files**: 
  - `usb_host_hid.c`
  - `cdc_app.c`
  - `msc_app.c`
  - `my_hid_app.c`
  - `tusb_config.h`
- **URL**: https://github.com/hathach/tinyusb
- **Copyright**: Copyright (c) 2019-2022 Ha Thach

## Protothreads

### Cornell RP2040 Protothreads
- **Author**: Bruce Land (BRL4)
- **Based on**: Original Protothreads by Adam Dunkels
- **License**: BSD-3-Clause (Protothreads), Additional contributions
- **Files**: 
  - `pt_cornell_rp2040_v1_1_2.h`
  - `pt_cornell_rp2040_v1_3.h`
- **Original Protothreads**: 
  - Copyright (c) 2004-2005, Swedish Institute of Computer Science
  - Author: Adam Dunkels <adam@sics.se>
- **URL**: https://dunkels.com/adam/pt/

## VGA Graphics Library

### VGA16 Graphics
- **Original Author**: Hunter Adams (vha3@cornell.edu)
- **Modifications**: BRL4 (Bruce Land) - 16 color support
- **Files**: 
  - `vga16_graphics.c`
  - `vga16_graphics.h`
  - `hsync.pio`
  - `vsync.pio`
  - `rgb.pio`
- **Note**: Based on PIC32 display primitives by Bruce Land and students

## UDP Networking Code

### UDP Send/Receive Implementation
- **Original Copyright**: Copyright (c) 2022 Andrew McDonnell
- **License**: BSD-3-Clause
- **Based on**: 
  - Copyright (c) 2016 Stephan Linz <linz@li-pro.net>, Li-Pro.Net
  - Examples by Iwan Budi Kusnanto and Juri Haberland
- **Files**: 
  - `picow_udp_send_recv_data.c` (both directories)
  - `udpecho_raw.h`
- **Additional Sources**:
  - Raspberry Pi Pico examples: https://github.com/raspberrypi/pico-examples/tree/master/pico_w/wifi/udp_beacon
  - lwIP contrib apps: https://github.com/lwip-tcpip/lwip/tree/master/contrib/apps
- **Credits**: Adam Dunkels and lwIP maintainers

## Fonts and Graphics Assets

### GLCD Font
- **Source**: Adafruit GFX Library (or similar)
- **Files**: `glcdfont.c`
- **Note**: Standard 5x7 pixel font for text rendering

### Font ROM
- **Author**: BRL4 (Bruce Land)
- **Files**: `font_rom_brl4.h`

## Sensor Drivers

### BNO055 Driver
- **Implementation**: Custom implementation based on BNO055 datasheet
- **Files**: 
  - `bno055.c`
  - `bno055.h`
- **Note**: Register map and initialization based on Bosch BNO055 datasheet
- **Fixed-point arithmetic**: Based on Hunter Adams' MPU6050 implementation style

## Motor Control

### PWM Motor Control
- **Implementation**: Custom implementation using Pico SDK PWM
- **Files**: `motors.c` (test/demo file)
- **Note**: Main motor control integrated into `picow_udp_send_recv_data.c`

## Build System

### CMake Configuration
- **Pico SDK Import**: Copyright 2020 (c) 2020 Raspberry Pi (Trading) Ltd.
- **License**: BSD-3-Clause
- **Files**: `pico_sdk_import.cmake`

## Additional Notes

### Code Modifications
- All third-party code has been modified and adapted for this project
- Modifications include:
  - Integration of UDP communication with VGA display
  - Mouse input handling for waypoint selection
  - Path optimization algorithms (nearest-neighbor, 2-opt)
  - Motor control integration
  - IMU sensor integration

### License Compliance
- All source files retain their original copyright notices where applicable
- This project complies with the terms of all included licenses
- When redistributing, ensure all license requirements are met

## References

- Raspberry Pi Pico C/C++ SDK Documentation: https://datasheets.raspberrypi.com/pico/raspberry-pi-pico-c-sdk.pdf
- lwIP Documentation: https://www.nongnu.org/lwip/2_1_x/index.html
- TinyUSB Documentation: https://docs.tinyusb.org/
- Protothreads Documentation: https://dunkels.com/adam/pt/
- BNO055 Datasheet: Bosch Sensortec
