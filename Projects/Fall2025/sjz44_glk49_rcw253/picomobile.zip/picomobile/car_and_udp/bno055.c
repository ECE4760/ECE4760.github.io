/**
 * @file bno055.c
 * @brief Implementation of BNO055 9-DOF IMU sensor driver
 * 
 * Provides functions to initialize and read data from the Bosch BNO055
 * sensor. The sensor provides fused orientation data and raw accelerometer/
 * gyroscope readings via I2C communication.
 * 
 * Based on BNO055 datasheet and register map documentation.
 * Uses fixed-point arithmetic (15.16 format) for efficient computation.
 * 
 * ECE 4760 Final Project, Fall 2025
 * Authors: Sarah Zhong (sjz44), Gebran Kastoun (glk49), Ruby Wu (rcw253)
 * Cornell University
 */

#include "bno055.h"

// Helper I2C write: write a register + value
static void bno_write_reg(uint8_t reg, uint8_t value) {
    uint8_t buf[2] = { reg, value };
    i2c_write_blocking(I2C_CHAN, BNO055_ADDR, buf, 2, false);
}

// Helper I2C: read len bytes starting at reg
static void bno_read_len(uint8_t reg, uint8_t *buf, uint8_t len) {
    i2c_write_blocking(I2C_CHAN, BNO055_ADDR, &reg, 1, true);
    i2c_read_blocking(I2C_CHAN, BNO055_ADDR, buf, len, false);
}

void bno055_init(void)
{
    // I2C init + pins are done in main(), we only configure the chip here

    sleep_ms(500);  // give BNO time to boot

    // Optional: read chip ID at 0x00 (0xA0 expected)
    uint8_t id;
    bno_read_len(0x00, &id, 1);
    // you could check id == 0xA0 here if you want

    // Use internal oscillator / normal settings based on the code you found
    // SYS_TRIGGER (0x3F): 0x40 = internal oscillator
    bno_write_reg(0x3F, 0x40);

    // Power mode = normal (PWR_MODE = 0x3E)
    bno_write_reg(0x3E, 0x00);
    sleep_ms(50);

    // Default Axis configuration (AXIS_MAP_CONFIG = 0x41)
    bno_write_reg(0x41, 0x24);

    // Default Axis signs (AXIS_MAP_SIGN = 0x42)
    bno_write_reg(0x42, 0x00);

    // UNIT_SEL (0x3B) from Aryan’s code: 0b00001000 => m/s^2 for accel
    // bits: [7:4]=0, bit3=acc unit 1=m/s^2, bit2=euler unit, bit1=gyro unit, bit0=temp unit
    bno_write_reg(0x3B, 0b00001000);
    sleep_ms(30);

    // Operation mode: they used 0x03 (IMU) but you probably want full fusion NDOF = 0x0C.
    // You can swap this back to 0x03 if you want IMU mode only.
    bno_write_reg(0x3D, 0x0C); // NDOF fusion
    sleep_ms(100);
}

// Read linear accel (m/s^2) and gyro (deg/s) in float, then convert to fixed point
void bno055_read_raw(fix15 accel[3], fix15 gyro[3])
{
    // ==== ACCEL ====
    uint8_t accel_raw[6];
    uint8_t reg = 0x08; // ACC_DATA_X_LSB
    bno_read_len(reg, accel_raw, 6);

    int16_t ax_raw = (int16_t)((accel_raw[1] << 8) | accel_raw[0]);
    int16_t ay_raw = (int16_t)((accel_raw[3] << 8) | accel_raw[2]);
    int16_t az_raw = (int16_t)((accel_raw[5] << 8) | accel_raw[4]);

    // Aryan’s code: accel_x = raw / 100.0;  // m/s^2
    float ax = ax_raw / 100.0f;
    float ay = ay_raw / 100.0f;
    float az = az_raw / 100.0f;

    accel[0] = float2fix15(ax);
    accel[1] = float2fix15(ay);
    accel[2] = float2fix15(az);

    // ==== GYRO ====
    uint8_t gyro_raw[6];
    reg = 0x14; // GYR_DATA_X_LSB
    bno_read_len(reg, gyro_raw, 6);

    int16_t gx_raw = (int16_t)((gyro_raw[1] << 8) | gyro_raw[0]);
    int16_t gy_raw = (int16_t)((gyro_raw[3] << 8) | gyro_raw[2]);
    int16_t gz_raw = (int16_t)((gyro_raw[5] << 8) | gyro_raw[4]);

    // Aryan’s code: deg/s = raw / 16.0, then * DEG_TO_RAD
    // For consistency with your MPU code which uses deg/s, we’ll keep deg/s.
    float gx = gx_raw / 16.0f;
    float gy = gy_raw / 16.0f;
    float gz = gz_raw / 16.0f;

    gyro[0] = float2fix15(gx);
    gyro[1] = float2fix15(gy);
    gyro[2] = float2fix15(gz);
}

// Optional: read fused Euler angles in degrees
void bno055_read_euler(fix15 euler[3])
{
    uint8_t buf[6];
    uint8_t reg = 0x1A; // EUL_HEADING_LSB
    bno_read_len(reg, buf, 6);

    int16_t h_raw = (int16_t)((buf[1] << 8) | buf[0]);
    int16_t r_raw = (int16_t)((buf[3] << 8) | buf[2]);
    int16_t p_raw = (int16_t)((buf[5] << 8) | buf[4]);

    float heading = h_raw / 16.0f;  // deg
    float roll    = r_raw / 16.0f;
    float pitch   = p_raw / 16.0f;

    euler[0] = float2fix15(heading);
    euler[1] = float2fix15(roll);
    euler[2] = float2fix15(pitch);
}
