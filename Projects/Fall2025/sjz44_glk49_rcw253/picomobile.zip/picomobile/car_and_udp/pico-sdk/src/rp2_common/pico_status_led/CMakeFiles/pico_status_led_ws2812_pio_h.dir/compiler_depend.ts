# CMAKE generated file: DO NOT EDIT!
# Timestamp file for custom commands dependencies management for pico_status_led_ws2812_pio_h.
