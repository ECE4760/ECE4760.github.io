/**
 * Copyright (c) 2022 Andrew McDonnell
 *
 * SPDX-License-Identifier: BSD-3-Clause
 * 
 * Modified and extended for ECE 4760 Final Project, Fall 2025
 * Authors: Sarah Zhong (sjz44), Gebran Kastoun (glk49), Ruby Wu (rcw253)
 * Cornell University
 *
 */
/*
 * UDP sned/receive Adapted from:
 ** Copyright (c) 2016 Stephan Linz <linz@li-pro.net>, Li-Pro.Net
 * All rights reserved.
 *
 * Based on examples provided by
 * Iwan Budi Kusnanto <ibk@labhijau.net> (htsettps://gist.github.com/iwanbk/1399729)
 * Juri Haberland <juri@sapienti-sat.org> (https://lists.gnu.org/archive/html/lwip-users/2007-06/msg00078.html)
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 * 3. The name of the author may not be used to endorse or promote products
 *    derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT
 * SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT
 * OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING
 * IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY
 * OF SUCH DAMAGE.
 *
 * This file is part of and a contribution to the lwIP TCP/IP stack.
 *
 * Credits go to Adam Dunkels (and the current maintainers) of this software.
 *
 * Stephan Linz rewrote this file to get a basic echo example.
 * 
 * =============================================================
 * UDP send/recv code is from :
 * Pico examples  
 * https://github.com/raspberrypi/pico-examples/tree/master/pico_w/wifi/udp_beacon
 * lwip contrib apps 
 * https://github.com/lwip-tcpip/lwip/tree/master/contrib/apps
 * UDP send/recv on Windows is from:
 * Microsoft 
 * https://apps.microsoft.com/store/detail/udp-senderreciever/9NBLGGH52BT0?hl=en-us&gl=us
 * a bare-bones packet whacker
 * =============================================================
 * Threads:
 * -- udp send
 * -- udp recv
 * -- blink cyw43 LED
 * -- serial for debug, set the mode to 'send, echo' and set blink time in 'send' mode
 * figure out addresses
 * -- pico discovery:
 *      in send mode: broadcast sender's IP address. format IP xxx.xxx.xxx.xxx
 *      pico in echo mode: sees braodcast and sends it's IP address back to sender's IP addr
 */

// Include standard libraries
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <stdint.h>

// Include hardware libraries
#include <pico/multicore.h>
#include "hardware/sync.h"
#include "hardware/gpio.h"
#include "hardware/timer.h"
#include "hardware/pwm.h"

// Include PICO libraries
#include "pico/stdlib.h"
#include "pico/cyw43_arch.h"
#include "pico/multicore.h"

#include "lwip/pbuf.h"
#include "lwip/udp.h"
#include "lwip/opt.h"
#include "lwip/debug.h"
#include "lwip/stats.h"
#include "lwip/dns.h"
#include "lwip/netif.h"

// Include custom libraries
#include "bno055.h"
#include "pt_cornell_rp2040_v1_1_2.h"

// ======================================
// udp constants
#define UDP_PORT 4444
#define UDP_MSG_LEN_MAX 1024
#define UDP_TARGET_DESK "192.168.1.9" //desktop
#define UDP_TARGET_BROADCAST "10.49.243.194"
//#define UDP_INTERVAL_MS 10 // not used
// should resolve to a actual addr after pairing
char udp_target_pico[20] =  "10.49.243.194" ;

// choose appropriate packet length
enum packet_lengths {command, ack, data} packet_length = command ;

// =======================================
// WiFi Configuration
// TODO: Update these credentials before building/deploying
// For production use, consider using CMake variables or a config file
#define WIFI_SSID "sarahphone"
#define WIFI_PASSWORD "daniel1234"

// =======================================
// protothreads and thread communication
// #include "pt_cornell_rp2040_v1_1_2.h"
char recv_data[UDP_MSG_LEN_MAX];
char send_data[UDP_MSG_LEN_MAX];

// payload to led blink
// or send to remote system
int blink_time, remote_blink_time ;
// interthread communicaition
// signal threads for sned/recv data
struct pt_sem new_udp_recv_s, new_udp_send_s ;
// mode: send/echo
// send mode is in chage here, defined by seril input
// both units default to echo
#define echo 0
#define send 1
int mode = echo ;
// did the addresses get set up?
int paired = false ;
// data to send over WIFI
#define max_data_size  512 
int data_size = 512;
short data_array[max_data_size] =
    {
    // // robot start pose: (y, x)
    // 0, 0,
    // // Square corners (y,x pairs): (0,50), (50,50), (50,0), (0,0) repeated to 10 entries
    // 0, 50,
    // 50, 50,
    // 50, 0,
    // 0, 0,
    // 0, 50,
    // 50, 50,
    // 50, 0,
    // 0, 0,
    // 0, 50,
    // terminator
    -1, -1,
    // remaining slots zeroed
    0
    };
// the following MUST be less than or equal to:
// UDP_MSG_LEN_MAX
// but for efficiency, not much smaller
#define send_data_size data_size*sizeof(short)
//record time for packet speed determination
uint64_t time1;


//==================================================
//================= PWM setup ======================
//==================================================

// Array with raw measurments
fix15 acceleration[3], gyro[3], euler[3] ;

// PWM parameters
#define WRAPVAL 5000
#define CLKDIV  25.0
uint slice_fwd; // slice for 16/17
uint slice_rev; // slice for 6/7

// PWM pins
#define PWM_LEFT_FWD    16   // robot forward (H-bridge "backward")
#define PWM_RIGHT_FWD   17   // robot forward
#define PWM_RIGHT_REV   6    // robot backward
#define PWM_LEFT_REV    7    // robot backward
// Movement Declarations

#define NUM_WAYPOINTS 20
int current_waypoint = 0;

// float atan2_array[NUM_WAYPOINTS];
// float current_angle_array[NUM_WAYPOINTS];

float initial;

// Struct definitions
typedef struct {
    float x;
    float y;
} waypoint_t;

typedef struct {
    float x;           // current x position in world units
    float y;           // current y position
    float heading_rad; // current heading (e.g., 0 rad = +x axis)
} pose_t;

// Struc initializations
waypoint_t waypoints[NUM_WAYPOINTS];

pose_t robot = {
    .x = 0.0f,
    .y = 0.0f,
    .heading_rad = 0.0f
};

// Tunable movement constants
#define PWM_FORWARD        5000.0f   // forward PWM level
#define UNITS_PER_SECOND   200.0f     // 20 Cartesian units per second at PWM_FORWARD
#define TURN_PWM           3500.0f   // PWM level used while turning
#define ANGLE_TOL_DEG      10.0f      // acceptable heading error to consider "aligned"
#define ANGLE_TOL_RAD      (ANGLE_TOL_DEG * 3.14159265f / 180.0f)

////////////////////////////////////////////////////////////////////////
///////////////////////// MOVEMENT HELPERS /////////////////////////////
////////////////////////////////////////////////////////////////////////

// Convert degrees (from BNO055) to radians
static inline float deg2rad(float deg) {
    return deg * (3.14159265f / 180.0f);
}

static float distance_to_waypoint(const pose_t *robot_pose, const waypoint_t *target)
{
    float dx = target->x - robot_pose->x;
    float dy = target->y - robot_pose->y;
    return sqrtf(dx * dx + dy * dy);
}

static void update_robot_heading_from_imu(void)
{
    float yaw_deg = fix2float15(euler[0]);   // heading in degrees
    robot.heading_rad = deg2rad(yaw_deg);    // store in radians
}

static void update_robot_heading_from_imu_first(void)
{
    float yaw_deg = fix2float15(euler[0]) + 180.0f;   // heading in degrees
    robot.heading_rad = deg2rad(yaw_deg);    // store in radians
}

// Absolute angle (world-frame) from robot pose to target waypoint
static float angle_to_waypoint(const pose_t *robot_pose, const waypoint_t *target)
{
    float dx = target->x - robot_pose->x;
    float dy = target->y - robot_pose->y;
    float waypoint_angle = atan2f(dy, dx);
    return waypoint_angle;   // radians
}

// Signed turn angle from robot heading to face the waypoint, normalized to [-pi, pi]
static float turn_angle_to_waypoint(const pose_t *robot_pose, const waypoint_t *target)
{
    float desired = angle_to_waypoint(robot_pose, target);
    float err     = desired - robot_pose->heading_rad;

    // normalize to [-pi, pi]
    while (err >=  3.14159265f) err -= 2.0f * 3.14159265f;
    while (err < -3.14159265f) err += 2.0f * 3.14159265f;

    return err;
}

// === Low-level helpers: directly drive each H-bridge input ===

// Forward slice: GPIO16 (A), GPIO17 (B)
static inline void left_forward_pin_pwm(float pwm) {
    if (pwm < 0.0f) pwm = 0.0f;
    if (pwm > (float)WRAPVAL) pwm = (float)WRAPVAL;
    pwm_set_chan_level(slice_fwd, PWM_CHAN_A, pwm);  // GPIO16
}

static inline void right_forward_pin_pwm(float pwm) {
    if (pwm < 0.0f) pwm = 0.0f;
    if (pwm > (float)WRAPVAL) pwm = (float)WRAPVAL;
    pwm_set_chan_level(slice_fwd, PWM_CHAN_B, pwm);  // GPIO17
}

// Reverse slice: GPIO6 (A), GPIO7 (B)
static inline void right_reverse_pin_pwm(float pwm) {
    if (pwm < 0.0f) pwm = 0.0f;
    if (pwm > (float)WRAPVAL) pwm = (float)WRAPVAL;
    pwm_set_chan_level(slice_rev, PWM_CHAN_A, pwm);  // GPIO6
}

static inline void left_reverse_pin_pwm(float pwm) {
    if (pwm < 0.0f) pwm = 0.0f;
    if (pwm > (float)WRAPVAL) pwm = (float)WRAPVAL;
    pwm_set_chan_level(slice_rev, PWM_CHAN_B, pwm);  // GPIO7
}

void set_left_motor_signed(float speed) {
    if (speed > 0.0f) {
        // Robot FORWARD:
        //   Left motor uses H-bridge "backward" input (GPIO16) due to flipped motor
        left_forward_pin_pwm(speed);   // GPIO16 -> robot forward
        left_reverse_pin_pwm(0.0f);    // GPIO7 off
    } else if (speed < 0.0f) {
        // Robot BACKWARD:
        //   Left motor uses H-bridge "forward" input (GPIO7)
        left_forward_pin_pwm(0.0f);    
        left_reverse_pin_pwm(-speed);  // GPIO7 -> robot backward
    } else {
        left_forward_pin_pwm(0.0f);
        left_reverse_pin_pwm(0.0f);
    }
}

void set_right_motor_signed(float speed) {
    if (speed > 0.0f) {
        // Normal orientation: forward input really is forward
        right_forward_pin_pwm(speed);  // GPIO17 -> robot forward
        right_reverse_pin_pwm(0.0f);   // GPIO6 off
    } else if (speed < 0.0f) {
        right_forward_pin_pwm(0.0f);
        right_reverse_pin_pwm(-speed); // GPIO6 -> robot backward
    } else {
        right_forward_pin_pwm(0.0f);
        right_reverse_pin_pwm(0.0f);
    }
}

void move_forward(float distance_units)
{
    // Ignore non-positive distances
    if (distance_units <= 0.0f) {
        return;
    }

    // Compute how long to drive in seconds
    float time_s = distance_units / UNITS_PER_SECOND;
    uint32_t time_ms = (uint32_t)(time_s * 1000.0f);

    // Drive forward
    set_left_motor_signed(PWM_FORWARD);
    set_right_motor_signed(PWM_FORWARD);
    // set_left_motor_b_pwm(0.0f);
    // set_right_motor_b_pwm(0.0f);

    // Block for the computed time
    sleep_ms(time_ms);

    // Stop motors
    set_left_motor_signed(0.0f);
    set_right_motor_signed(0.0f);
    // set_left_motor_b_pwm(0.0f);
    // set_right_motor_b_pwm(0.0f);

}

static void turn_towards_waypoint(const waypoint_t *target)
{
    // printf("Target waypoint: (%.2f, %.2f)\n", target->x, target->y);

    while (true) {
        update_robot_heading_from_imu();           // read current heading
        float err = turn_angle_to_waypoint(&robot, target);  // compute turn error

        // Print useful debugging info
        //printf("Current pos: (%.2f, %.2f), Error: %.2f rad\n",
         //      robot.x, robot.y, robot.heading_rad, err);

        if (fabsf(err) < ANGLE_TOL_RAD) {
            set_left_motor_signed(0.0f);
            set_right_motor_signed(0.0f);
            // printf("Aligned with waypoint.\n");
            break;
        }

        if (err < 0.0f) {
            // Turn left
            set_right_motor_signed(+TURN_PWM);
            set_left_motor_signed(-TURN_PWM);
            
            //printf("Turning left. PWM Right: %.0f, PWM Left: 0\n", TURN_PWM);
        } else {
            // Turn right
            set_left_motor_signed(+TURN_PWM);
            set_right_motor_signed(-TURN_PWM);

            // printf("Turning right. PWM Left: %.0f, PWM Right: 0\n", TURN_PWM);
        }

        sleep_ms(100);
    }
}

void populate_robot(void) {
    // Format: [0]=seq, [1]=robot_x, [2]=robot_y
    // x,y are reversed: x at odd indices, y at even indices
    robot.y = data_array[1];  // robot x from odd index [1]
    robot.x = 640 - data_array[2];         // robot y from even index [2]
}

int loaded_waypoint_count = 0;

// Populate waypoints starting from a given waypoint index
void populate_waypoints_from_index(int start_waypoint_index) {
  // Format: [0]=waypoint_count, [1]=robot_x, [2]=robot_y, [3]=wp1_x, [4]=wp1_y, [5]=wp2_x, [6]=wp2_y, ...
  // x,y are reversed: x at odd indices, y at even indices
  // start_waypoint_index: which waypoint index to start populating from (0-based)
  int i = 3 + start_waypoint_index * 2;  // Start at data_array index corresponding to waypoint start_waypoint_index
  int waypoints_to_load = 0;
  while ((i + 1) < max_data_size &&
         (start_waypoint_index + waypoints_to_load) < NUM_WAYPOINTS &&
         data_array[i] != -1 &&
         data_array[i+1] != -1) {
    waypoints[start_waypoint_index + waypoints_to_load].y = data_array[i];     // waypoint x from odd index
    waypoints[start_waypoint_index + waypoints_to_load].x = 640 - data_array[i+1];         // waypoint y from even index
    waypoints_to_load++;
    i += 2;
  }
  loaded_waypoint_count = start_waypoint_index + waypoints_to_load;
}

void populate_waypoints(void) {
  populate_waypoints_from_index(0);
}

void populate_all(void) {
  populate_robot();
  populate_waypoints();
}

// High-level controller: go from current robot pose to waypoints[current_waypoint]
void move_to_waypoint(void)
{
    if (current_waypoint == 0) {
      populate_robot();
      populate_waypoints();
    }
    if (current_waypoint >= loaded_waypoint_count) {
        // No more waypoints to visit
        return;
    }

    waypoint_t *target = &waypoints[current_waypoint];

    // Print waypoint we are moving to
    // printf("Moving to waypoint %d: (%.2f, %.2f)\n", current_waypoint, target->x, target->y);

    // 1) Turn to face the current waypoint
    turn_towards_waypoint(target);

    // 2) Compute straight-line distance and drive forward
    float dist = distance_to_waypoint(&robot, target);
    // printf("Driving forward %.2f units\n", dist);
    move_forward(dist);

    // 3) Update pose estimate (snap to waypoint for now)
    robot.x = target->x;
    robot.y = target->y;
   // printf("Reached waypoint. New pose: (%.2f, %.2f)\n", robot.x, robot.y);

    // 4) Advance to next waypoint
    current_waypoint++;
    // if (current_waypoint >= NUM_WAYPOINTS) {
    //     for (int i = 0; i < NUM_WAYPOINTS; i++){
    //         // printf("%d: %f ;", i, atan2_array[i]);
    //     }
    //     printf("\n");
    //     for (int i = 0; i < NUM_WAYPOINTS; i++){
    //         // printf("%d: %f ;", i, current_angle_array[i]);
    //     }
    // }
    
}


//==================================================
// UDP async receive callback setup
// NOTE that udpecho_raw_recv is triggered by a signal
// directly from the LWIP package -- not from your code
// this callback juswt copies out the packet string
// and sets a "new data" semaphore
// This runs in an ISR -- KEEP IT SHORT!!!

#if LWIP_UDP

static struct udp_pcb *udpecho_raw_pcb;
struct pbuf *p ;

static void
udpecho_raw_recv(void *arg, struct udp_pcb *upcb, struct pbuf *p,
                 const ip_addr_t *addr, u16_t port)
{
  LWIP_UNUSED_ARG(arg);

  if (p != NULL) {
    memcpy(recv_data, p->payload, UDP_MSG_LEN_MAX);
    // can signal from an ISR -- BUT NEVER wait in an ISR
    PT_SEM_SIGNAL(pt, &new_udp_recv_s) ;
    
    /* free the pbuf */
    pbuf_free(p);
  }
}

// ===================================
// Define the recv callback 
void 
udpecho_raw_init(void)
{
  udpecho_raw_pcb = udp_new_ip_type(IPADDR_TYPE_ANY);
  p = pbuf_alloc(PBUF_TRANSPORT, UDP_MSG_LEN_MAX+1, PBUF_RAM);

  if (udpecho_raw_pcb != NULL) {
    err_t err;
    // netif_ip4_addr returns the picow ip address
    err = udp_bind(udpecho_raw_pcb, netif_ip4_addr(netif_list), UDP_PORT); //DHCP addr

    if (err == ERR_OK) {
      udp_recv(udpecho_raw_pcb, udpecho_raw_recv, NULL);
    }
  }
}

#endif /* LWIP_UDP */
// end recv setup

// =======================================
// UDP send thead
// sends data when signalled
// =======================================

static PT_THREAD (protothread_udp_send(struct pt *pt))
 { PT_BEGIN(pt);
    static struct udp_pcb* pcb;
    pcb = udp_new();
    pcb->remote_port = UDP_PORT ;
    pcb->local_port = UDP_PORT ;

    static ip_addr_t addr;
    //ipaddr_aton(UDP_TARGET, &addr);

    static int counter = 0;
    
    while (true) {
        
        // stall until there is actually something to send
        PT_SEM_WAIT(pt, &new_udp_send_s) ;

        // in paired mode, the two picos talk just to each other
        // before pairing, the echo unit talks to the laptop
        if(mode == echo) {
          if(paired == true){
                ipaddr_aton(udp_target_pico, &addr);
            }
            else{
                ipaddr_aton(UDP_TARGET_DESK, &addr);
            }         
        }
        // broadcast mode makes sure that another pico sees the packet
        // to sent an address and for testing
        else if(mode == send) {
            if(paired == true){
                ipaddr_aton(udp_target_pico, &addr);
            }
            else{
                ipaddr_aton(UDP_TARGET_BROADCAST, &addr);
            }
        }

        // get the length specified by another thread
        int udp_send_length ;
        switch (packet_length){
          case command:
            udp_send_length = 32 ;
            break;
          case data:
            udp_send_length = send_data_size ;
            break;
          case ack:
            udp_send_length = 5 ;
            break;
        }

       // actual data-send
        struct pbuf *p = pbuf_alloc(PBUF_TRANSPORT, udp_send_length+1, PBUF_RAM);
        char *req = (char *)p->payload;
        memset(req, 0, udp_send_length+1);//
        memcpy(req, send_data, udp_send_length) ;
        //
        err_t er = udp_sendto(pcb, p, &addr, UDP_PORT); //port
       
        pbuf_free(p);
        if (er == ERR_OK) {
            counter++;
        }
    }
    PT_END(pt);
}

// ==================================================
// udp recv processing
// ==================================================
static PT_THREAD (protothread_udp_recv(struct pt *pt))
{
    PT_BEGIN(pt);
        static char  arg1[32], arg2[32], arg3[32] , arg4[32]  ;
        static char* token ;

      while(1) {
        // wait for new packet
        // signalled by LWIP receive ISR
        PT_SEM_WAIT(pt, &new_udp_recv_s) ;       
        
        // parse command         
          token = strtok(recv_data, "  ");
          strcpy(arg1, token) ;
          token = strtok(NULL, "  ");
          strcpy(arg2, token) ;
          token = strtok(NULL, "  ");
          strcpy(arg3, token) ;
          token = strtok(NULL, "  ");
          strcpy(arg4, token) ;

          // is this a pairing packet (starts with IP)
          // if so, parse address 
          // process packet to get time
          if(strcmp(arg1,"IP")==0){
            if(mode == echo){
                // if I'm the echo unit, grab the address of the other pico
                // for the send thread to use
                strcpy(udp_target_pico, arg2) ;
                //        
                paired = true ;
                // then send back echo-unit address to send-pico
                memset(send_data, 0, UDP_MSG_LEN_MAX) ;
                sprintf(send_data,"IP %s" ,ip4addr_ntoa(netif_ip4_addr(netif_list))) ;
                packet_length = command ;
                blink_time = 500 ;
                // tell send threead 
                PT_SEM_SIGNAL(pt, &new_udp_send_s) ;
                PT_YIELD(pt);
            }
            else{
              // if I'm the send unit, then just save for future transmit
              strcpy(udp_target_pico, arg2) ;
            }
          } // end  if(strcmp(arg1,"IP")==0)

          // is it ack packet ?
          else if(strcmp(arg1,"ack")==0){
            if(mode == send){
                // ack received
            }
            if(mode == echo){
                memset(send_data, 0, UDP_MSG_LEN_MAX) ;
                sprintf(send_data,"ack" ) ;   
                packet_length = ack ;     
                // tell send threead 
                PT_SEM_SIGNAL(pt, &new_udp_send_s) ;
                PT_YIELD(pt);
            }
          }

        // if not a command, then unformatted data
        else if(mode==echo){ 
          // get the binary array
          memcpy(data_array, recv_data, send_data_size) ;
          // send timing ack
          memset(send_data, 0, UDP_MSG_LEN_MAX) ;
          sprintf(send_data,"ack" ) ;   
          packet_length = ack ;     
          // tell send threead 
         PT_SEM_SIGNAL(pt, &new_udp_send_s) ;
         PT_YIELD(pt);
        }
        // NEVER exit while
      } // END WHILE(1)
    PT_END(pt);
} // recv thread

// ==================================================
// toggle cyw43 LED  
// this is really just a test of multitasking
// compatability with LWIP 
// but also reads out pair status
// ==================================================
static PT_THREAD (protothread_toggle_cyw43(struct pt *pt))
{
    PT_BEGIN(pt);
    static bool LED_state = false ;
    //
     // data structure for interval timer
     PT_INTERVAL_INIT() ;
     // set some default blink time
     blink_time = 100 ;
     // echo the default time to udp connection
     // PT_SEM_SIGNAL(pt, &new_udp_send_s) ;

      while(1) {
        // force a context switch of there is data to send
        if(&new_udp_send_s.count) PT_YIELD(pt);
        //
        LED_state = !LED_state ;
        // the onboard LED is attached to the wifi module
        cyw43_arch_gpio_put(CYW43_WL_GPIO_LED_PIN, LED_state);
        // blink time is modifed by the udp recv thread
        PT_YIELD_INTERVAL(blink_time*1000) ;
        //
        // NEVER exit while
      } // END WHILE(1)
    PT_END(pt);
} // blink thread


static PT_THREAD (protothread_I_like_to_move_it_move_it(struct pt *pt))
{
    PT_BEGIN(pt);
    static enum {
        MOVE_WAITING_FOR_ROUTE = 0,
        MOVE_TURNING,
        MOVE_DRIVING
    } move_state = MOVE_WAITING_FOR_ROUTE;
    static uint64_t drive_end_time_us = 0;
    static waypoint_t *current_target = NULL;
    static bool route_initialized = false;
    static int last_seen_waypoint_count = -1;  // Track last seen waypoint count
    static int last_processed_waypoint_index = -1;  // Track last waypoint index that was processed/visited

    while (1) {
        uint32_t delay_us = 50000;

        // Check for new waypoint data with increased waypoint count
        // Format: [0]=waypoint_count, [1]=robot_x, [2]=robot_y, [3]=wp1_x, [4]=wp1_y, ...
        if (data_array[0] != -1 && data_array[1] != -1 && data_array[2] != -1) {
            int current_waypoint_count = data_array[0];
            
            // Only process if waypoint count increased (new waypoints added)
            if (current_waypoint_count > last_seen_waypoint_count) {
                if (!route_initialized) {
                    // First time: set robot position from data and populate all waypoints starting from 0
                    // Note: waypoint[0] is the "home" position (same as robot start), so we skip it
                    populate_robot();  // Only set robot position on first initialization
                    populate_waypoints_from_index(0);
                    current_waypoint = 1;  // Start from waypoint 1, skip waypoint 0 (home)
                    last_processed_waypoint_index = 0;  // Track that we've processed up to waypoint 0 (home)
                    route_initialized = (loaded_waypoint_count > 1);  // Need at least 2 waypoints (home + 1 destination)
                    move_state = route_initialized ? MOVE_TURNING : MOVE_WAITING_FOR_ROUTE;
                } else {
                    // More waypoints added: DO NOT update robot position - keep current position
                    // Populate only new waypoints starting from last_processed_waypoint_index + 1
                    int start_index = last_processed_waypoint_index + 1;
                    populate_waypoints_from_index(start_index);
                    
                    // Resume navigation from the first unvisited waypoint
                    // Set current_waypoint to the first waypoint we haven't visited yet
                    current_waypoint = start_index;
                    
                    // If we have unvisited waypoints, resume navigation
                    if (current_waypoint < loaded_waypoint_count) {
                        move_state = MOVE_TURNING;
                    } else {
                        // All waypoints completed, stay stationary
                        move_state = MOVE_WAITING_FOR_ROUTE;
                        set_left_motor_signed(0.0f);
                        set_right_motor_signed(0.0f);
                    }
                }
                
                last_seen_waypoint_count = current_waypoint_count;
            }
        }

        if (!route_initialized || loaded_waypoint_count == 0) {
            set_left_motor_signed(0.0f);
            set_right_motor_signed(0.0f);
            delay_us = 200000;
            PT_YIELD_usec(delay_us);
            continue;
        }

        if (current_waypoint >= loaded_waypoint_count) {
            // All current waypoints completed - stop and remain stationary
            // Update last_processed_waypoint_index to track progress
            last_processed_waypoint_index = loaded_waypoint_count - 1;
            set_left_motor_signed(0.0f);
            set_right_motor_signed(0.0f);
            // Don't reset - keep route_initialized and current_waypoint so we can continue when new waypoints arrive
            delay_us = 500000;
            PT_YIELD_usec(delay_us);
            continue;
        }

        current_target = &waypoints[current_waypoint];

        switch (move_state) {
            case MOVE_WAITING_FOR_ROUTE:
                delay_us = 200000;
                break;

            case MOVE_TURNING: {
                update_robot_heading_from_imu();
                float err = turn_angle_to_waypoint(&robot, current_target);
                if (fabsf(err) < ANGLE_TOL_RAD) {
                    set_left_motor_signed(0.0f);
                    set_right_motor_signed(0.0f);
                    float dist = distance_to_waypoint(&robot, current_target);
                    if (dist < 0.01f) {
                        robot.x = current_target->x;
                        robot.y = current_target->y;
                        // Update last processed waypoint index before moving to next
                        last_processed_waypoint_index = current_waypoint;
                        current_waypoint++;
                        break;
                    }
                    float time_s = dist / UNITS_PER_SECOND;
                    drive_end_time_us = time_us_64() + (uint64_t)(time_s * 1000000.0f);
                    set_left_motor_signed(PWM_FORWARD);
                    set_right_motor_signed(PWM_FORWARD);
                    move_state = MOVE_DRIVING;
                } else if (err < 0.0f) {
                    set_left_motor_signed(-TURN_PWM);
                    set_right_motor_signed(+TURN_PWM);
                } else {
                    set_left_motor_signed(+TURN_PWM);
                    set_right_motor_signed(-TURN_PWM);
                }
                delay_us = 50000;
                break;
            }

            case MOVE_DRIVING: {
                if (time_us_64() >= drive_end_time_us) {
                    set_left_motor_signed(0.0f);
                    set_right_motor_signed(0.0f);
                    robot.x = current_target->x;
                    robot.y = current_target->y;
                    // Update last processed waypoint index before moving to next
                    last_processed_waypoint_index = current_waypoint;
                    current_waypoint++;
                    move_state = MOVE_TURNING;
                } else {
                    set_left_motor_signed(PWM_FORWARD);
                    set_right_motor_signed(PWM_FORWARD);
                }
                delay_us = 50000;
                break;
            }
        }

        PT_YIELD_usec(delay_us);
    }

    PT_END(pt);
}

// Interrupt service routine
void on_pwm_wrap() {

    // Clear the interrupt flag that brought us here
    pwm_clear_irq(slice_fwd);
    pwm_clear_irq(slice_rev);

    // Read the IMU
    // NOTE! This is in 15.16 fixed point. Accel in g's, gyro in deg/s
    // If you want these values in floating point, call fix2float15() on
    // the raw measurements.
    bno055_read_euler(euler);
}

// Entry point for core 1
void core1_entry() {
    // pt_add_thread(protothread_imu_serial);
    // pt_add_thread(protothread_move_motors);
    pt_schedule_start ;
}

// ====================================================
int main() {
    memset(data_array, -1, sizeof(data_array));

        ////////////////////////////////////////////////////////////////////////
    ///////////////////////// I2C CONFIGURATION ////////////////////////////
    i2c_init(I2C_CHAN, I2C_BAUD_RATE) ;
    gpio_set_function(SDA_PIN, GPIO_FUNC_I2C) ;
    gpio_set_function(SCL_PIN, GPIO_FUNC_I2C) ;

    bno055_init();
    bno055_read_raw(acceleration, gyro);
    bno055_read_euler(euler);


    // =======================
    // init the wifi network
    if (cyw43_arch_init()) {
        return 1;
    }

    // hook up to local WIFI
    cyw43_arch_enable_sta_mode();

    // power managment 
    //cyw43_wifi_pm(&cyw43_state, CYW43_DEFAULT_PM & ~0xf);

    if (cyw43_arch_wifi_connect_timeout_ms(WIFI_SSID, WIFI_PASSWORD, CYW43_AUTH_WPA2_AES_PSK, 30000)) {
        return 1;
    }

  //==================================================
  //=============== PWM intialization ================
  //==================================================
  // Tell GPIO's 16,17 that they allocated to the PWM
  gpio_set_function(PWM_LEFT_FWD, GPIO_FUNC_PWM);
  gpio_set_function(PWM_RIGHT_FWD, GPIO_FUNC_PWM);

  // Find out which PWM slice is connected to GPIO 16
  slice_fwd = pwm_gpio_to_slice_num(PWM_LEFT_FWD);

  // This section configures the period of the PWM signals
  pwm_set_wrap(slice_fwd, WRAPVAL) ;
  pwm_set_clkdiv(slice_fwd, CLKDIV) ;

  // This sets duty cycle
  pwm_set_chan_level(slice_fwd, PWM_CHAN_A, 0);
  pwm_set_chan_level(slice_fwd, PWM_CHAN_B, 0);

  // Set GPIO 6 7 
  gpio_set_function(PWM_LEFT_REV, GPIO_FUNC_PWM);
  gpio_set_function(PWM_RIGHT_REV, GPIO_FUNC_PWM);

  slice_rev = pwm_gpio_to_slice_num(PWM_LEFT_REV);

  pwm_set_wrap(slice_rev, WRAPVAL) ;
  pwm_set_clkdiv(slice_rev, CLKDIV) ;

  pwm_set_chan_level(slice_rev, PWM_CHAN_A, 0);
  pwm_set_chan_level(slice_rev, PWM_CHAN_B, 0);

  // Mask our slice's IRQ output into the PWM block's single interrupt line,
  // and register our interrupt handler
  pwm_clear_irq(slice_fwd);
  pwm_clear_irq(slice_rev);
  pwm_set_irq_enabled(slice_fwd, true);
  pwm_set_irq_enabled(slice_rev, true);
  irq_set_exclusive_handler(PWM_IRQ_WRAP, on_pwm_wrap);
  irq_set_enabled(PWM_IRQ_WRAP, true);

  // Start the channel
  pwm_set_mask_enabled((1u << slice_fwd) | (1u << slice_rev));


  //============================
  // set up UDP recenve ISR handler
  udpecho_raw_init();
  update_robot_heading_from_imu();

      //========================================
  // start core 1 threads
  // multicore_reset_core1();
  // multicore_launch_core1(&core1_entry);

  // === config threads ========================
  // for core 0

  // init the thread control semaphores
  // for the send/receive
  // recv semaphone is set by an ISR
  PT_SEM_INIT(&new_udp_send_s, 0) ;
  PT_SEM_INIT(&new_udp_recv_s, 0) ;

  // Motor control is now managed by protothread_move_motors
  // set_left_motor_signed(4000);
  // set_right_motor_signed(4000);

  // Note that the ORDER of adding the threads is
  // important here for performance with the async
  // WIFI interface
  pt_add_thread(protothread_udp_recv);
  pt_add_thread(protothread_udp_send);
  pt_add_thread(protothread_toggle_cyw43) ;
  pt_add_thread(protothread_I_like_to_move_it_move_it);
  //
  // === initalize the scheduler ===============
  pt_schedule_start ;

    cyw43_arch_deinit();

    return 0;
}
