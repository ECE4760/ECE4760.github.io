
/**
 * V. Hunter Adams (vha3@cornell.edu)
 * 
 * This demonstration utilizes the MPU6050.
 * It gathers raw accelerometer/gyro measurements, scales
 * them, and plots them to the VGA display. The top plot
 * shows gyro measurements, bottom plot shows accelerometer
 * measurements.
 * 
 * HARDWARE CONNECTIONS
 *  - GPIO 16 ---> VGA Hsync
 *  - GPIO 17 ---> VGA Vsync
 *  - GPIO 18 ---> 470 ohm resistor ---> VGA Green
 *  - GPIO 19 ---> 330 ohm resistor ---> VGA Green
 *  - GPIO 20 ---> 330 ohm resistor ---> VGA Blue
 *  - GPIO 21 ---> 330 ohm resistor ---> VGA Red
 *  - RP2040 GND ---> VGA GND
 *  - GPIO 8 ---> MPU6050 SDA
 *  - GPIO 9 ---> MPU6050 SCL
 *  - 3.3v ---> MPU6050 VCC
 *  - RP2040 GND ---> MPU6050 GND
 * 
 * Modified for ECE 4760 Final Project, Fall 2025
 * Authors: Sarah Zhong (sjz44), Gebran Kastoun (glk49), Ruby Wu (rcw253)
 * Cornell University
 */

/*
    Program structure (incomplete, was just notes to write the code):

    ISR:
        - Checks if it is time for new waypoint movement/calculation
        - Yes:
            - Call "move_to_waypoint" method
        - No:
            - Wait

    move_to_waypoint:
        - Turns towards waypoint
            - Needs current_heading (last desired_heading), desired_heading, current_position (last waypoint)
        - Moves forward to waypoint
        - Tells ISR its at waypoint

*/ 
 // Include standard libraries
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <stdint.h>

// Include PICO libraries
#include "pico/stdlib.h"
#include "pico/multicore.h"

// Include hardware libraries
#include "hardware/pwm.h"
#include "hardware/dma.h"
#include "hardware/irq.h"
#include "hardware/adc.h"
#include "hardware/pio.h"
#include "hardware/i2c.h"
#include "hardware/clocks.h"

// Include custom libraries
#include "vga16_graphics_v2.h"
#include "mpu6050.h" 
#include "bno055.h"
#include "pt_cornell_rp2040_v1_4.h"

/*

Arrays in which raw measurements will be stored

Accel & Gyro are for MPU
Euler for BNO (Can pull orientation from Euler vector)

*/ 
fix15 acceleration[3], gyro[3], euler[3] ;

// character array
char screentext[40] ;

// draw speed
int threshold = 10 ;

// Some macros for max/min/abs
#define min(a,b) ((a<b) ? a:b)
#define max(a,b) ((a<b) ? b:a)
#define abs(a) ((a>0) ? a:-a)

// semaphore
static struct pt_sem vga_semaphore ;

// Some paramters for PWM 
// !!! CHECK IF WE NEED TO EDIT WRAPVAL FOR YELLOW MOTORS !!!
#define WRAPVAL 5000
#define CLKDIV  25.0
uint slice_fwd; // slice for 16/17
uint slice_rev; // slice for 6/7

// === MOTOR PIN ASSIGNMENTS ===
// Left motor:
//   - GPIO16: H-bridge "backward" input  -> robot FORWARD (motor flipped)
//   - GPIO7:  H-bridge "forward" input   -> robot BACKWARD
// Right motor:
//   - GPIO17: H-bridge "forward" input   -> robot FORWARD
//   - GPIO6:  H-bridge "backward" input  -> robot BACKWARD

#define PWM_LEFT_FWD    16   // robot forward (H-bridge "backward")
#define PWM_RIGHT_FWD   17   // robot forward
#define PWM_RIGHT_REV   6    // robot backward
#define PWM_LEFT_REV    7    // robot backward

// BLINKYYYYY
#define LED_PIN 25

// PWM duty cycles
// volatile int control_right;
// volatile int old_control_right;
// volatile int control_left;
// volatile int old_control_left;

// // PWM duty cycles
// volatile int control_right_b;
// volatile int old_control_right_b;
// volatile int control_left_b;
// volatile int old_control_left_b;

// Movement Declarations

#define NUM_WAYPOINTS 18
int current_waypoint = 0;

float atan2_array[NUM_WAYPOINTS];
float current_angle_array[NUM_WAYPOINTS];

float initial;

// Struct definitions
typedef struct {
    float x;
    float y;
} waypoint_t;

typedef struct {
    float x;           // current x position in world units
    float y;           // current y position
    float heading_rad; // current heading (e.g., 0 rad = +x axis)
} pose_t;

// Struc initializations
waypoint_t waypoints[NUM_WAYPOINTS] = {
    {40.0f, 50.0f},   // P1 outer (top)
    {50.0f, 40.0f},   // P2 inner
    {50.0f, 20.0f},   // P3 outer
    {40.0f, 10.0f},   // P4 inner
    {20.0f,  10.0f},   // P5 outer
    {10.0,  20.0f},   // P6 inner (bottom-ish)
    { 10.0f,  40.0f},   // P7 outer
    { 20.0, 50.0f},   // P8 inner
    { 10.0f, 60.0f},   // P9 outer
    { 10.0f, 80.0f},    // P10 inner — ends loop
    {20.0f, 90.0f},
    {40.0f, 90.0f},
    {50.0f, 80.0f},
    {50.0f, 60.0f},
    {150.0f, 60.0f},
    {160.0f,50.0f},
    {150.0f, 40.0f},
    {50.0f, 40.0f}
};

pose_t robot = {
    .x = 0.0f,
    .y = 0.0f,
    .heading_rad = 0.0f
};

// Tunable movement constants
#define PWM_FORWARD        4000.0f   // forward PWM level
#define UNITS_PER_SECOND   50.0f     // 20 Cartesian units per second at PWM_FORWARD
#define TURN_PWM           4000.0f   // PWM level used while turning
#define ANGLE_TOL_DEG      10.0f      // acceptable heading error to consider "aligned"
#define ANGLE_TOL_RAD      (ANGLE_TOL_DEG * 3.14159265f / 180.0f)
 


////////////////////////////////////////////////////////////////////////
///////////////////////// MOVEMENT HELPERS /////////////////////////////
////////////////////////////////////////////////////////////////////////

// Convert degrees (from BNO055) to radians
static inline float deg2rad(float deg) {
    return deg * (3.14159265f / 180.0f);
}

static float distance_to_waypoint(const pose_t *robot_pose, const waypoint_t *target)
{
    float dx = target->x - robot_pose->x;
    float dy = target->y - robot_pose->y;
    return sqrtf(dx * dx + dy * dy);
}

static void update_robot_heading_from_imu(void)
{
    float yaw_deg = fix2float15(euler[0]);   // heading in degrees
    current_angle_array[current_waypoint] = deg2rad(yaw_deg);
    robot.heading_rad = deg2rad(yaw_deg);    // store in radians
}

// Absolute angle (world-frame) from robot pose to target waypoint
static float angle_to_waypoint(const pose_t *robot_pose, const waypoint_t *target)
{
    float dx = target->x - robot_pose->x;
    float dy = target->y - robot_pose->y;
    float waypoint_angle = atan2f(dy, dx);
    atan2_array[current_waypoint] = waypoint_angle;
    return waypoint_angle;   // radians
}


// Signed turn angle from robot heading to face the waypoint, normalized to [-pi, pi]
static float turn_angle_to_waypoint(const pose_t *robot_pose, const waypoint_t *target)
{
    float desired = angle_to_waypoint(robot_pose, target);
    float err     = desired - robot_pose->heading_rad;

    // normalize to [-pi, pi]
    while (err >=  3.14159265f) err -= 2.0f * 3.14159265f;
    while (err < -3.14159265f) err += 2.0f * 3.14159265f;

    return err;
}

// === Low-level helpers: directly drive each H-bridge input ===

// Forward slice: GPIO16 (A), GPIO17 (B)
static inline void left_forward_pin_pwm(float pwm) {
    if (pwm < 0.0f) pwm = 0.0f;
    if (pwm > (float)WRAPVAL) pwm = (float)WRAPVAL;
    pwm_set_chan_level(slice_fwd, PWM_CHAN_A, pwm);  // GPIO16
}

static inline void right_forward_pin_pwm(float pwm) {
    if (pwm < 0.0f) pwm = 0.0f;
    if (pwm > (float)WRAPVAL) pwm = (float)WRAPVAL;
    pwm_set_chan_level(slice_fwd, PWM_CHAN_B, pwm);  // GPIO17
}

// Reverse slice: GPIO6 (A), GPIO7 (B)
static inline void right_reverse_pin_pwm(float pwm) {
    if (pwm < 0.0f) pwm = 0.0f;
    if (pwm > (float)WRAPVAL) pwm = (float)WRAPVAL;
    pwm_set_chan_level(slice_rev, PWM_CHAN_A, pwm);  // GPIO6
}

static inline void left_reverse_pin_pwm(float pwm) {
    if (pwm < 0.0f) pwm = 0.0f;
    if (pwm > (float)WRAPVAL) pwm = (float)WRAPVAL;
    pwm_set_chan_level(slice_rev, PWM_CHAN_B, pwm);  // GPIO7
}

void set_left_motor_signed(float speed) {
    if (speed > 0.0f) {
        // Robot FORWARD:
        //   Left motor uses H-bridge "backward" input (GPIO16) due to flipped motor
        left_forward_pin_pwm(speed);   // GPIO16 -> robot forward
        left_reverse_pin_pwm(0.0f);    // GPIO7 off
    } else if (speed < 0.0f) {
        // Robot BACKWARD:
        //   Left motor uses H-bridge "forward" input (GPIO7)
        left_forward_pin_pwm(0.0f);    
        left_reverse_pin_pwm(-speed);  // GPIO7 -> robot backward
    } else {
        left_forward_pin_pwm(0.0f);
        left_reverse_pin_pwm(0.0f);
    }
}

void set_right_motor_signed(float speed) {
    if (speed > 0.0f) {
        // Normal orientation: forward input really is forward
        right_forward_pin_pwm(speed);  // GPIO17 -> robot forward
        right_reverse_pin_pwm(0.0f);   // GPIO6 off
    } else if (speed < 0.0f) {
        right_forward_pin_pwm(0.0f);
        right_reverse_pin_pwm(-speed); // GPIO6 -> robot backward
    } else {
        right_forward_pin_pwm(0.0f);
        right_reverse_pin_pwm(0.0f);
    }
}


void move_forward(float distance_units)
{
    gpio_put(LED_PIN, 1);
    // Ignore non-positive distances
    if (distance_units <= 0.0f) {
        return;
    }

    // Compute how long to drive in seconds
    float time_s = distance_units / UNITS_PER_SECOND;
    uint32_t time_ms = (uint32_t)(time_s * 1000.0f);

    // Drive forward
    set_left_motor_signed(PWM_FORWARD);
    set_right_motor_signed(PWM_FORWARD);
    // set_left_motor_b_pwm(0.0f);
    // set_right_motor_b_pwm(0.0f);

    // Block for the computed time
    sleep_ms(time_ms);

    // Stop motors
    set_left_motor_signed(0.0f);
    set_right_motor_signed(0.0f);
    // set_left_motor_b_pwm(0.0f);
    // set_right_motor_b_pwm(0.0f);

    gpio_put(LED_PIN, 0);
}

static void turn_towards_waypoint(const waypoint_t *target)
{
    while (true) {
        update_robot_heading_from_imu();           // read current heading
        float err = turn_angle_to_waypoint(&robot, target);  // compute turn error

        if (fabsf(err) < ANGLE_TOL_RAD) {
            set_left_motor_signed(0.0f);
            set_right_motor_signed(0.0f);
            break;
        }

        if (err < 0.0f) {
            // Turn left
            set_right_motor_signed(+TURN_PWM);
            set_left_motor_signed(-TURN_PWM);
        } else {
            // Turn right
            set_left_motor_signed(+TURN_PWM);
            set_right_motor_signed(-TURN_PWM);
        }

        sleep_ms(100);
    }
}


// High-level controller: go from current robot pose to waypoints[current_waypoint]
void move_to_waypoint(void)
{
    if (current_waypoint >= NUM_WAYPOINTS) {
        // No more waypoints to visit
        return;
    }

    waypoint_t *target = &waypoints[current_waypoint];

    // Print waypoint we are moving to
    // printf("Moving to waypoint %d: (%.2f, %.2f)\n", current_waypoint, target->x, target->y);

    // 1) Turn to face the current waypoint
    turn_towards_waypoint(target);

    // 2) Compute straight-line distance and drive forward
    float dist = distance_to_waypoint(&robot, target);
    // printf("Driving forward %.2f units\n", dist);
    move_forward(dist);

    // 3) Update pose estimate (snap to waypoint for now)
    robot.x = target->x;
    robot.y = target->y;
   // printf("Reached waypoint. New pose: (%.2f, %.2f)\n", robot.x, robot.y);

    // 4) Advance to next waypoint
    current_waypoint++;
    
}




// Interrupt service routine
void on_pwm_wrap() {

    // Clear the interrupt flag that brought us here
    pwm_clear_irq(slice_fwd);
    pwm_clear_irq(slice_rev);

    // Read the IMU
    // NOTE! This is in 15.16 fixed point. Accel in g's, gyro in deg/s
    // If you want these values in floating point, call fix2float15() on
    // the raw measurements.
    bno055_read_euler(euler);

    // Signal VGA to draw
    // if ( control_right != old_control_right ) {
    //     old_control_right = control_right;
    //     pwm_set_chan_level(slice_num, PWM_CHAN_A, control_right);
    // }
    // if ( control_left != old_control_left ) {
    //     old_control_left = control_left;
    //     pwm_set_chan_level(slice_num, PWM_CHAN_B, control_left);
    // }
    // PT_SEM_SIGNAL(pt, &vga_semaphore);
}

/*
    User input thread:
        - Can use this to test movement. Have to edit to test right and left independently
        - After will have to replace with control thread
        - Need to make methods for move forward, right, left, etc.
*/
// static PT_THREAD (protothread_serial(struct pt *pt))
// {
//     PT_BEGIN(pt) ;
//     static int test_in ;
//     while(1) {
//         sprintf(pt_serial_out_buffer, "input a duty cycle (0-5000): ");
//         serial_write ;
//         // spawn a thread to do the non-blocking serial read
//         serial_read ;
//         // convert input string to number
//         sscanf(pt_serial_in_buffer,"%d", &test_in) ;
//         if (test_in > 5000) continue ;
//         else if (test_in < 0) continue ;
//         else {
//             control_right = test_in ;
//             control_left = test_in ;
//         } 
//     }
//     PT_END(pt) ;
// }


// Thread that draws to VGA display
static PT_THREAD (protothread_vga(struct pt *pt))
{
    // Indicate start of thread
    PT_BEGIN(pt) ;

    // We will start drawing at column 81
    static int xcoord = 81 ;
    
    // Rescale the measurements for display
    static float OldRange = 360.0f;   // (+/- 180)
    static float NewRange = 150.0f;   // (looks nice on VGA)
    static float OldMin   = -180.0f;
    static float OldMax   =  180.0f;

    // Control rate of drawing
    static int throttle ;

    // Draw the static aspects of the display
    setTextSize(1) ;
    setTextColor(WHITE);

    // Draw bottom plot
    drawHLine(75, 430, 5, CYAN) ;
    drawHLine(75, 355, 5, CYAN) ;
    drawHLine(75, 280, 5, CYAN) ;
    drawVLine(80, 280, 150, CYAN) ;
    sprintf(screentext, "0") ;
    setCursor(50, 350) ;
    writeString(screentext) ;
    sprintf(screentext, "+180") ;
    setCursor(50, 280) ;
    writeString(screentext) ;
    sprintf(screentext, "-180") ;
    setCursor(50, 425) ;
    writeString(screentext) ;

    // Label bottom plot as Yaw
    setCursor(90, 280);
    writeString("Yaw (deg)");

    // Draw top plot
    drawHLine(75, 230, 5, CYAN) ;
    drawHLine(75, 155, 5, CYAN) ;
    drawHLine(75, 80, 5, CYAN) ;
    drawVLine(80, 80, 150, CYAN) ;
    sprintf(screentext, "0") ;
    setCursor(50, 150) ;
    writeString(screentext) ;
    sprintf(screentext, "+180") ;
    setCursor(45, 75) ;
    writeString(screentext) ;
    sprintf(screentext, "-180") ;
    setCursor(45, 225) ;
    writeString(screentext) ;

    setCursor(90, 80);
    writeString("Yaw/Roll/Pitch (deg)");
    

    while (true) {
        // Wait on semaphore
        PT_SEM_WAIT(pt, &vga_semaphore);
        // Increment drawspeed controller
        throttle += 1 ;
        // If the controller has exceeded a threshold, draw
        if (throttle >= threshold) { // GEBRAN NOTE: I don't understand what this does
            // Zero drawspeed controller
            throttle = 0 ;

            // Erase a column
            drawVLine(xcoord, 0, 480, BLACK) ;

            // Convert fixed-point Euler angles to float degrees
            float yaw_deg   = fix2float15(euler[0]);   // heading
            float roll_deg  = fix2float15(euler[1]);
            float pitch_deg = fix2float15(euler[2]);

            //------------------ Top plot: yaw, roll, pitch ------------------//
            // Map [-180,180] -> vertical pixels on 80..230 region
            int y_yaw_top   = 230 - (int)(NewRange * ((yaw_deg   - OldMin) / OldRange));
            int y_roll_top  = 230 - (int)(NewRange * ((roll_deg  - OldMin) / OldRange));
            int y_pitch_top = 230 - (int)(NewRange * ((pitch_deg - OldMin) / OldRange));

            drawPixel(xcoord, y_yaw_top,   WHITE); // yaw
            drawPixel(xcoord, y_roll_top,  RED);   // roll
            drawPixel(xcoord, y_pitch_top, GREEN); // pitch

            //------------------ Bottom plot: yaw only ------------------//
            int y_yaw_bottom = 430 - (int)(NewRange * ((yaw_deg - OldMin) / OldRange));
            drawPixel(xcoord, y_yaw_bottom, WHITE);

            // Update horizontal cursor
            if (xcoord < 609) {
                xcoord += 1 ;
            }
            else {
                xcoord = 81 ;
            }
        }
    }
    // Indicate end of thread
    PT_END(pt);
}

// User input thread. User can change draw speed
// GEBRAN NOTE: I think this is irrelevant for us? Can keep but can also remove for clarity
static PT_THREAD (protothread_serial_draw(struct pt *pt))
{
    PT_BEGIN(pt) ;
    static char classifier ;
    static int test_in ;
    static float float_in ;
    while(1) {
        sprintf(pt_serial_out_buffer, "input a command: ");
        serial_write ;
        // spawn a thread to do the non-blocking serial read
        serial_read ;
        // convert input string to number
        sscanf(pt_serial_in_buffer,"%c", &classifier) ;

        // num_independents = test_in ;
        if (classifier=='t') {
            sprintf(pt_serial_out_buffer, "timestep: ");
            serial_write ;
            serial_read ;
            // convert input string to number
            sscanf(pt_serial_in_buffer,"%d", &test_in) ;
            if (test_in > 0) {
                threshold = test_in ;
            }
        }
    }
    PT_END(pt) ;
}

// Thread to print IMU orientation 10x a second
static PT_THREAD (protothread_imu_serial(struct pt *pt))
{
    PT_BEGIN(pt);

    while (1) {
        // Use the latest euler[] values (updated in on_pwm_wrap ISR)
        float yaw_deg   = fix2float15(euler[0]);
        // float roll_deg  = fix2float15(euler[1]);
        // float pitch_deg = fix2float15(euler[2]);

        // Print to USB serial

        // Wait 100 ms -> 10 Hz
        PT_YIELD_usec(1000000);
    }

    PT_END(pt);
}

// Entry point for core 1
// GEBRAN NOTE: Do we even have anything on core 1?
void core1_entry() {
    pt_add_thread(protothread_vga) ;
    // pt_add_thread(protothread_imu_serial);
    pt_schedule_start ;
}

int main() {

    // Overclock
    set_sys_clock_khz(150000, true) ;

    // Initialize stdio
    stdio_init_all();

    // Initialize VGA
    initVGA() ;

    ////////////////////////////////////////////////////////////////////////
    ///////////////////////// I2C CONFIGURATION ////////////////////////////
    i2c_init(I2C_CHAN, I2C_BAUD_RATE) ;
    gpio_set_function(SDA_PIN, GPIO_FUNC_I2C) ;
    gpio_set_function(SCL_PIN, GPIO_FUNC_I2C) ;

    // BLINKYYY
    gpio_init(LED_PIN);
    gpio_set_dir(LED_PIN, GPIO_OUT);

    /*  
        Pullup resistors on breakout board, don't need to turn on internals
        GEBRAN NOTE: Not sure what breakout board they're referring to.
        Maybe the MPU has internals, the BNO might have as well
        But regardless, I think we're good; the signal on the VGA for the IMU orientation
        looked very clean.
    */
    // gpio_pull_up(SDA_PIN) ;
    // gpio_pull_up(SCL_PIN) ;

    // BNO055 initialization (replaced the MPU, slightly different functions from the BNO driver)
    // while (1) {
    //     gpio_put(LED_PIN, 1);
    //     sleep_ms(500);
    //     gpio_put(LED_PIN, 0);
    //     sleep_ms(500);
    // }
    bno055_init();
    bno055_read_raw(acceleration, gyro);
    bno055_read_euler(euler);
    update_robot_heading_from_imu();
    // initial = fix2float15(euler[0]);



    ////////////////////////////////////////////////////////////////////////
    ///////////////////////// PWM CONFIGURATION ////////////////////////////
    ////////////////////////////////////////////////////////////////////////
    // Tell GPIO's 16,17 that they allocated to the PWM
    gpio_set_function(PWM_LEFT_FWD, GPIO_FUNC_PWM);
    gpio_set_function(PWM_RIGHT_FWD, GPIO_FUNC_PWM);

    // Find out which PWM slice is connected to GPIO 16
    slice_fwd = pwm_gpio_to_slice_num(PWM_LEFT_FWD);

    // This section configures the period of the PWM signals
    pwm_set_wrap(slice_fwd, WRAPVAL) ;
    pwm_set_clkdiv(slice_fwd, CLKDIV) ;

    // This sets duty cycle
    pwm_set_chan_level(slice_fwd, PWM_CHAN_A, 0);
    pwm_set_chan_level(slice_fwd, PWM_CHAN_B, 0);

    // Set GPIO 6 7 
    gpio_set_function(PWM_LEFT_REV, GPIO_FUNC_PWM);
    gpio_set_function(PWM_RIGHT_REV, GPIO_FUNC_PWM);

    slice_rev = pwm_gpio_to_slice_num(PWM_LEFT_REV);

    pwm_set_wrap(slice_rev, WRAPVAL) ;
    pwm_set_clkdiv(slice_rev, CLKDIV) ;

    pwm_set_chan_level(slice_rev, PWM_CHAN_A, 0);
    pwm_set_chan_level(slice_rev, PWM_CHAN_B, 0);

    // Mask our slice's IRQ output into the PWM block's single interrupt line,
    // and register our interrupt handler
    pwm_clear_irq(slice_fwd);
    pwm_clear_irq(slice_rev);
    pwm_set_irq_enabled(slice_fwd, true);
    pwm_set_irq_enabled(slice_rev, true);
    irq_set_exclusive_handler(PWM_IRQ_WRAP, on_pwm_wrap);
    irq_set_enabled(PWM_IRQ_WRAP, true);

    // Start the channel
    pwm_set_mask_enabled((1u << slice_fwd) | (1u << slice_rev));


    ////////////////////////////////////////////////////////////////////////
    ///////////////////////////// ROCK AND ROLL ////////////////////////////
    ////////////////////////////////////////////////////////////////////////
    // start core 1 
    multicore_reset_core1();
    multicore_launch_core1(core1_entry);

    sleep_ms(2000);

    // // SPIN TEST //
    // sleep_ms(1000);
    // // Tiny test: spin in place left for 1s, then right for 1s

    // set_left_motor_signed(+4000);   // forward left (NO THIS TURNS FORWARD RIGHT)
    // set_right_motor_signed(-4000);  // backward right


    // sleep_ms(10000);

    // set_left_motor_signed(-4000);   // backward left
    // set_right_motor_signed(+4000);  // forward right
    // sleep_ms(10000);

    // set_left_motor_signed(0.0f);
    // set_right_motor_signed(0.0f);

    // Loop through all waypoints
    // 1
    while (current_waypoint < NUM_WAYPOINTS) {
        move_to_waypoint();   // turn + drive to next waypoint
        sleep_ms(500);        // short pause between waypoints so you can see it

        // Testing from earlier
        // set_left_motor_pwm(4000);
        // set_right_motor_pwm(4000);
        // sleep_ms(3000);

        // set_left_motor_pwm(0);
        // set_right_motor_pwm(0);
        // sleep_ms(2000);
    }

    // Stop motors when done
    set_left_motor_signed(0.0f);
    set_right_motor_signed(0.0f);

    // Idle forever, VGA still runs on core1
    while (1) {
        sleep_ms(1000);  // or sleep_ms(1000);
    }

    // start core 0
    //pt_add_thread(protothread_serial) ;
    //pt_add_thread(protothread_serial_draw) ;
    //pt_schedule_start ;

}