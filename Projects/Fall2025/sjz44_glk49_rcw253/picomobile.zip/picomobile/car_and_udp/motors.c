/**
 * @file motors.c
 * @brief Motor control functions for PWM-based H-bridge motor drivers
 * 
 * This file provides PWM control functions for left and right motors
 * connected to an H-bridge driver circuit. Motors are controlled via
 * hardware PWM on the Raspberry Pi Pico.
 * 
 * @note This is a test/demo file. The main motor control logic is
 *       integrated into picow_udp_send_recv_data.c
 * 
 * ECE 4760 Final Project, Fall 2025
 * Authors: Sarah Zhong (sjz44), Gebran Kastoun (glk49), Ruby Wu (rcw253)
 * Cornell University
 */

#include "pico/stdlib.h"
#include "hardware/pwm.h"

// Use the actual pins wired to your H-bridge EN pins.
// If you rewired to 6/7, use those. If still on 4/5, use 4/5.
#define PWM_OUT_RIGHT 16   // or 4
#define PWM_OUT_LEFT  17   // or 5

#define WRAPVAL 5000
#define CLKDIV  25.0

static uint slice_num;

void set_left_motor_pwm(uint16_t pwm)
{
    if (pwm > WRAPVAL) pwm = WRAPVAL;
    pwm_set_chan_level(slice_num, PWM_CHAN_B, pwm);
}

void set_right_motor_pwm(uint16_t pwm)
{
    if (pwm > WRAPVAL) pwm = WRAPVAL;
    pwm_set_chan_level(slice_num, PWM_CHAN_A, pwm);
}

int main()
{
    stdio_init_all();

    // Configure GPIOs for PWM
    gpio_set_function(PWM_OUT_LEFT,  GPIO_FUNC_PWM);
    gpio_set_function(PWM_OUT_RIGHT, GPIO_FUNC_PWM);

    // Get the slice used by the LEFT pin
    slice_num = pwm_gpio_to_slice_num(PWM_OUT_LEFT);

    // Basic PWM config
    pwm_set_wrap(slice_num, WRAPVAL);
    pwm_set_clkdiv(slice_num, CLKDIV);

    // Start with both off
    pwm_set_chan_level(slice_num, PWM_CHAN_A, 0);
    pwm_set_chan_level(slice_num, PWM_CHAN_B, 0);

    pwm_set_mask_enabled(1u << slice_num);

    while (true) {

        // 1) RIGHT ONLY
        set_right_motor_pwm(3000);
        set_left_motor_pwm(0);
        sleep_ms(2000);

        set_right_motor_pwm(0);
        sleep_ms(1000);

        // 2) LEFT ONLY
        set_left_motor_pwm(3000);
        set_right_motor_pwm(0);
        sleep_ms(2000);

        set_left_motor_pwm(0);
        sleep_ms(1000);

        // 3) BOTH
        set_left_motor_pwm(3000);
        set_right_motor_pwm(3000);
        sleep_ms(3000);

        set_left_motor_pwm(0);
        set_right_motor_pwm(0);
        sleep_ms(2000);
    }
}
