/* 
 * The MIT License (MIT)
 *
 * Copyright (c) 2019 Ha Thach (tinyusb.org)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 * 
 * This version converts the demo program to use protothreads 1.3
 * then factors out the reporting from the usb handler and controls
 * the mouse and keyboard disply to VGA
 * The USB task is running as a protothread every 8 mSec to catch mouse events
 * YOu might need ot speed this up for gaming.
 * core 0 is handling USB and blinking an LED
 * core 1 is doing the drawing
 *
 */

#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "vars.h"
#include "bsp/board.h"
#include "tusb.h"

// ==========================================
// === VGA graphics library
// ==========================================
#include "vga16_graphics.h"
#include "pico/stdlib.h"
#include "hardware/pio.h"
#include "hardware/dma.h"

// ==========================================
// === protothreads globals
// ==========================================
#include "hardware/sync.h"
#include "hardware/timer.h"
#include "pico/multicore.h"
#include "string.h"
// protothreads header
#include "pt_cornell_rp2040_v1_1_2.h"
// global vars shared with HID code thru vars.h
int mouse_dx, mouse_x=320, mouse_dy, mouse_y=240 ;
int mouse_update ;
int mouse_button, mouse_button_update ;
char keybd_char ;
int keybd_update ;

extern void cdc_app_task(void);
extern void hid_app_task(void);

//--------------------------------------------------------------------+
// TinyUSB Callbacks
//--------------------------------------------------------------------+

void tuh_mount_cb(uint8_t dev_addr)
{
  // application set-up
  (void) dev_addr;
}

void tuh_umount_cb(uint8_t dev_addr)
{
  // application tear-down
  (void) dev_addr;
}

// ==================================================
// === USB hid thread on core 0
// ==================================================
// handle mouaswe and keybd
PT_THREAD (protothread_hid(struct pt *pt))
{
    PT_BEGIN(pt);
     while (1) {
      // tinyusb host task
      tuh_task();
      //cdc_app_task();
      //hid_app_task();
      // 8 mSec 125 Hz
      PT_YIELD_usec(8000) ;
    }
    PT_END(pt);
}

// ==================================================
// === toggle25 thread on core 0
// ==================================================
// the on-board LED blinks
static PT_THREAD (protothread_toggle25(struct pt *pt))
{
    PT_BEGIN(pt);
    static bool LED_state = false ;
    
     // set up LED p25 to blink
     gpio_init(25) ;	
     gpio_set_dir(25, GPIO_OUT) ;
     gpio_put(25, true);
     // data structure for interval timer
     PT_INTERVAL_INIT() ;

      while(1) {
        // yield time 0.5 second
        //PT_YIELD_usec(100000) ;
        PT_YIELD_INTERVAL(500000) ;

        // toggle the LED on PICO
        LED_state = LED_state? false : true ;
        gpio_put(25, LED_state);
        //
        // NEVER exit while
      } // END WHILE(1)
  PT_END(pt);
} // blink thread

// ===========================================
// Cursor  -- overlay conttol
// ===========================================

short cursor_pixel_x[5], cursor_pixel_y[5] ;


// replace cursor color with saved image colors
void erase_cursor(short x, short y){
    // first the x direction, then y
    for(int i=0; i<5; i++){
        drawPixel(x-2+i, y,  cursor_pixel_x[i]) ;
        drawPixel(x, y-2+i,  cursor_pixel_y[i]) ;
    }
}

// replace image with cursor color and save image pixels
void draw_cursor(short x, short y){
    for(int i=0; i<5; i++){
        cursor_pixel_x[i] = readPixel(x-2+i, y) ;
        cursor_pixel_y[i] = readPixel(x, y-2+i) ;
        drawPixel(x-2+i, y, WHITE) ;
        drawPixel(x, y-2+i, WHITE) ;
    }
}

// ==================================================
// === vga thread on core 1
// ==================================================
//vga display of mouse and keybd 
PT_THREAD (protothread_vga(struct pt *pt))
{
    PT_BEGIN(pt);
    static char video_str[64], mouse_str[10];
    static unsigned char draw_color = GREEN ;
    static int text_x, text_y, begin_text_x ;

    // Write some text
    setTextColor(WHITE) ;
    setCursor(65, 0) ;
    setTextSize(1) ;
    writeStringBold("Raspberry Pi Pico") ;
    setCursor(65, 10) ;
    writeStringBold("USB HID") ;
    setCursor(65, 20) ;
    writeString("Hunter Adams") ;
    setCursor(65, 30) ;
    writeString("Bruce Land") ;
    setCursor(65, 40) ;
    writeStringBold("ece4760 Cornell") ;
    //
    setCursor(445, 10) ;
    setTextColor(WHITE) ;
    setTextSize(1) ;
    writeString("Protothreads rp2040 v1.3") ;
    setCursor(445, 20) ;
    writeString("VGA 4-bit color") ;
    setCursor(445, 30) ;
    writeString("Tested on pico") ;
    //
    setCursor(270, 20) ;
    setTextColor2(WHITE, BLACK) ;
    writeStringBig("USB HID Test") ;
    setCursor(270, 37) ;
    setTextColor2(WHITE, BLACK) ;
    
    draw_cursor(mouse_x, mouse_y);
    drawRect(2,90,636, 389, WHITE) ;
    setCursor(290, 92) ;
    setTextColor2(WHITE, BLACK) ;
    sprintf(video_str, "%s","Draw Area") ;
    writeStringBold(video_str) ;
    drawHLine(2,100,636, WHITE) ;

     while (1) {
      
      // 30 mSec
      PT_YIELD_usec(30000) ;
     // dreaw the readouts and controls
     setCursor(300, 73) ;
    setTextColor2(GREEN, BLACK) ;
    sprintf(video_str, "%s","Color pick (middle click)") ;
     writeStringBold(video_str) ;
     for(int i=0; i<16; i++){
      fillRect(300+10*i,60,10,10, i);
     }

     drawRoundRect(500, 60, 50, 15, 7, WHITE);
     setCursor(506, 64) ;
     setTextColor2(RED, BLACK) ;
     writeStringBold("erase") ;
     if(mouse_x>500 && mouse_x<610 & mouse_y>60 & mouse_y<75 && (mouse_button & 1)) fillRect(3,101,634, 377, BLACK);

      setCursor(20, 60) ;
      setTextColor2(GREEN, BLACK) ;
      sprintf(video_str, "mouse x = %03d   mouse y = %03d", mouse_x, mouse_y) ;
     writeStringBig(video_str) ;

     // cursor motion update
     if(mouse_update){
      erase_cursor(mouse_x, mouse_y);
      mouse_x += mouse_dx ;
      if (mouse_x < 5) mouse_x = 5;
      if (mouse_x > 635) mouse_x = 635;
      mouse_y += mouse_dy ;
      if (mouse_y < 5) mouse_y = 5;
      if (mouse_y > 475) mouse_y = 475;
      mouse_update = 0 ;
      draw_cursor(mouse_x, mouse_y);
     }

     // mouse buttons
     // left -- draw
     // right -- text instetion point
     // middle -- grab color fro mouse position
     if(mouse_button_update || mouse_button==0){
      //
        if(mouse_button & 1) {
          strcpy(mouse_str, "left    ");
          //2,90,636, 389,
          if(mouse_x>2 && mouse_x<638 && mouse_y>101 && mouse_y<478){
            fillCircle(mouse_x, mouse_y, 2, draw_color) ;
            for(int i=0; i<5; i++){
              cursor_pixel_x[i] = draw_color ;
              cursor_pixel_y[i] = draw_color ;
            }  
          }      
        }    
        // 
        else if(mouse_button & 2) {
          strcpy(mouse_str, "right   ");
          text_x = mouse_x;
          text_y = mouse_y;
          begin_text_x = mouse_x ;
        }
        //
        else if(mouse_button & 4) {
          strcpy(mouse_str, "middle  ");
          draw_color = readPixel(mouse_x+1, mouse_y+1) ;
        }
        //
        else strcpy(mouse_str, "none    ");
        setCursor(20, 75) ;
        setTextColor2(GREEN, BLACK) ;
        sprintf(video_str, "mouse button = %s  ", mouse_str) ;
        writeStringBig(video_str) ;
        mouse_button_update = false ;
     } 

    // keyboard event
    if (keybd_update){
      // <enter>
      if(keybd_char == '\r') {
        text_y += 15; 
        text_x = begin_text_x; 
      }
      // delete a char on the same line
      // <backspace>
      else if(keybd_char == '\b') {
        text_x -= 8 ;
        // draw a spacw over the previous char
        drawCharBig(text_x, text_y, 0x20, WHITE, BLACK) ;
      }
      // regular char
      else {
        drawCharBig(text_x, text_y, keybd_char, draw_color, BLACK) ;
        text_x += 8 ; 
      }   
      keybd_update = false ;
    }    
    }
    PT_END(pt);
}

// ========================================
// === core 1 main -- started in main below
// ========================================
void core1_main(){ 
  //
  //  === add threads  ====================
  // for core 1
  pt_add_thread(protothread_vga) ;
  //pt_add_thread(protothread_serial) ;
  //
  // === initalize the scheduler ==========
  pt_schedule_start ;
  // NEVER exits
  // ======================================
}

// ========================================
// === core 0 main - REMOVED
// Main function is now in picow_udp_send_recv_data.c
// ========================================