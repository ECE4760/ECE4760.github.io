/**
 * @file bno055.h
 * @brief Header file for BNO055 9-DOF IMU sensor driver
 * 
 * Provides interface for reading accelerometer, gyroscope, and Euler angle
 * data from the Bosch BNO055 sensor via I2C.
 * 
 * Based on BNO055 datasheet and register map documentation.
 * Uses fixed-point arithmetic (15.16 format) for efficient computation.
 * 
 * ECE 4760 Final Project, Fall 2025
 * Authors: Sarah Zhong (sjz44), Gebran Kastoun (glk49), Ruby Wu (rcw253)
 * Cornell University
 */

#ifndef BNO055_H
#define BNO055_H

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h> // Added because of errors in bno055.c file but it's trying to include a cpp header file?
#include <math.h>
#include <string.h>
#include "hardware/i2c.h"
#include "pico/stdlib.h"

// I2C config for your board (same as old MPU: GPIO 8/9 on i2c0)
#define BNO055_ADDR    0x28      // or 0x29 if ADR is high
#define I2C_CHAN       i2c0
#define SDA_PIN        8
#define SCL_PIN        9
#define I2C_BAUD_RATE  400000

// 15.16 fixed point type (same as Hunter’s mpu6050.h)
typedef signed int fix15 ;
#define multfix15(a,b) ((fix15)(((( signed long long)(a))*(( signed long long)(b)))>>16))
#define float2fix15(a) ((fix15)((a)*65536.0f)) // 2^16
#define fix2float15(a) ((float)(a)/65536.0f)
#define int2fix15(a)   ((a)<<16)
#define fix2int15(a)   ((a)>>16)

// API
void bno055_init(void);
void bno055_read_raw(fix15 accel[3], fix15 gyro[3]);   // m/s^2 and rad/s-ish
void bno055_read_euler(fix15 euler[3]);                // heading, roll, pitch in deg

#endif
