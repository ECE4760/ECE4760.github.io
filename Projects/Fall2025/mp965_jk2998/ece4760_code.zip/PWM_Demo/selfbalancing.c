// main.c - Self-balancing robot using MPU6050 + L293D via 4N35 optos
// Throttled loop (~200 Hz) to avoid overloading CPU/USB


#include <stdio.h>
#include <math.h>


#include "pico/stdlib.h"
#include "hardware/pwm.h"
#include "hardware/i2c.h"
#include "hardware/clocks.h"


#include "mpu6050.h"   // Cornell driver: fix15, multfix15, float2fix15, fix2float15, oneeightyoverpi, zeropt001, zeropt999, etc.


// ==== Motor pins ====
//
// IMPORTANT: these are PICO -> 4N35 LED pins, not direct to L293D.
// L293D side is: 4N35 collector -> L293D input + 10k to 5V, emitter -> motor GND


// PWM EN pins (Pico -> 4N35 LEDs -> L293D enables)
#define EN1_PIN   15   // L293D 1,2EN -> left motor enable (via opto)
#define EN2_PIN   17   // L293D 3,4EN -> right motor enable (via opto)


// Direction pins (Pico -> 4N35 LEDs -> L293D inputs)
#define IN1_PIN   12   // 1A (left motor)
#define IN2_PIN   10   // 2A (left motor)
#define IN3_PIN   18   // 3A (right motor)
#define IN4_PIN   20   // 4A (right motor)


// ==== PWM config ====


#define PWM_WRAP   6000
#define PWM_CLKDIV 25.0f   // 125MHz / 25 = 5MHz -> ~833 Hz PWM


typedef struct {
   uint slice;
   uint chan;
} pwm_out_t;


static pwm_out_t en1_pwm;   // EN1
static pwm_out_t en2_pwm;   // EN2


volatile int control = 0;
volatile int old_control = -1;


// ==== IMU / filter / PID state ====


fix15 acceleration[3], gyro[3];   // raw readings from driver


static fix15 accel_lp[3] = {0, 0, 0};
static fix15 complementary_angle = 0;  // in degrees, 15.16 fixed


static inline void accel_lowpass_update(void) {
   // alpha = 1/16
   accel_lp[0] = accel_lp[0] + ((acceleration[0] - accel_lp[0]) >> 4);
   accel_lp[1] = accel_lp[1] + ((acceleration[1] - accel_lp[1]) >> 4);
   accel_lp[2] = accel_lp[2] + ((acceleration[2] - accel_lp[2]) >> 4);
}


// PID gains (tune these!)
volatile float k_p = 800.0f;
volatile float k_i = 1.4f;
volatile float k_d = 40.0f;


static float integ = 0.0f;
static float prev_error = 0.0f;


volatile int target_angle_deg = 0;  // 0 = upright
volatile bool pid_enabled = true;


static inline void pid_reset(void) {
   integ = 0.0f;
   prev_error = 0.0f;
}


// ==== PWM helper ====


static pwm_out_t init_pwm_pin(uint gpio) {
   gpio_set_function(gpio, GPIO_FUNC_PWM);
   uint slice = pwm_gpio_to_slice_num(gpio);
   uint chan  = pwm_gpio_to_channel(gpio);


   pwm_set_clkdiv(slice, PWM_CLKDIV);
   pwm_set_wrap(slice, PWM_WRAP);
   pwm_set_enabled(slice, true);


   pwm_out_t out = { slice, chan };
   return out;
}


// ==== Motor helpers ====
//
// IMPORTANT: 4N35 + 10k pull-up makes L293D inputs ACTIVE-LOW:
//
//   Pico GPIO LOW  -> LED OFF  -> L293D input HIGH
//   Pico GPIO HIGH -> LED ON   -> L293D input LOW
//
// For direction, L293D wants:
//   Forward: INx = HIGH, INy = LOW
//   Reverse: INx = LOW, INy = HIGH
//
// So for forward we must drive:
//   GPIO(INx) = 0 (HIGH at L293D)
//   GPIO(INy) = 1 (LOW at L293D)
//
// For enables, L293D EN is active-HIGH, so with optos:
//   LED OFF  (GPIO LOW)  -> EN HIGH  (enabled)
//   LED ON   (GPIO HIGH) -> EN LOW   (disabled)
//
// That means we must INVERT the PWM: 0 = stop, max = full speed.


static void left_motor_set_dir(bool forward) {
   if (forward) {
       // Want IN1=HIGH, IN2=LOW at L293D
       gpio_put(IN1_PIN, 0);  // LED OFF -> IN1 HIGH
       gpio_put(IN2_PIN, 1);  // LED ON  -> IN2 LOW
   } else {
       // Reverse: IN1=LOW, IN2=HIGH
       gpio_put(IN1_PIN, 1);  // LED ON  -> IN1 LOW
       gpio_put(IN2_PIN, 0);  // LED OFF -> IN2 HIGH
   }
}


static void right_motor_set_dir(bool forward) {
   if (forward) {
       // Want IN3=HIGH, IN4=LOW at L293D
       gpio_put(IN3_PIN, 0);  // LED OFF -> IN3 HIGH
       gpio_put(IN4_PIN, 1);  // LED ON  -> IN4 LOW
   } else {
       // Reverse: IN3=LOW, IN4=HIGH
       gpio_put(IN3_PIN, 1);  // LED ON  -> IN3 LOW
       gpio_put(IN4_PIN, 0);  // LED OFF -> IN4 HIGH
   }
}


static void motors_stop(void) {
   // Disable both motors by pulling EN pins LOW at L293D
   // -> LED ON 100% (PWM level = PWM_WRAP)
   pwm_set_chan_level(en1_pwm.slice, en1_pwm.chan, PWM_WRAP);
   pwm_set_chan_level(en2_pwm.slice, en2_pwm.chan, PWM_WRAP);


   // Optionally set directions to a known state
   gpio_put(IN1_PIN, 0);
   gpio_put(IN2_PIN, 0);
   gpio_put(IN3_PIN, 0);
   gpio_put(IN4_PIN, 0);
}


static void motors_init(void) {
   // Direction pins as outputs (to 4N35 LEDs)
   gpio_init(IN1_PIN);
   gpio_init(IN2_PIN);
   gpio_init(IN3_PIN);
   gpio_init(IN4_PIN);


   gpio_set_dir(IN1_PIN, GPIO_OUT);
   gpio_set_dir(IN2_PIN, GPIO_OUT);
   gpio_set_dir(IN3_PIN, GPIO_OUT);
   gpio_set_dir(IN4_PIN, GPIO_OUT);


   // Don't touch EN pins here; they will be set up as PWM later.
}


// ==== IMU init ====


static void imu_init(void) {
   i2c_init(I2C_CHAN, I2C_BAUD_RATE);
   gpio_set_function(SDA_PIN, GPIO_FUNC_I2C);
   gpio_set_function(SCL_PIN, GPIO_FUNC_I2C);
   gpio_pull_up(SDA_PIN);
   gpio_pull_up(SCL_PIN);


   mpu6050_reset();
   mpu6050_read_raw(acceleration, gyro);
}


// ==== main loop ====


int main() {
   set_sys_clock_khz(150000, true);


   stdio_init_all();
   sleep_ms(1000);
   printf("Self-balancing robot (throttled) starting...\n");


   // Init IMU
   imu_init();


   // Init motors (direction pins)
   motors_init();


   // EN pins as PWM outputs (to 4N35 LEDs)
   en1_pwm = init_pwm_pin(EN1_PIN);
   en2_pwm = init_pwm_pin(EN2_PIN);


   // Start with motors disabled: EN LOW at L293D
   pwm_set_chan_level(en1_pwm.slice, en1_pwm.chan, PWM_WRAP);  // LED ON 100% -> EN low
   pwm_set_chan_level(en2_pwm.slice, en2_pwm.chan, PWM_WRAP);


   motors_stop();
    // ... after motors_stop();


   absolute_time_t last = get_absolute_time();


   uint32_t last_print = to_ms_since_boot(get_absolute_time());
   int accel_counter = 0;


   while (true) {
       // 0) Compute dt based on real time
       absolute_time_t now_t = get_absolute_time();
       int64_t dt_us = absolute_time_diff_us(last, now_t);
       last = now_t;


       float dt = dt_us / 1e6f;   // seconds


       // 1) Read IMU
       mpu6050_read_raw(acceleration, gyro);
       accel_lowpass_update();


       // 2) Update angle via complementary filter
       float gyro_rate = fix2float15(gyro[0]);  // assume deg/s
       float angle_deg = fix2float15(complementary_angle);


       // integrate gyro (predict)
       angle_deg -= gyro_rate * dt;


       // use accel correction every few loops (approximate, since loop rate is variable now)
       if (++accel_counter >= 4) {
           accel_counter = 0;
           float ay = fix2float15(accel_lp[1]);
           float az = fix2float15(accel_lp[2]);
           float accel_deg = atan2f(ay, az) * (180.0f / (float)M_PI);
           accel_deg = -accel_deg;  // adjust sign as before


           // complementary blend: mostly gyro, a bit of accel
           const float alpha = 0.98f;
           angle_deg = alpha * angle_deg + (1.0f - alpha) * accel_deg;
       }


       // store back into fixed-point for compatibility
       complementary_angle = float2fix15(angle_deg);


       // 3) PID on angle
       float comp_deg = angle_deg;
       float error    = (float)target_angle_deg - comp_deg;


       // P
       float P = k_p * error;


       // I (with clamp)
       integ += error * dt;
       const float INTEG_MIN = -2000.0f;
       const float INTEG_MAX =  2000.0f;
       if (integ > INTEG_MAX) integ = INTEG_MAX;
       if (integ < INTEG_MIN) integ = INTEG_MIN;
       float I = k_i * integ;


       // D on gyro_rate (already deg/s)
       static float gyro_rate_f = 0.0f;
       const float alpha_d = 0.7f;
       gyro_rate_f = alpha_d * gyro_rate_f + (1.0f - alpha_d) * gyro_rate;
       float D = k_d * gyro_rate_f;


       float u = P + I + D;


       // 4) Apply to motors
       if (!pid_enabled) {
           pid_reset();
           control = 0;
           if (control != old_control) {
               old_control = control;
               motors_stop();
           }
       } else {
           bool forward = (u >= 0.0f);
           float mag = fabsf(u);


           if (mag > (float)PWM_WRAP) mag = (float)PWM_WRAP;
           int new_duty = (int)mag;


           const int MIN_DUTY = 600;
           if (new_duty > 0 && new_duty < MIN_DUTY) new_duty = MIN_DUTY;


           control = new_duty;


           if (control != old_control) {
               old_control = control;


               left_motor_set_dir(forward);
               right_motor_set_dir(forward);


               uint16_t pwm_level = (uint16_t)(PWM_WRAP - control);


               pwm_set_chan_level(en1_pwm.slice, en1_pwm.chan, pwm_level);
               pwm_set_chan_level(en2_pwm.slice, en2_pwm.chan, pwm_level);
           }
       }


       // 5) Print angle every 100 ms
       uint32_t now = to_ms_since_boot(get_absolute_time());
       if (now - last_print >= 100) {
           last_print = now;
           printf("Angle: %.2f deg, duty=%d, dt=%.6f\n", angle_deg, control, dt);
       }


       // 6) NO sleep here — loop is unthrottled
   }




   return 0;
}





