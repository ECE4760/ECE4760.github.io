// btstack_config.h - config for Pico W BLE robot

#ifndef _PICO_BTSTACK_BTSTACK_CONFIG_H
#define _PICO_BTSTACK_BTSTACK_CONFIG_H

// ---- Basic feature selection ----
// #define ENABLE_BLE            // we are only using BLE
#define ENABLE_LE_PERIPHERAL // Pico advertises and phone connects

#define ENABLE_LOG_INFO
#define ENABLE_LOG_ERROR
#define ENABLE_PRINTF_HEXDUMP

// LE secure connections
#define ENABLE_LE_SECURE_CONNECTIONS

// ---- Buffer & connection limits ----
#define HCI_OUTGOING_PRE_BUFFER_SIZE    4
#define HCI_ACL_CHUNK_SIZE_ALIGNMENT     4
#define HCI_ACL_PAYLOAD_SIZE           (255 + 4)

#define MAX_NR_HCI_CONNECTIONS          1
#define MAX_NR_SM_LOOKUP_ENTRIES        2
#define MAX_NR_WHITELIST_ENTRIES       16
#define MAX_NR_LE_DEVICE_DB_ENTRIES    16

#define MAX_NR_CONTROLLER_ACL_BUFFERS   3
#define MAX_NR_CONTROLLER_SCO_PACKETS   0

#define ENABLE_HCI_CONTROLLER_TO_HOST_FLOW_CONTROL
#define HCI_HOST_ACL_PACKET_LEN        (255 + 4)
#define HCI_HOST_ACL_PACKET_NUM         3
#define HCI_HOST_SCO_PACKET_LEN         0
#define HCI_HOST_SCO_PACKET_NUM         0

#define NVM_NUM_DEVICE_DB_ENTRIES      16
#define NVM_NUM_LINK_KEYS              16

#define MAX_ATT_DB_SIZE               512

// ---- Platform / timing ----
#define HAVE_EMBEDDED_TIME_MS
#define HAVE_ASSERT

#define HCI_RESET_RESEND_TIMEOUT_MS 1000

// ---- Crypto for LE secure connections ----
#define ENABLE_SOFTWARE_AES128
#define ENABLE_MICRO_ECC_FOR_LE_SECURE_CONNECTIONS

#endif // _PICO_BTSTACK_BTSTACK_CONFIG_H
