
/*
 Two-SG90 servo + HC-SR04 demo using PWM and protothreads
 Adapted from:
   V. Hunter Adams (vha3@cornell.edu) PWM demo code with serial input

 GPIO 2 (pan - left/right)
 GPIO 3 (tilt - up/down)

 servo control based on:    pwm-demo.c
 sensor control based on:   https://projecthub.arduino.cc/Isaac100/getting-started-with-the-hc-sr04-ultrasonic-sensor-7cabe1
 motor control based on:    https://randomnerdtutorials.com/raspberry-pi-pico-dc-motor-micropython/

LEFT MOTOR
IN1 = GPIO12 = left forward
IN2 = GPIO10 = left backward
RIGHT MOTOR
IN3 = GPIO18 = right forward
IN4 = GPIO20 = right backward

LED pins: r=11, g=12, b=13
Patrol=blue blink, follow=constant white; dance=off (for now)

A buzzer sound library for a passive piezo buzzer
logic and functions based on: https://www.tomshardware.com/desktops/pc-building/starforge-systems-collabs-with-frieren-for-a-fantastical-new-custom-pc-bundle

commands over ble char:
'C' → CONTROL (manual drive)
'1' → PATROL
'2' → FOLLOW
'3' → DANCE
'M' → advance to next autonomous mode (PATROL→FOLLOW→DANCE→PATROL)
mic:
'E' → enable clap-to-cycle
'D' → disable clap (mic ignored)
manual drive:
//   'F'     - forward
//   'B'     - backward
//   'L'     - turn left (spin in place)
//   'R'     - turn right (spin in place)
//   'S'     - stop
//   'Pxxx'  - pan servo angle 0–180 (e.g. "P090")
//   'Txxx'  - tilt servo angle 0–180 (e.g. "T045")
=============================================================
 */

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>

#include "pico/stdlib.h"
#include "hardware/pwm.h"
#include "hardware/irq.h"
#include "hardware/adc.h"
#include "hardware/i2c.h"

#include "pt_cornell_rp2040_v1_4.h"

// ble
#include "pico/cyw43_arch.h"
#include "btstack_config.h"
#include "btstack.h"
#include "ble/att_db_util.h"


// BLE UUIDs and globals
// Service UUID: F0EFCDAB-8967-4523-1234-785634127812
static const uint8_t robot_service_uuid[16] = {
    0xf0, 0xef, 0xcd, 0xab,
    0x89, 0x67, 0x45, 0x23,
    0x12, 0x34, 0x78, 0x56,
    0x34, 0x12, 0x78, 0x12
};

// Characteristic UUID: F1EFCDAB-8967-4523-1234-785634127812
static const uint8_t robot_char_uuid[16] = {
    0xf1, 0xef, 0xcd, 0xab,
    0x89, 0x67, 0x45, 0x23,
    0x12, 0x34, 0x78, 0x56,
    0x34, 0x12, 0x78, 0x12
};

static uint16_t robot_char_value_handle;

// RGB LED pins
#define LED_R 11
#define LED_G 14
#define LED_B 13

// GPIOs we're using for PWM
#define PWM_OUT_PAN   2 
#define PWM_OUT_TILT  3 

#define TRIG_PIN      6
#define ECHO_PIN      7

// a PWM frequency of 50 Hz.
#define WRAPVAL 19999
#define CLKDIV  125.0f

// Servo pulse range in counts (~1 ms to ~2 ms)
#define SERVO_MIN 500
#define SERVO_MAX 2000

// Buzzer defines and globals
#define BUZZER_PIN 4
#define VOLUME 60000

// MIC on ADC2 / GPIO28
#define MIC_PIN        28
#define MIC_ADC_CH     2
// #define CLAP_THRESHOLD  2800
#define MUSIC_THRESHOLD  2500
#define MIC_MUSIC_COUNT 60
volatile bool mic_enabled = false; // controlled from BLE

static uint buzzer_slice;
static uint buzzer_chan;

// Scan angles and distances
#define CENTER_ANGLE 135
#define LEFT_ANGLE 180
#define RIGHT_ANGLE 90

#define NUM_SCAN_ANGLES 5
#define MIN_VALID_CM 5.0f    
#define MAX_VALID_CM 150.0f
#define TOO_CLOSE_CM 15.0f
#define TOO_FAR_CM 50.0f

#define SERVO_SETTLE_MS 300 //time for servo to reach angle

#define TILT_A 0
#define TILT_B 20
#define CLEAR_DIST_CM 60.0f

// Variable to hold PWM slice number
uint slice_num;

// PWM duty cycle for pan and tilt
volatile int servo_pan_level;
volatile int old_servo_pan_level;
volatile int servo_tilt_level;
volatile int old_servo_tilt_level;

// motor defines
#define EN1_PIN   15
#define EN2_PIN   17
#define IN1  12
#define IN2   10
#define IN3   18
#define IN4   20

// lcd screen
#define I2C_PORT i2c1
#define SDA_PIN 26
#define SCL_PIN 27
#define LCD_ADDR 0x27
// P0 = RS, P1 = RW, P2 = EN, P3 = BACKLIGHT, P4–P7 = D4–D7
#define LCD_BACKLIGHT 0x08  // P3
#define LCD_EN        0x04  // P2
#define LCD_RW        0x02  // P1 (we keep this 0)
#define LCD_RS        0x01  // P0

// lcd screen functions
static void lcd_write_nibble(uint8_t nibble, uint8_t mode) {
   uint8_t data[2];

   // EN high
   data[0] = (nibble & 0xF0) | mode | LCD_BACKLIGHT | LCD_EN;
   // EN low
   data[1] = (nibble & 0xF0) | mode | LCD_BACKLIGHT;

   int res = i2c_write_blocking(I2C_PORT, LCD_ADDR, data, 2, false);

   sleep_us(50); // small delay for LCD to latch
}

static void lcd_send(uint8_t val, uint8_t mode) {
   // High nibble
   lcd_write_nibble(val & 0xF0, mode);
   // Low nibble
   lcd_write_nibble((val << 4) & 0xF0, mode);
}

static void lcd_cmd(uint8_t cmd) {
   lcd_send(cmd, 0x00); // RS = 0
   if (cmd == 0x01 || cmd == 0x02) {
       // clear / home need > 1.5ms
       sleep_ms(3);
   } else {
       sleep_us(60);
   }
}

static void lcd_char(char c) {
   lcd_send(c, LCD_RS); // RS = 1 for data
}

static void lcd_print(const char *s) {
   while (*s) {
       lcd_char(*s++);
   }
}

static void lcd_init(void) {
   sleep_ms(50); // wait for LCD power-up

   // Force into 4-bit mode using only high nibble writes
   lcd_write_nibble(0x30, 0x00);
   sleep_ms(5);

   lcd_write_nibble(0x30, 0x00);
   sleep_ms(5);

   lcd_write_nibble(0x30, 0x00);
   sleep_ms(5);

   lcd_write_nibble(0x20, 0x00); // 4-bit mode
   sleep_ms(5);

   // Now in 4-bit mode – standard commands
   lcd_cmd(0x28); // 4-bit, 2 lines, 5x8 font
   lcd_cmd(0x0C); // display on, cursor off, blink off
   lcd_cmd(0x06); // entry mode: increment, no shift
   lcd_cmd(0x01); // clear display
   sleep_ms(5);
}

// robot modes
typedef enum {
    MODE_CONTROL = 0,
    MODE_PATROL = 1,    // avoid obstacles
    MODE_FOLLOW = 2,    // follow objects 
    MODE_DANCE = 3      // programmed movements
} robot_mode_t;

volatile int current_mode = MODE_CONTROL;
volatile int led_obstacle = 0;
absolute_time_t last_mode_change_time;


// MOTOR FUNCTIONS
void motors_enable(void) {
    gpio_put(EN1_PIN, 0);   // motor enabled
    gpio_put(EN2_PIN, 0);
}

void motors_disable(void) {
    gpio_put(EN1_PIN, 1);
    gpio_put(EN2_PIN, 1);
}

void motors_stop(void) {
    gpio_put(IN1, 0);
    gpio_put(IN2, 0);
    gpio_put(IN3, 0);
    gpio_put(IN4, 0);
}

void motors_forward(void) {
    motors_enable();
    gpio_put(IN1, 0);
    gpio_put(IN2, 1);
    gpio_put(IN3, 0);
    gpio_put(IN4, 1);
}

void motors_backward(void) {
    gpio_put(IN1, 1);
    gpio_put(IN2, 0);
    gpio_put(IN3, 1);
    gpio_put(IN4, 0);
}

void motors_turn_left(void) {
    gpio_put(IN1, 1);
    gpio_put(IN2, 0);
    gpio_put(IN3, 0);
    gpio_put(IN4, 1);
}

void motors_turn_right(void) {
    gpio_put(IN1, 0);
    gpio_put(IN2, 1);
    gpio_put(IN3, 1);
    gpio_put(IN4, 0);
}

// LED HELPERS
void led_set(int r, int g, int b) {
    gpio_put(LED_R, r);
    gpio_put(LED_G, g);
    gpio_put(LED_B, b);
}

void led_off(void) {
    led_set(0, 0, 0);
}


// ========= Buzzer Library =========
void buzzer_init(void) {
    gpio_set_function(BUZZER_PIN, GPIO_FUNC_PWM);
    buzzer_slice = pwm_gpio_to_slice_num(BUZZER_PIN);
    buzzer_chan  = pwm_gpio_to_channel(BUZZER_PIN);
    pwm_set_enabled(buzzer_slice, false);
}

// freq: 300-3000 Hz
// duration_ms: how long to play sound for
// volume: 0-65535
void buzzer_tone(uint freq, uint duration_ms, uint16_t volume) {
    if (freq == 0 || volume == 0){
        pwm_set_enabled(buzzer_slice, false);
        sleep_ms(duration_ms);
        return;
    }

    const uint32_t f_sys = 125000000;
    float clkdiv = 4.0f;
    uint32_t wrap = (uint32_t)( (float)f_sys / (clkdiv * freq) ) - 1;

    if (wrap > 65535) {
        wrap = 65535;
    }
    if (wrap < 10) {
        wrap = 10;
    }
    pwm_set_clkdiv(buzzer_slice, clkdiv);
    pwm_set_wrap(buzzer_slice, wrap);

    uint32_t level = (wrap * (uint32_t)volume) / 65535;
    pwm_set_chan_level(buzzer_slice, buzzer_chan, level);

    pwm_set_enabled(buzzer_slice, true);
    sleep_ms(duration_ms);
    pwm_set_enabled(buzzer_slice, false);
}

// helper: angle (0–180) to pulse width
int angle_to_level(int angle_deg) {
    if (angle_deg < 0) angle_deg = 0;
    if (angle_deg > 180) angle_deg = 180;
    float t = angle_deg / 180.0f;
    return (int)(SERVO_MIN + t * (SERVO_MAX - SERVO_MIN));
}

static void servo_pan_set_angle(int angle_deg) {
    servo_pan_level = angle_to_level(angle_deg);
}

static void servo_tilt_set_angle(int angle_deg) {
    servo_tilt_level = angle_to_level(180 - angle_deg);
}

// ============ robot sounds ============
// like a button click
void beep_short(void) {
    buzzer_tone(2000, 80, VOLUME);
}

// friendly startup chime
void beep_ok(void) {
    buzzer_tone(1200, 80, VOLUME);
    sleep_ms(40);
    buzzer_tone(1600, 120, VOLUME);
}

// error/warning tone
void beep_error(void) {
    buzzer_tone(600, 150, VOLUME);
    sleep_ms(60);
    buzzer_tone(350, 200, VOLUME);
}

// 3 sharp alarm beeps
void beep_obstacle(void) {
    for (int i = 0; i < 3; i++) {
        buzzer_tone(1500, 100, VOLUME);
        sleep_ms(80);
    }
}

void beep_thinking(void) {
    buzzer_tone(350, 100, VOLUME);
    sleep_ms(40);
    buzzer_tone(450, 120, VOLUME);
}

// mode cycle button press - mode-switch chime
void beep_mode_change(void) {
    buzzer_tone(1000, 60, VOLUME);
    sleep_ms(40);
    buzzer_tone(1400, 80, VOLUME);
}

//ascending trill - entering dance mode/celebrating
void beep_dance(void) {
    uint freqs[] = {800, 1000, 1200, 1400, 1600};
    for (int i = 0; i < 5; i++) {
        buzzer_tone(freqs[i], 60, VOLUME);
        sleep_ms(20);
    }
}

void lcd_show_mode(void) {
    // clear display
    lcd_cmd(0x01);
    // go to first line, position 0
    lcd_cmd(0x80);

    lcd_print("Mode: ");

    switch (current_mode) {
        case MODE_CONTROL:
            lcd_print("CONTROL");
            break;
        case MODE_PATROL:
            lcd_print("PATROL");
            break;
        case MODE_FOLLOW:
            lcd_print("FOLLOW");
            break;
        case MODE_DANCE:
            lcd_print("DANCE");
            break;
        default:
            lcd_print("TIMMY");
            break;
    }
}

void lcd_show_obstacle(void) {
    lcd_cmd(0x01);        // clear
    lcd_cmd(0x80);        // first line
    lcd_print("Obstacle!");
}

// flash "Obstacle!" briefly; then restore mode
void lcd_flash_obstacle(void) {
    lcd_show_obstacle();
    sleep_ms(400);
    lcd_show_mode();
}


void change_mode(void) {
    absolute_time_t now = get_absolute_time();

    // 300 ms cooldown between mode changes
    if (absolute_time_diff_us(last_mode_change_time, now) < 300000) {
        return;
    }
    last_mode_change_time = now;
    
    // clap/app cycle only the autonomous modes: 
    if (current_mode == MODE_PATROL) {
        current_mode = MODE_FOLLOW;
    } else if (current_mode == MODE_FOLLOW) {
        current_mode = MODE_DANCE;
    } else {
        current_mode = MODE_PATROL;
    }

    beep_mode_change();

    const char *mode_name = "PATROL";
    if (current_mode == MODE_FOLLOW) {
        mode_name = "FOLLOW";
    } else if (current_mode == MODE_DANCE) {
        mode_name = "DANCE";
        beep_dance();
    } else if (current_mode == MODE_CONTROL) {
        mode_name = "CONTROL";
    }

    // printf("[MODE] Now %s\n", mode_name);
    lcd_show_mode();
}

// ble-facing servo helpers (reuse pwm) - Hunter Adam's bluetooth code with assistance from AI code generation
// att write callback - ble command handler
static int att_write_callback(hci_con_handle_t connection_handle,
                              uint16_t attribute_handle,
                              uint16_t transaction_mode,
                              uint16_t offset,
                              uint8_t *buffer,
                              uint16_t buffer_size)
{
    (void)connection_handle;
    (void)transaction_mode;
    (void)offset;

    if (buffer_size == 0) return 0;

    char first = buffer[0];
    char printable = (first >= 32 && first <= 126) ? first : '?';

    printf("[BLE] Write on handle 0x%04x, len=%u, first='%c'\n",
           attribute_handle, buffer_size, printable);

    printf("       data:");
    for (uint16_t i = 0; i < buffer_size; i++) {
        printf(" %02X", buffer[i]);
    }
    printf("\n");

    char cmd = buffer[0];

    // ----- Single-letter commands -----
    if (buffer_size == 1) {
        switch (cmd) {

            // ===== Mode selection from app =====
            case 'C':   // CONTROL
                printf("[BLE] MODE: CONTROL\n");
                current_mode = MODE_CONTROL;
                motors_stop();
                beep_mode_change();
                sprintf(pt_serial_out_buffer, "Mode: CONTROL\r\n");
                // serial_write;
                 lcd_show_mode();
                break;

            case '1':   // PATROL
                printf("[BLE] MODE: PATROL\n");
                current_mode = MODE_PATROL;
                motors_stop();
                beep_mode_change();
                sprintf(pt_serial_out_buffer, "Mode: PATROL\r\n");
                // serial_write;
                lcd_show_mode();
                break;

            case '2':   // FOLLOW
                printf("[BLE] MODE: FOLLOW\n");
                current_mode = MODE_FOLLOW;
                motors_stop();
                beep_mode_change();
                sprintf(pt_serial_out_buffer, "Mode: FOLLOW\r\n");
                // serial_write;
                lcd_show_mode();
                break;

            case '3':   // DANCE
                printf("[BLE] MODE: DANCE\n");
                current_mode = MODE_DANCE;
                motors_stop();
                beep_mode_change();
                beep_dance();
                sprintf(pt_serial_out_buffer, "Mode: DANCE\r\n");
                // serial_write;
                lcd_show_mode();
                break;

            case 'M':   // optional: cycle modes from app (same as clap)
                printf("[BLE] CMD: MODE CYCLE\n");
                change_mode();
                break;

            // ===== Mic enable/disable from app =====
            case 'E':   // Enable mic
                mic_enabled = true;
                printf("[BLE] MIC ENABLED\n");
                sprintf(pt_serial_out_buffer, "Mic: ENABLED\r\n");
                // serial_write;
                break;

            case 'D':   // Disable mic
                mic_enabled = false;
                printf("[BLE] MIC DISABLED\n");
                sprintf(pt_serial_out_buffer, "Mic: DISABLED\r\n");
                // serial_write;
                break;

            // ===== Manual motion commands (only in CONTROL) =====
            case 'F':
                if (current_mode == MODE_CONTROL) {
                    printf("[BLE] CMD: FORWARD\n");
                    motors_forward();
                } else {
                    printf("[BLE] Ignoring FORWARD (not in CONTROL)\n");
                }
                break;

            case 'B':
                if (current_mode == MODE_CONTROL) {
                    printf("[BLE] CMD: BACKWARD\n");
                    motors_backward();
                } else {
                    printf("[BLE] Ignoring BACKWARD (not in CONTROL)\n");
                }
                break;

            case 'L':
                if (current_mode == MODE_CONTROL) {
                    printf("[BLE] CMD: LEFT\n");
                    motors_turn_left();
                } else {
                    printf("[BLE] Ignoring LEFT (not in CONTROL)\n");
                }
                break;

            case 'R':
                if (current_mode == MODE_CONTROL) {
                    printf("[BLE] CMD: RIGHT\n");
                    motors_turn_right();
                } else {
                    printf("[BLE] Ignoring RIGHT (not in CONTROL)\n");
                }
                break;

            case 'S':
                // STOP always works (emergency stop)
                printf("[BLE] CMD: STOP\n");
                motors_stop();
                break;

            default:
                printf("[BLE] Unknown command '%c'\n", cmd);
                break;
        }
        return buffer_size;
    }

    // ----- Servo commands: Pxxx / Txxx (e.g. "P090") -----
    if ((cmd == 'P' || cmd == 'T') && buffer_size >= 4) {

        if (current_mode != MODE_CONTROL) {
            printf("[BLE] Ignoring servo command (not in CONTROL)\n");
            return buffer_size;
        }

        int angle = (buffer[1] - '0') * 100 +
                    (buffer[2] - '0') * 10  +
                    (buffer[3] - '0');

        if (angle < 0)   angle = 0;
        if (angle > 180) angle = 180;

        if (cmd == 'P') {
            printf("[BLE] PAN command: %d\n", angle);
            servo_pan_set_angle(angle);
        } else {
            printf("[BLE] TILT command: %d\n", angle);
            servo_tilt_set_angle(angle);
        }

        return buffer_size;
    }

    printf("[BLE] Unrecognized payload for command '%c'\n", cmd);
    return buffer_size;
}

// ble event handler (logging only)
static void packet_handler(uint8_t packet_type, uint16_t channel,
                           uint8_t *packet, uint16_t size)
{
    (void)channel;
    (void)size;

    if (packet_type != HCI_EVENT_PACKET) return;

    uint8_t event = hci_event_packet_get_type(packet);
    switch (event) {
        case BTSTACK_EVENT_STATE:
            if (btstack_event_state_get_state(packet) == HCI_STATE_WORKING) {
                printf("[BLE] HCI_STATE_WORKING, advertising enabled\n");
            }
            break;
        default:
            break;
    }
}

// build att database at runtime
static void att_db_init_robot(void)
{
    att_db_util_init();

    // Add primary service
    att_db_util_add_service_uuid128(robot_service_uuid);

    // Add writable characteristic (write / write without response / dynamic)
    robot_char_value_handle = att_db_util_add_characteristic_uuid128(
        robot_char_uuid,
        ATT_PROPERTY_WRITE | ATT_PROPERTY_WRITE_WITHOUT_RESPONSE | ATT_PROPERTY_DYNAMIC,
        ATT_SECURITY_NONE,   // read
        ATT_SECURITY_NONE,   // write
        NULL,
        0
    );

    printf("[ATT] Robot characteristic handle = 0x%04x\n", robot_char_value_handle);
}

static void ble_init_robot(void)
{
    // Init CYW43 (WiFi/BLE chip)
    if (cyw43_arch_init()) {
        printf("Failed to init cyw43_arch\n");
        return;
    }
    cyw43_arch_gpio_put(CYW43_WL_GPIO_LED_PIN, 1); // onboard LED ON

    // Init BTstack
    l2cap_init();
    sm_init();

    // Build ATT DB
    att_db_init_robot();

    // GATT server
    att_server_init(att_db_util_get_address(), NULL, att_write_callback);

    // Register minimal HCI event handler
    static btstack_packet_callback_registration_t hci_cb;
    hci_cb.callback = &packet_handler;
    hci_add_event_handler(&hci_cb);

    // Advertise as "PicoRobot"
    uint8_t adv_data[] = {
        0x02, BLUETOOTH_DATA_TYPE_FLAGS,
        0x06, // LE General Discoverable Mode, BR/EDR not supported
        0x0A, BLUETOOTH_DATA_TYPE_COMPLETE_LOCAL_NAME,
        'P','i','c','o','R','o','b','o','t'
    };

    gap_advertisements_set_data(sizeof(adv_data), adv_data);
    gap_advertisements_set_params(
        0x0030, // min interval
        0x0060, // max interval
        0,      // adv type
        0,      // direct addr type
        NULL,   // direct addr
        0x07,   // channel map
        0x00    // filter policy
    );
    gap_advertisements_enable(1);

    printf("[BLE] Advertising as 'PicoRobot'\n");

    // Turn Bluetooth controller on
    hci_power_control(HCI_POWER_ON);
}
// end AI code generation

// PWM interrupt service routine
void on_pwm_wrap() {
    // Clear the interrupt flag that brought us here
    pwm_clear_irq(slice_num);

    // Update duty cycle: pan = channel A
    if (servo_pan_level != old_servo_pan_level) {
        old_servo_pan_level = servo_pan_level;
        pwm_set_chan_level(slice_num, PWM_CHAN_A, servo_pan_level);
    }

    // Update duty cycle: tilt = channel B
    if (servo_tilt_level != old_servo_tilt_level) {
        old_servo_tilt_level = servo_tilt_level;
        pwm_set_chan_level(slice_num, PWM_CHAN_B, servo_tilt_level);
    }
}

float sensor_read_cm(void) {
    const int32_t timeout_us = 30000; // ~5m max range
   
    // make sure trigger = low
    gpio_put(TRIG_PIN, 0);
    sleep_us(2);

    // send 10 us trigger pulse
    gpio_put(TRIG_PIN, 1);
    sleep_us(10);
    gpio_put(TRIG_PIN, 0);

    // wait for echo to go high; start of pulse
    absolute_time_t t0 = get_absolute_time();
    while (gpio_get(ECHO_PIN) == 0) {
        // no echo
        if (absolute_time_diff_us(t0, get_absolute_time()) > timeout_us) {
            return -1.0f;
        }
    }

    // echo is high: measure how long
    absolute_time_t echo_start = get_absolute_time();
    while (gpio_get(ECHO_PIN) == 1) {
        // echo is too long = out of range
        if (absolute_time_diff_us(echo_start, get_absolute_time()) > timeout_us) {
            return -1.0f;
        }
    }
    absolute_time_t echo_end = get_absolute_time();
    // compute pulse width in us
    int64_t pulse_width_us = absolute_time_diff_us(echo_start, echo_end);

    // convert time to distance in cm
    // speed of sound = 343 m/s; round-trip time formula simplifies to time_us/58
    float distance_cm = pulse_width_us / 58.0f;
    return distance_cm;
}

// MODE FUNCTIONS
#define TURN_STEP_MS      200
#define TURN_MAX_STEPS    5
#define TURN_CLEAR_DIST   CLEAR_DIST_CM + 5
static int patrol_step_counter = 0;

void mode_patrol( float d_cm )
{
    led_obstacle = 0;

    if ( d_cm < 0.0f ) {
        d_cm = sensor_read_cm();
        if ( d_cm < 0.0f)  {
            d_cm = CLEAR_DIST_CM + 5;
        }
    }

    // clear path: go and maybe do a quick scan
    if ( d_cm > CLEAR_DIST_CM ) {

        patrol_step_counter++;

        // every ~60 cycles, do a quick scan (human-like behavior))
        if ( patrol_step_counter > 60 && (rand() % 3 == 0) ) {
            patrol_step_counter = 0;
            motors_stop();
            beep_thinking(); 

            // quick glance left/right
            servo_pan_level = angle_to_level( LEFT_ANGLE / 2 );
            sleep_ms(150);
            servo_pan_level = angle_to_level( RIGHT_ANGLE / 2 );
            sleep_ms(150);
            servo_pan_level = angle_to_level( CENTER_ANGLE );
            sleep_ms(150);
        }

        motors_forward();
        return;
    }

    // obstacle detected
    motors_stop();
    led_obstacle = 1;
    beep_obstacle();
    lcd_flash_obstacle();

    // back up a bit
    motors_backward();
    sleep_ms(300);
    motors_stop();

    // pan left and measure
    servo_pan_level = angle_to_level( LEFT_ANGLE );
    sleep_ms( SERVO_SETTLE_MS );
    float d_left = sensor_read_cm();
    if ( d_left < 0.0f ) d_left = 0.0f;

    // pan right and measure
    servo_pan_level = angle_to_level( RIGHT_ANGLE );
    sleep_ms( SERVO_SETTLE_MS );
    float d_right = sensor_read_cm();
    if ( d_right < 0.0f ) d_right = 0.0f;

    // recenter head
    servo_pan_level = angle_to_level( CENTER_ANGLE );
    sleep_ms( SERVO_SETTLE_MS );

    int turn_left = 1;
    if ( d_left > d_right && d_left > 15.0f ) {
        turn_left = 1;
    } else if ( d_right >= d_left && d_right > 15.0f ) {
        turn_left = 0;
    } else {
        // if both are bad, default to left
        turn_left = 1;
    }

    // step-turn with distance checks
    for ( int step = 0; step < TURN_MAX_STEPS; step++ ) {

        if ( turn_left )
            motors_turn_left();
        else
            motors_turn_right();

        sleep_ms( TURN_STEP_MS );
        motors_stop();
        sleep_ms(40);    // short pause before measuring

        float d = sensor_read_cm();
        if ( d > TURN_CLEAR_DIST ) {
            break; // can stop turning
        }
    }

    motors_stop();
    led_obstacle = 0;
}

// FOLLOW mode internal state
typedef enum {
    FOLLOW_STATE_SCAN = 0,
    FOLLOW_STATE_TRACK = 1
} follow_state_t;

static follow_state_t follow_state = FOLLOW_STATE_SCAN;
static int  follow_scan_angle = CENTER_ANGLE;
static int  follow_scan_dir   = 1;      // +1 = toward LEFT_ANGLE, -1 = toward RIGHT_ANGLE
static int  follow_detect_count = 0;    // consecutive "good" detections
static int  follow_lost_count   = 0;    // consecutive "lost" readings
static absolute_time_t follow_scan_start;
static bool follow_initialized = false;


void mode_follow( float d_cm )
{
    led_obstacle = 0;

    // Always keep head centered in FOLLOW mode
    servo_pan_level = angle_to_level( CENTER_ANGLE );

    // If distance is invalid or out of reasonable range, just stop.
    if ( d_cm <= 0.0f || d_cm < MIN_VALID_CM || d_cm > MAX_VALID_CM ) {
        motors_stop();
        led_obstacle = 0;
        return;
    }

    // We have a valid center distance. Use it to maintain a "following band".
    //   - If too far away -> move forward
    //   - If too close    -> back up
    //   - Otherwise       -> stop and hold position

    if ( d_cm > TOO_FAR_CM ) {
        // too far, move closer
        motors_forward();
        led_obstacle = 0;
    }
    else if ( d_cm < TOO_CLOSE_CM ) {
        // too close, back away
        motors_backward();
        led_obstacle = 1;
    }
    else {
        // good following distance
        motors_stop();
        led_obstacle = 0;
    }
}

// dance function
void mode_dance(float d_cm) {
    (void)d_cm;

    static int step = 0;
    static absolute_time_t t0;

    if (step == 0) {
        t0 = get_absolute_time();
        step = 1;
    }

    if (absolute_time_diff_us(t0, get_absolute_time()) < 250000)
        return;
    t0 = get_absolute_time();

    switch (step) {
        case 1:
            servo_pan_set_angle(LEFT_ANGLE);
            motors_turn_left();
            led_set(1,0,1);
            step = 2;
            break;

        case 2:
            servo_pan_set_angle(RIGHT_ANGLE);
            motors_turn_right();
            led_set(0,1,1);
            step = 3;
            break;

        case 3:
            motors_stop();
            servo_pan_set_angle(LEFT_ANGLE);
            led_set(1,1,1);
            step = 4;
            break;

        case 4:
            servo_pan_set_angle(RIGHT_ANGLE);
            step = 5;
            break;

        case 5:
            servo_pan_set_angle(CENTER_ANGLE);
            step = 6;
            break;

        case 6:
            servo_tilt_set_angle(110);
            motors_forward();
            led_set(1,1,0);
            step = 7;
            break;

        case 7:
            servo_tilt_set_angle(70);
            motors_backward();
            step = 8;
            break;

        case 8:
            servo_tilt_set_angle(90);
            motors_stop();
            step = 1;
            break;
    }
}

// User input thread
// ask for angles, set servos
static PT_THREAD (protothread_serial(struct pt *pt))
{
    PT_BEGIN(pt);
    static int pan_angle, tilt_angle;
    while (1) {
        sprintf(pt_serial_out_buffer,
                "input pan and tilt angles (0-180 0-180): ");
        serial_write;
        // spawn a thread to do the non-blocking serial read
        serial_read;
        // convert input string to number
        if (sscanf(pt_serial_in_buffer, "%d %d", &pan_angle, &tilt_angle) != 2)
            continue;
        if (pan_angle < 0 || pan_angle > 180) continue;
        if (tilt_angle < 0 || tilt_angle > 180) continue;

        // normal mapping for pan
        servo_pan_level = angle_to_level(pan_angle);
        servo_tilt_level = angle_to_level(180 - tilt_angle);
    }
    PT_END(pt);
}

 static PT_THREAD (protothread_sensor(struct pt *pt))
{
    PT_BEGIN(pt);
    while (1) {
        float d_cm;

        if (current_mode == MODE_CONTROL) {
            d_cm = sensor_read_cm();
            if (d_cm < 0.0f) {
                sprintf(pt_serial_out_buffer, "Distance: --- (no echo)\r\n");
            } else {
                sprintf(pt_serial_out_buffer, "Distance: %.1f cm (CONTROL)\r\n", d_cm);
            }
            serial_write;

            PT_YIELD_usec(50000);
            continue;   // skip the rest of the loop
        }

        if (current_mode == MODE_PATROL) {
            servo_tilt_level = angle_to_level(TILT_B);
        } else {
            servo_tilt_level = angle_to_level(TILT_A);
        }

        d_cm = sensor_read_cm();
        
        if (current_mode == MODE_DANCE) {
            if (d_cm < 0.0f) {
                sprintf(pt_serial_out_buffer, "Distance: --- (no echo)\r\n");
            } else {
                sprintf(pt_serial_out_buffer, "Distance: %.1f cm\r\n", d_cm);
            }
            serial_write;

            mode_dance(50.0f);         // ignore actual distance for dance
            PT_YIELD_usec(50000);
            continue;
        }

        // For PATROL / FOLLOW, keep the safety logic
if (current_mode == MODE_PATROL) {
    // Let mode_patrol decide what to do with no-echo
    mode_patrol(d_cm);   // d_cm may be < 0; that's okay
    if (d_cm < 0.0f) {
        sprintf(pt_serial_out_buffer, "Distance: --- (no echo, PATROL)\r\n");
    } else {
        sprintf(pt_serial_out_buffer, "Distance: %.1f cm (PATROL)\r\n", d_cm);
    }
}
else if (current_mode == MODE_FOLLOW) {
    // Keep safety for FOLLOW
    if (d_cm < 0.0f) {
        motors_stop(); // SAFETY
        sprintf(pt_serial_out_buffer, "Distance: --- (no echo, FOLLOW STOP)\r\n");
    } else {
        mode_follow(d_cm);
        sprintf(pt_serial_out_buffer, "Distance: %.1f cm (FOLLOW)\r\n", d_cm);
    }
}

serial_write;

        PT_YIELD_usec(50000); // 50 ms update rate
    }
    PT_END(pt);
}


static PT_THREAD (protothread_led(struct pt *pt))
{
    PT_BEGIN(pt);
    while (1) {
        if (led_obstacle) {
            led_set(1, 0, 0); 
            PT_YIELD_usec(100000); // 100 ms then check again
            continue;
        }

        if (current_mode == MODE_PATROL) {
            // flash blue in patrol 
            led_set(0, 0, 1); 
            PT_YIELD_usec(200000);
            led_off(); 
            PT_YIELD_usec(200000);
        }
        else if (current_mode == MODE_FOLLOW) {
            // steady white
            led_set(1, 1, 1);
            PT_YIELD_usec(200000); 
        }
        else if (current_mode == MODE_DANCE) {
            // PLACEHOLDER
            led_off();
            PT_YIELD_usec(200000);
        }
        else if (current_mode == MODE_CONTROL) {
            // steady green = phone/BLE control mode
            led_set(0, 1, 0);
            PT_YIELD_usec(200000);
        }
    }
    PT_END(pt);
}

static PT_THREAD (protothread_mic(struct pt *pt))
{
    PT_BEGIN(pt);
    static uint16_t last_sample = 0;
    static int loud_count = 0; // track how long sound is loud

    while (1) {
        uint16_t sample = adc_read();

        if (mic_enabled) {
            // if (sample > CLAP_THRESHOLD && last_sample <= CLAP_THRESHOLD) {
            //     beep_short();
            //     change_mode();
            // }
            if (sample > MUSIC_THRESHOLD) {
                if (loud_count < 1000) loud_count++;
            } else if (loud_count > 0) {
                loud_count--;
            }
            if (loud_count > MIC_MUSIC_COUNT) {
                if (current_mode != MODE_DANCE) {
                    printf("[MIC] Music detected -> DANCE\n");
                    current_mode = MODE_DANCE;
                    motors_stop();
                    beep_dance();
                    sprintf(pt_serial_out_buffer, "Mode: DANCE (music)\r\n");
                    serial_write;
                }
            }
        }
        last_sample = sample;
        PT_YIELD_usec(5000);
    }
    PT_END(pt);
}

int main() {
    // Initialize stdio
    stdio_init_all();
    buzzer_init();
    beep_ok(); // startup chime

    adc_init();
    adc_gpio_init(MIC_PIN);
    adc_select_input(MIC_ADC_CH);

    // lcd
    i2c_init(I2C_PORT, 100 * 1000);
    gpio_set_function(SDA_PIN, GPIO_FUNC_I2C);
    gpio_set_function(SCL_PIN, GPIO_FUNC_I2C);
    gpio_pull_up(SDA_PIN);
    gpio_pull_up(SCL_PIN);

    lcd_init();
    lcd_print("Timmy Ready");

    ////////////////////////////////////////////////////////////////////////
    ///////////////////////// PWM CONFIGURATION ////////////////////////////
    ////////////////////////////////////////////////////////////////////////
    // Tell GPIO PWM_OUT that it is allocated to the PWM
    gpio_set_function(PWM_OUT_PAN,  GPIO_FUNC_PWM);
    gpio_set_function(PWM_OUT_TILT, GPIO_FUNC_PWM);

    slice_num = pwm_gpio_to_slice_num(PWM_OUT_PAN);

    // Mask our slice's IRQ output into the PWM block's single interrupt line,
    // and register our interrupt handler
    pwm_clear_irq(slice_num);
    pwm_set_irq_enabled(slice_num, true);
    irq_set_exclusive_handler(PWM_IRQ_WRAP, on_pwm_wrap);
    irq_set_enabled(PWM_IRQ_WRAP, true);

    // This section configures the period of the PWM signals
    pwm_set_wrap(slice_num, WRAPVAL);
    pwm_set_clkdiv(slice_num, CLKDIV);

    // start both at middle position (90 deg)
    servo_pan_level  = angle_to_level(CENTER_ANGLE);
    servo_tilt_level = angle_to_level(0);

    old_servo_pan_level  = -1; // force initial update
    old_servo_tilt_level = -1; // force initial update

    // This sets duty cycle
    pwm_set_chan_level(slice_num, PWM_CHAN_A, servo_pan_level);
    pwm_set_chan_level(slice_num, PWM_CHAN_B, servo_tilt_level);

    // Start the channel
    pwm_set_mask_enabled(1u << slice_num);

    gpio_init(TRIG_PIN);
    gpio_set_dir(TRIG_PIN, GPIO_OUT);
    gpio_put(TRIG_PIN, 0);

    gpio_init(ECHO_PIN);
    gpio_set_dir(ECHO_PIN, GPIO_IN);

    // Motor pins
    gpio_init(IN1);
    gpio_init(IN2);
    gpio_init(IN3);
    gpio_init(IN4);

    gpio_init(EN1_PIN);
    gpio_init(EN2_PIN);
    gpio_set_dir(EN1_PIN, GPIO_OUT);
    gpio_set_dir(EN2_PIN, GPIO_OUT);
    gpio_put(EN1_PIN, 0);
    gpio_put(EN2_PIN, 0);

    gpio_set_dir(IN1, GPIO_OUT);
    gpio_set_dir(IN2, GPIO_OUT);
    gpio_set_dir(IN3, GPIO_OUT);
    gpio_set_dir(IN4, GPIO_OUT);

    gpio_init(LED_R);
    gpio_init(LED_G);
    gpio_init(LED_B);
    gpio_set_dir(LED_R, GPIO_OUT);
    gpio_set_dir(LED_G, GPIO_OUT);
    gpio_set_dir(LED_B, GPIO_OUT);
    led_off();

    motors_stop();
    ble_init_robot();

    ////////////////////////////////////////////////////////////////////////
    ///////////////////////////// ROCK AND ROLL ////////////////////////////
    ////////////////////////////////////////////////////////////////////////
    pt_add_thread(protothread_serial);
    pt_add_thread(protothread_sensor);
    //pt_add_thread(protothread_led);
    pt_add_thread(protothread_mic);
    pt_schedule_start;
}

