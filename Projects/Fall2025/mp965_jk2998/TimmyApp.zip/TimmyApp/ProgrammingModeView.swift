//
//  ProgramBlockKind.swift
//  TimmyApp
//
//  Created by Junwoo Kwon on 12/11/25.
//

import SwiftUI


enum VariableComparison: String, CaseIterable, Hashable {
    case equal = "=="
    case notEqual = "≠"
    case less = "<"
    case lessOrEqual = "≤"
    case greater = ">"
    case greaterOrEqual = "≥"

    var label: String { rawValue }
}


enum ProgramBlockKind: Hashable {
    // Robot actions
    case motorTimed(direction: DPadDirection, seconds: Double)   // move for N seconds
    case motorContinuous(direction: DPadDirection)                // move until Stop
    case stop                                                     // send stop command
    case servo(pan: Int, tilt: Int)
    case wait(seconds: Double)

    // Variables
    case setVariable(name: String, value: Double)
    case changeVariable(name: String, delta: Double)

    // Structured control flow
    case ifStart(name: String, comparison: VariableComparison, value: Double)
    case endIf
    case loopStart(times: Int)
    case endLoop
}

struct ProgramBlock: Identifiable, Hashable {
    let id = UUID()
    var kind: ProgramBlockKind
}

// MARK: - Programming Mode view

struct ProgrammingModeView: View {
    @EnvironmentObject var bt: BluetoothManager
    @State private var currentBlockID: UUID? = nil
    @State private var blocks: [ProgramBlock] = [
        // Initialize a step counter
        ProgramBlock(kind: .setVariable(name: "step", value: 0)),

        // Loop 4 times: move forward + sidestep
        ProgramBlock(kind: .loopStart(times: 4)),
        ProgramBlock(kind: .motorTimed(direction: .up, seconds: 1.0)),    // forward 1s
        ProgramBlock(kind: .wait(seconds: 0.3)),
        ProgramBlock(kind: .motorTimed(direction: .right, seconds: 0.5)), // right 0.5s
        ProgramBlock(kind: .wait(seconds: 0.2)),
        ProgramBlock(kind: .changeVariable(name: "step", delta: 1)),      // step += 1
        ProgramBlock(kind: .endLoop),

        // If we've completed 4 steps, do a little servo "pose" and back up
        ProgramBlock(kind: .ifStart(name: "step", comparison: .greaterOrEqual, value: 4)),
        ProgramBlock(kind: .servo(pan: 150, tilt: 30)),
        ProgramBlock(kind: .wait(seconds: 0.5)),
        ProgramBlock(kind: .motorTimed(direction: .down, seconds: 1.0)),  // back 1s
        ProgramBlock(kind: .endIf)
    ]

    @State private var isRunning = false

    var body: some View {
        NavigationStack {
            VStack {
                if blocks.isEmpty {
                    Text("Add some blocks to create a program.")
                        .foregroundColor(.secondary)
                        .padding()
                } else {
                     List {
                        ForEach(Array(blocks.enumerated()), id: \.element.id) { index, block in
                            ProgramBlockRow(
                                block: $blocks[index],
                                isActive: block.id == currentBlockID
                            )
                        }
                        .onDelete { indexSet in
                            blocks.remove(atOffsets: indexSet)
                        }
                        .onMove { indices, newOffset in
                            blocks.move(fromOffsets: indices, toOffset: newOffset)
                        }
                        .moveDisabled(isRunning)
                        .deleteDisabled(isRunning)
                    }


                    .listStyle(.insetGrouped)
                }


                VStack(spacing: 12) {
                    ScrollView(.horizontal, showsIndicators: false) {
                        HStack(spacing: 8) {
                            Button { addTimedMoveBlock() } label: {
                                Label("Move (Timed)", systemImage: "clock.arrow.circlepath")
                                    .padding(.horizontal, 10)
                            }

                            Button { addContinuousMoveBlock() } label: {
                                Label("Move (Until Stop)", systemImage: "arrow.triangle.2.circlepath")
                                    .padding(.horizontal, 10)
                            }

                            Button { addStopBlock() } label: {
                                Label("Stop", systemImage: "stop.fill")
                                    .padding(.horizontal, 10)
                            }

                            Button { addServoBlock() } label: {
                                Label("Servo", systemImage: "scope")
                                    .padding(.horizontal, 10)
                            }

                            Button { addWaitBlock() } label: {
                                Label("Wait", systemImage: "hourglass")
                                    .padding(.horizontal, 10)
                            }

                            Button { addSetVariableBlock() } label: {
                                Label("Set Var", systemImage: "slider.horizontal.3")
                                    .padding(.horizontal, 10)
                            }

                            Button { addChangeVariableBlock() } label: {
                                Label("Change Var", systemImage: "arrow.up.arrow.down")
                                    .padding(.horizontal, 10)
                            }

                            Button { addIfStartBlock() } label: {
                                Label("If", systemImage: "questionmark.circle")
                                    .padding(.horizontal, 10)
                            }

                            Button { addEndIfBlock() } label: {
                                Label("End If", systemImage: "checkmark.rectangle")
                                    .padding(.horizontal, 10)
                            }

                            Button { addLoopStartBlock() } label: {
                                Label("Loop", systemImage: "repeat")
                                    .padding(.horizontal, 10)
                            }

                            Button { addEndLoopBlock() } label: {
                                Label("End Loop", systemImage: "arrow.uturn.left.square")
                                    .padding(.horizontal, 10)
                            }
                        }
                        .buttonStyle(.borderedProminent)
                        .disabled(isRunning || !bt.isConnected)
                        .padding(.horizontal, 4)
                    }

                    Button {
                        runProgram()
                    } label: {
                        Label(isRunning ? "Running…" : "Run Program",
                              systemImage: "play.fill")
                            .frame(maxWidth: .infinity)
                    }
                    .buttonStyle(.borderedProminent)
                    .tint(.green)
                    .disabled(isRunning || !bt.isConnected || blocks.isEmpty)
                }
                .padding()
            }
            .onTapGesture {
                UIApplication.shared.endEditing()   // dismiss keyboard anywhere
            }
            .navigationTitle("Programming Mode")
            .toolbar {
                EditButton()
            }
        }
    }

    // MARK: - Block helpers (add)

    private func addTimedMoveBlock() {
        blocks.append(ProgramBlock(kind: .motorTimed(direction: .up, seconds: 1.0)))
    }

    private func addContinuousMoveBlock() {
        blocks.append(ProgramBlock(kind: .motorContinuous(direction: .up)))
    }

    private func addStopBlock() {
        blocks.append(ProgramBlock(kind: .stop))
    }

    private func addServoBlock() {
        blocks.append(ProgramBlock(kind: .servo(pan: 90, tilt: 90)))
    }

    private func addWaitBlock() {
        blocks.append(ProgramBlock(kind: .wait(seconds: 0.5)))
    }

    private func addSetVariableBlock() {
        blocks.append(ProgramBlock(kind: .setVariable(name: "x", value: 0)))
    }

    private func addChangeVariableBlock() {
        blocks.append(ProgramBlock(kind: .changeVariable(name: "x", delta: 1)))
    }

    private func addIfStartBlock() {
        blocks.append(ProgramBlock(kind: .ifStart(name: "x", comparison: .greater, value: 0)))
    }

    private func addEndIfBlock() {
        blocks.append(ProgramBlock(kind: .endIf))
    }

    private func addLoopStartBlock() {
        blocks.append(ProgramBlock(kind: .loopStart(times: 3)))
    }

    private func addEndLoopBlock() {
        blocks.append(ProgramBlock(kind: .endLoop))
    }

    // MARK: - Run program with structured If/Loop

    private struct LoopFrame {
        var startIndex: Int
        var remaining: Int
    }

    private func runProgram() {
        guard bt.isConnected else { return }
        guard !blocks.isEmpty else { return }

        isRunning = true

        Task {
            var variables: [String: Double] = [:]
            var loopStack: [LoopFrame] = []

            // Put robot into control mode first
            bt.sendMotorCommand(RobotMode.control.bleCommand)

            var index = 0

            while index < blocks.count {
                if !bt.isConnected { break }

                let block = blocks[index]
                await MainActor.run {
                    currentBlockID = block.id
                }
                switch block.kind {

                case .ifStart(let name, let comparison, let value):
                    let current = variables[name] ?? 0
                    let condition = evaluate(lhs: current, op: comparison, rhs: value)

                    if condition {
                        // Run body as normal
                        index += 1
                    } else {
                        // Skip to matching End If
                        index = findMatchingEndIf(from: index)
                    }

                case .endIf:
                    // Just continue
                    index += 1

                case .loopStart(let times):
                    let clamped = max(0, min(times, 100))
                    if clamped <= 0 {
                        // Skip whole loop
                        index = findMatchingEndLoop(from: index)
                    } else {
                        // Enter loop: next block is body start
                        let frame = LoopFrame(startIndex: index + 1, remaining: clamped)
                        loopStack.append(frame)
                        index += 1
                    }

                case .endLoop:
                    if var top = loopStack.last {
                        if top.remaining > 1 {
                            top.remaining -= 1
                            loopStack[loopStack.count - 1] = top
                            index = top.startIndex
                        } else {
                            // Done with loop
                            loopStack.removeLast()
                            index += 1
                        }
                    } else {
                        // Unmatched EndLoop, just skip
                        index += 1
                    }

                default:
                    await execute(block: block, variables: &variables)
                    index += 1
                }
            }

            // Safety stop at the very end
            bt.sendMotorCommand(DPadDirection.stop.commandChar)
            


            await MainActor.run {
                currentBlockID = nil      // 👈 clear highlight
                isRunning = false
            }
        }
    }

    // MARK: - Control flow helpers

    private func evaluate(lhs: Double, op: VariableComparison, rhs: Double) -> Bool {
        switch op {
        case .equal:          return lhs == rhs
        case .notEqual:       return lhs != rhs
        case .less:           return lhs < rhs
        case .lessOrEqual:    return lhs <= rhs
        case .greater:        return lhs > rhs
        case .greaterOrEqual: return lhs >= rhs
        }
    }

    private func findMatchingEndIf(from startIndex: Int) -> Int {
        var depth = 1
        var i = startIndex + 1

        while i < blocks.count {
            switch blocks[i].kind {
            case .ifStart:
                depth += 1
            case .endIf:
                depth -= 1
                if depth == 0 {
                    return i + 1   // index AFTER the End If
                }
            default:
                break
            }
            i += 1
        }
        return blocks.count
    }

    private func findMatchingEndLoop(from startIndex: Int) -> Int {
        var depth = 1
        var i = startIndex + 1

        while i < blocks.count {
            switch blocks[i].kind {
            case .loopStart:
                depth += 1
            case .endLoop:
                depth -= 1
                if depth == 0 {
                    return i + 1
                }
            default:
                break
            }
            i += 1
        }
        return blocks.count
    }


    private func execute(block: ProgramBlock,
                         variables: inout [String: Double]) async {
        switch block.kind {

        case .motorTimed(let direction, let seconds):
            bt.sendMotorCommand(direction.commandChar)
            let clamped = max(0.1, min(seconds, 10.0))
            try? await Task.sleep(
                nanoseconds: UInt64(clamped * 1_000_000_000)
            )
            bt.sendMotorCommand(DPadDirection.stop.commandChar)

        case .motorContinuous(let direction):
            bt.sendMotorCommand(direction.commandChar)
            try? await Task.sleep(nanoseconds: 100_000_000)

        case .stop:
            bt.sendMotorCommand(DPadDirection.stop.commandChar)
            try? await Task.sleep(nanoseconds: 100_000_000)

        case .servo(let pan, let tilt):
            bt.sendPan(angle: pan)
            bt.sendTilt(angle: tilt)
            try? await Task.sleep(
                nanoseconds: UInt64(0.15 * 1_000_000_000)
            )

        case .wait(let seconds):
            let clamped = max(0.0, min(seconds, 10.0))
            try? await Task.sleep(
                nanoseconds: UInt64(clamped * 1_000_000_000)
            )

        case .setVariable(let name, let value):
            variables[name] = value

        case .changeVariable(let name, let delta):
            let current = variables[name] ?? 0
            variables[name] = current + delta

        case .ifStart, .endIf, .loopStart, .endLoop:
          
            break
        }
    }
}



struct ProgramBlockRow: View {
    @Binding var block: ProgramBlock
    var isActive: Bool

    private let moveDirections: [DPadDirection] = [.up, .down, .left, .right]

    var body: some View {
        Group {
            switch block.kind {
            case .motorTimed:
                motorTimedRow()

            case .motorContinuous:
                motorContinuousRow()

            case .stop:
                stopRow()

            case .servo(let pan, let tilt):
                servoRow(pan: pan, tilt: tilt)

            case .wait:
                waitRow()

            case .setVariable:
                setVariableRow()

            case .changeVariable:
                changeVariableRow()

            case .ifStart:
                ifStartRow()

            case .endIf:
                endIfRow()

            case .loopStart:
                loopStartRow()

            case .endLoop:
                endLoopRow()
            }
        }
        .padding(6)
        .background(
            RoundedRectangle(cornerRadius: 10)
                .fill(isActive ? Color.accentColor.opacity(0.15) : Color.clear)
        )
        .overlay(
            RoundedRectangle(cornerRadius: 10)
                .stroke(isActive ? Color.accentColor : Color.clear, lineWidth: 2)
        )
    }

    private func stringBinding(
        for doubleBinding: Binding<Double>
    ) -> Binding<String> {
        Binding<String>(
            get: {

                return String(doubleBinding.wrappedValue)
            },
            set: { newText in

                if newText.isEmpty {
                    doubleBinding.wrappedValue = 0
                } else if let value = Double(newText) {
                    doubleBinding.wrappedValue = value
                }
            }
        )
    }


    
    

    private func motorTimedRow() -> some View {
        let directionBinding = bindingForMotorTimedDirection()
        let secondsBinding = bindingForMotorTimedSeconds()

        return VStack(alignment: .leading, spacing: 8) {
            Text("Move (Timed)")
                .font(.headline)

            Picker("Direction", selection: directionBinding) {
                ForEach(moveDirections, id: \.self) { dir in
                    Image(systemName: dir.systemImageName)
                        .tag(dir)
                }
            }
            .pickerStyle(.segmented)

            HStack {
                Text("Duration")
                Spacer()
                TextField("Seconds", text: stringBinding(for: secondsBinding))
                    .keyboardType(.decimalPad)
                    .multilineTextAlignment(.trailing)
                    .frame(width: 80)
                Text("s")
                    .foregroundColor(.secondary)
            }
        }
    }

    private func motorContinuousRow() -> some View {
        let directionBinding = bindingForMotorContinuousDirection()

        return VStack(alignment: .leading, spacing: 8) {
            Text("Move (Until Stop)")
                .font(.headline)

            Picker("Direction", selection: directionBinding) {
                ForEach(moveDirections, id: \.self) { dir in
                    Image(systemName: dir.systemImageName)
                        .tag(dir)
                }
            }
            .pickerStyle(.segmented)

            Text("Keeps moving until a Stop block or the program ends.")
                .font(.caption)
                .foregroundColor(.secondary)
        }
    }

    private func stopRow() -> some View {
        HStack {
            Image(systemName: "stop.fill")
                .foregroundColor(.red)
            Text("Stop")
                .font(.headline)
            Spacer()
            Text("Stops motors")
                .font(.subheadline)
                .foregroundColor(.secondary)
        }
    }

    private func servoRow(pan: Int, tilt: Int) -> some View {
        VStack(alignment: .leading) {
            Text("Servo")
                .font(.headline)

            HStack {
                Text("Pan \(pan)°")
                Slider(
                    value: Binding(
                        get: { Double(pan) },
                        set: { updateServo(pan: Int($0), tilt: tilt) }
                    ),
                    in: 0...180
                )
            }

            HStack {
                Text("Tilt \(tilt)°")
                Slider(
                    value: Binding(
                        get: { Double(tilt) },
                        set: { updateServo(pan: pan, tilt: Int($0)) }
                    ),
                    in: 0...180
                )
            }
        }
    }

    private func waitRow() -> some View {
        let waitBinding = bindingForWaitSeconds()

        return HStack {
            Text("Wait")
                .font(.headline)

            Spacer()

            TextField("Seconds", text: stringBinding(for: waitBinding))
                .keyboardType(.decimalPad)
                .multilineTextAlignment(.trailing)
                .frame(width: 80)

            Text("s")
                .foregroundColor(.secondary)
        }
    }


    private func setVariableRow() -> some View {
        let nameBinding = bindingForSetVariableName()
        let valueBinding = bindingForSetVariableValue()

        return VStack(alignment: .leading, spacing: 6) {
            Text("Set Variable")
                .font(.headline)

            HStack {
                Text("Name")
                Spacer()
                TextField("name", text: nameBinding)
                    .textInputAutocapitalization(.never)
                    .autocorrectionDisabled()
                    .multilineTextAlignment(.leading)
                    .frame(width: 100)
            }

            HStack {
                Text("Value")
                Spacer()
                TextField("0", text: stringBinding(for: valueBinding))
                    .keyboardType(.decimalPad)
                    .multilineTextAlignment(.trailing)
                    .frame(width: 80)
            }
        }
    }

    private func changeVariableRow() -> some View {
        let nameBinding = bindingForChangeVariableName()
        let deltaBinding = bindingForChangeVariableDelta()

        return VStack(alignment: .leading, spacing: 6) {
            Text("Change Variable")
                .font(.headline)

            HStack {
                Text("Name")
                Spacer()
                TextField("name", text: nameBinding)
                    .textInputAutocapitalization(.never)
                    .autocorrectionDisabled()
                    .multilineTextAlignment(.leading)
                    .frame(width: 100)
            }

            HStack {
                Text("Delta")
                Spacer()
                TextField("+1",
                          value: deltaBinding,
                          format: .number)
                    .keyboardType(.decimalPad)
                    .multilineTextAlignment(.trailing)
                    .frame(width: 80)
            }
        }
    }



    private func ifStartRow() -> some View {
        let nameBinding = bindingForIfName()
        let valueBinding = bindingForIfValue()
        let comparisonBinding = bindingForIfComparison()

        return VStack(alignment: .leading, spacing: 8) {
            // Header
            HStack {
                Image(systemName: "questionmark.circle")
                    .foregroundColor(.blue)
                Text("If")
                    .font(.headline)
            }

            // Variable line
            HStack {
                Text("Variable")
                Spacer()
                TextField("name", text: nameBinding)
                    .textInputAutocapitalization(.never)
                    .autocorrectionDisabled()
                    .multilineTextAlignment(.leading)
                    .frame(width: 100)
            }

            // Condition line
            HStack(spacing: 8) {
                Text("Condition")
                Spacer()
                Picker("", selection: comparisonBinding) {
                    ForEach(VariableComparison.allCases, id: \.self) { op in
                        Text(op.label).tag(op)
                    }
                }
                .pickerStyle(.menu)


                TextField("0", value: valueBinding, format: .number)
                    .keyboardType(.decimalPad)
                    .multilineTextAlignment(.trailing)
                    .frame(width: 80)
            }

            Text("If false, skip all blocks until the matching End If.")
                .font(.caption)
                .foregroundColor(.secondary)
        }
    }


    private func endIfRow() -> some View {
        HStack {
            Image(systemName: "checkmark.rectangle")
                .foregroundColor(.blue)
            Text("End If")
                .font(.headline)
            Spacer()
        }
    }

    private func loopStartRow() -> some View {
        let timesBinding = bindingForLoopTimes()

        return HStack {
            Text("Loop")
                .font(.headline)

            Spacer()

            Text("Repeat")
            TextField("Times",
                      value: timesBinding,
                      format: .number)
                .keyboardType(.numberPad)
                .multilineTextAlignment(.trailing)
                .frame(width: 60)

            Text("x")
                .foregroundColor(.secondary)
        }
    }

    private func endLoopRow() -> some View {
        HStack {
            Image(systemName: "arrow.uturn.left.square")
                .foregroundColor(.purple)
            Text("End Loop")
                .font(.headline)
            Spacer()
        }
    }


    private func updateServo(pan: Int, tilt: Int) {
        block.kind = .servo(pan: pan, tilt: tilt)
    }

    // Timed move

    private func bindingForMotorTimedDirection() -> Binding<DPadDirection> {
        Binding<DPadDirection>(
            get: {
                if case .motorTimed(let dir, _) = block.kind {
                    return dir
                }
                return .up
            },
            set: { newDir in
                if case .motorTimed(_, let seconds) = block.kind {
                    block.kind = .motorTimed(direction: newDir, seconds: seconds)
                }
            }
        )
    }

    private func bindingForMotorTimedSeconds() -> Binding<Double> {
        Binding<Double>(
            get: {
                if case .motorTimed(_, let s) = block.kind {
                    return s
                }
                return 1.0
            },
            set: { newValue in
                let clamped = max(0.0, min(newValue, 10.0))
                if case .motorTimed(let direction, _) = block.kind {
                    block.kind = .motorTimed(direction: direction, seconds: clamped)
                }
            }
        )
    }

    // Continuous move

    private func bindingForMotorContinuousDirection() -> Binding<DPadDirection> {
        Binding<DPadDirection>(
            get: {
                if case .motorContinuous(let dir) = block.kind {
                    return dir
                }
                return .up
            },
            set: { newDir in
                if case .motorContinuous = block.kind {
                    block.kind = .motorContinuous(direction: newDir)
                }
            }
        )
    }

    // Wait

    private func bindingForWaitSeconds() -> Binding<Double> {
        Binding<Double>(
            get: {
                if case .wait(let s) = block.kind {
                    return s
                }
                return 0.5
            },
            set: { newValue in
                let clamped = max(0.0, min(newValue, 10.0))
                if case .wait = block.kind {
                    block.kind = .wait(seconds: clamped)
                }
            }
        )
    }

    // Set variable

    private func bindingForSetVariableName() -> Binding<String> {
        Binding<String>(
            get: {
                if case .setVariable(let name, _) = block.kind {
                    return name
                }
                return "x"
            },
            set: { newName in
                if case .setVariable(_, let value) = block.kind {
                    block.kind = .setVariable(name: newName, value: value)
                }
            }
        )
    }

    private func bindingForSetVariableValue() -> Binding<Double> {
        Binding<Double>(
            get: {
                if case .setVariable(_, let value) = block.kind {
                    return value
                }
                return 0
            },
            set: { newValue in
                if case .setVariable(let name, _) = block.kind {
                    block.kind = .setVariable(name: name, value: newValue)
                }
            }
        )
    }

    // Change variable

    private func bindingForChangeVariableName() -> Binding<String> {
        Binding<String>(
            get: {
                if case .changeVariable(let name, _) = block.kind {
                    return name
                }
                return "x"
            },
            set: { newName in
                if case .changeVariable(_, let delta) = block.kind {
                    block.kind = .changeVariable(name: newName, delta: delta)
                }
            }
        )
    }

    private func bindingForChangeVariableDelta() -> Binding<Double> {
        Binding<Double>(
            get: {
                if case .changeVariable(_, let delta) = block.kind {
                    return delta
                }
                return 1
            },
            set: { newValue in
                if case .changeVariable(let name, _) = block.kind {
                    block.kind = .changeVariable(name: name, delta: newValue)
                }
            }
        )
    }

    // If block

    private func bindingForIfName() -> Binding<String> {
        Binding<String>(
            get: {
                if case .ifStart(let name, _, _) = block.kind {
                    return name
                }
                return "x"
            },
            set: { newName in
                if case .ifStart(_, let op, let value) = block.kind {
                    block.kind = .ifStart(name: newName, comparison: op, value: value)
                }
            }
        )
    }

    private func bindingForIfValue() -> Binding<Double> {
        Binding<Double>(
            get: {
                if case .ifStart(_, _, let value) = block.kind {
                    return value
                }
                return 0
            },
            set: { newValue in
                if case .ifStart(let name, let op, _) = block.kind {
                    block.kind = .ifStart(name: name, comparison: op, value: newValue)
                }
            }
        )
    }

    private func bindingForIfComparison() -> Binding<VariableComparison> {
        Binding<VariableComparison>(
            get: {
                if case .ifStart(_, let op, _) = block.kind {
                    return op
                }
                return .greater
            },
            set: { newOp in
                if case .ifStart(let name, _, let value) = block.kind {
                    block.kind = .ifStart(name: name, comparison: newOp, value: value)
                }
            }
        )
    }

    // Loop

    private func bindingForLoopTimes() -> Binding<Int> {
        Binding<Int>(
            get: {
                if case .loopStart(let times) = block.kind {
                    return times
                }
                return 1
            },
            set: { newValue in
                let clamped = max(0, min(newValue, 100))
                block.kind = .loopStart(times: clamped)
            }
        )
    }
}

#Preview {
    ProgrammingModeView()
 }
