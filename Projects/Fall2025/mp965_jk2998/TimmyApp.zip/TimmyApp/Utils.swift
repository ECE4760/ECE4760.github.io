//
//  Utils.swift
//  TimmyApp
//
//  Created by Junwoo Kwon on 12/11/25.
//

import SwiftUI

extension UIApplication {
    func endEditing() {
        sendAction(#selector(UIResponder.resignFirstResponder),
                   to: nil, from: nil, for: nil)
    }
}
