import SwiftUI

// MARK: - D-pad model

enum DPadDirection: Hashable {
    case up, down, left, right, stop

    var commandChar: Character {
        switch self {
        case .up:    return "F" // forward
        case .down:  return "B" // backward
        case .left:  return "L" // turn left
        case .right: return "R" // turn right
        case .stop:  return "S" // stop 
        }
    }

    var systemImageName: String {
        switch self {
        case .up:    return "chevron.up"
        case .down:  return "chevron.down"
        case .left:  return "chevron.left"
        case .right: return "chevron.right"
        case .stop:  return "stop.fill"
        }
    }
}

// MARK: - Robot mode (matches firmware)

enum RobotMode: CaseIterable, Hashable {
    case control    // 'C'
    case patrol     // '1'
    case follow     // '2'
    case dance      // '3'

    var title: String {
        switch self {
        case .control: return "Control"
        case .patrol:  return "Patrol"
        case .follow:  return "Follow"
        case .dance:   return "Dance"
        }
    }

    var bleCommand: Character {
        switch self {
        case .control: return "C"
        case .patrol:  return "1"
        case .follow:  return "2"
        case .dance:   return "3"
        }
    }
}

// MARK: - Press & hold button style

struct PressAndHoldButtonStyle: ButtonStyle {
    var onPressChanged: (Bool) -> Void

    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .scaleEffect(configuration.isPressed ? 0.9 : 1.0)
            .opacity(configuration.isPressed ? 0.7 : 1.0)
            .animation(
                .spring(response: 0.2, dampingFraction: 0.7),
                value: configuration.isPressed
            )
            .onChange(of: configuration.isPressed) { isPressed in
                onPressChanged(isPressed)
            }
    }
}

// MARK: - Single D-pad direction button

struct DPadDirectionButton: View {
    @EnvironmentObject var bt: BluetoothManager
    let direction: DPadDirection

    var body: some View {
        Button {
            // Optional tap behavior
        } label: {
            Image(systemName: direction.systemImageName)
                .font(.system(size: 26, weight: .bold))
                .frame(width: 60, height: 60)
                .background(
                    Circle()
                        .fill(Color(.systemGray5))
                )
                .overlay(
                    Circle()
                        .stroke(Color(.systemGray3), lineWidth: 1)
                )
        }
        .buttonStyle(
            PressAndHoldButtonStyle { isPressed in
                guard bt.isConnected else { return }

                if isPressed {
                    bt.sendMotorCommand(direction.commandChar)
                } else if direction != .stop {
                    bt.sendMotorCommand(DPadDirection.stop.commandChar)
                }
            }
        )
        .disabled(!bt.isConnected)
        .opacity(bt.isConnected ? 1.0 : 0.4)
    }
}

// MARK: - D-pad layout

struct DPadView: View {
    var body: some View {
        VStack(spacing: 12) {
            HStack {
                Spacer()
                DPadDirectionButton(direction: .up)
                Spacer()
            }

            HStack(spacing: 16) {
                DPadDirectionButton(direction: .left)
                DPadDirectionButton(direction: .stop)
                DPadDirectionButton(direction: .right)
            }

            HStack {
                Spacer()
                DPadDirectionButton(direction: .down)
                Spacer()
            }
        }
        .padding(16)
        .background(
            RoundedRectangle(cornerRadius: 20)
                .fill(Color(.systemGray6))
        )
        .overlay(
            RoundedRectangle(cornerRadius: 20)
                .stroke(Color(.systemGray3), lineWidth: 1)
        )
    }
}

// MARK: - 2D Servo pad (drag dot in a box)

struct ServoPadView: View {
    @EnvironmentObject var bt: BluetoothManager

    @Binding var panAngle: Double   // 0...180
    @Binding var tiltAngle: Double  // 0...180

    @State private var handlePosition: CGPoint = .zero
    @State private var initialized = false

    var body: some View {
        GeometryReader { geo in
            let width = geo.size.width
            let height = geo.size.height

            ZStack {
                RoundedRectangle(cornerRadius: 12)
                    .fill(Color(.systemGray6))
                    .overlay(
                        RoundedRectangle(cornerRadius: 12)
                            .stroke(Color(.systemGray3), lineWidth: 1)
                    )

                Path { path in
                    path.move(to: CGPoint(x: width / 2, y: 0))
                    path.addLine(to: CGPoint(x: width / 2, y: height))
                    path.move(to: CGPoint(x: 0, y: height / 2))
                    path.addLine(to: CGPoint(x: width, y: height / 2))
                }
                .stroke(Color(.systemGray4),
                        style: StrokeStyle(lineWidth: 1, dash: [4, 4]))

                Circle()
                    .frame(width: 24, height: 24)
                    .foregroundStyle(.blue)
                    .shadow(radius: 3)
                    .position(
                        x: clamp(handlePosition.x, min: 0, max: width),
                        y: clamp(handlePosition.y, min: 0, max: height)
                    )
            }
            .contentShape(Rectangle())
            .gesture(
                DragGesture(minimumDistance: 0)
                    .onChanged { value in
                        let loc = CGPoint(
                            x: clamp(value.location.x, min: 0, max: width),
                            y: clamp(value.location.y, min: 0, max: height)
                        )

                        handlePosition = loc

                        let normalizedX = max(0, min(1, loc.x / width))
                        let newPan = normalizedX * 180.0

                        let normalizedY = max(0, min(1, loc.y / height))
                        let newTilt = (1.0 - normalizedY) * 180.0

                        panAngle = newPan
                        tiltAngle = newTilt

                        if bt.isConnected {
                            bt.sendPan(angle: Int(newPan))
                            bt.sendTilt(angle: Int(newTilt))
                        }
                    }
                    .onEnded { _ in }
            )
            .onAppear {
                guard !initialized else { return }
                initialized = true

                let initialX = width / 2
                let initialY = height / 2
                handlePosition = CGPoint(x: initialX, y: initialY)

                panAngle = 90
                tiltAngle = 90

                if bt.isConnected {
                    bt.sendPan(angle: 90)
                    bt.sendTilt(angle: 90)
                }
            }
        }
    }

    private func clamp<T: Comparable>(_ value: T, min: T, max: T) -> T {
        if value < min { return min }
        if value > max { return max }
        return value
    }
}

// MARK: - Mode + Mic controls

struct ModeControlsView: View {
    @EnvironmentObject var bt: BluetoothManager
    @Binding var selectedMode: RobotMode?
    @Binding var micEnabled: Bool

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Mode")
                .font(.title3)

            HStack(spacing: 8) {
                ForEach(RobotMode.allCases, id: \.self) { mode in
                    Button {
                        guard bt.isConnected else { return }
                        bt.sendMotorCommand(mode.bleCommand)
                        selectedMode = mode
                    } label: {
                        Text(mode.title)
                            .font(.subheadline.weight(.semibold))
                            .padding(.vertical, 8)
                            .padding(.horizontal, 12)
                            .frame(maxWidth: .infinity)
                            .background(
                                Capsule()
                                    .fill(selectedMode == mode
                                          ? Color.accentColor
                                          : Color(.systemGray5))
                            )
                            .foregroundColor(selectedMode == mode ? .white : .primary)
                    }
                    .disabled(!bt.isConnected)
                }
            }

            HStack(spacing: 8) {
                Button {
                    guard bt.isConnected else { return }
                    bt.sendMotorCommand("M")  // cycle modes on robot
                } label: {
                    Label("Cycle", systemImage: "arrow.2.circlepath")
                        .font(.subheadline.weight(.semibold))
                        .padding(.vertical, 8)
                        .padding(.horizontal, 12)
                        .frame(maxWidth: .infinity)
                        .background(
                            Capsule()
                                .fill(Color(.systemGray5))
                        )
                }
                .disabled(!bt.isConnected)

                Button {
                    guard bt.isConnected else { return }
                    if micEnabled {
                        bt.sendMotorCommand("D")
                        micEnabled = false
                    } else {
                        bt.sendMotorCommand("E")
                        micEnabled = true
                    }
                } label: {
                    Label(micEnabled ? "Mic On" : "Mic Off",
                          systemImage: micEnabled ? "mic.fill" : "mic.slash")
                        .font(.subheadline.weight(.semibold))
                        .padding(.vertical, 8)
                        .padding(.horizontal, 12)
                        .frame(maxWidth: .infinity)
                        .background(
                            Capsule()
                                .fill(micEnabled ? Color.green.opacity(0.2)
                                                 : Color(.systemGray5))
                        )
                }
                .disabled(!bt.isConnected)
            }
        }
    }
}
