//
//  finalProject4750App.swift
//  finalProject4750
//
//  Created by Junwoo Kwon on 11/27/25.
//

import SwiftUI

@main
struct TimmyApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
