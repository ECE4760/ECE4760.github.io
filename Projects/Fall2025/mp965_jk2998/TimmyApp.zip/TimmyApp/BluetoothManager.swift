import CoreBluetooth
import Combine

class BluetoothManager: NSObject, ObservableObject {
    @Published var isConnected = false

    private var central: CBCentralManager!
    private var robotPeripheral: CBPeripheral?
    private var commandChar: CBCharacteristic?


    private let serviceUUID = CBUUID(string: "F0EFCDAB-8967-4523-1234-785634127812")
    private let charUUID    = CBUUID(string: "F1EFCDAB-8967-4523-1234-785634127812")

    override init() {
        super.init()

        central = CBCentralManager(delegate: self, queue: .main)
    }

    deinit {

    }

    // ------ Generic send ------
    private func send(_ string: String) {
 
        guard let peripheral = robotPeripheral else {

            return
        }
        guard let characteristic = commandChar else {

            return
        }

        guard let data = string.data(using: .utf8) else {

            return
        }
        peripheral.writeValue(data, for: characteristic, type: .withoutResponse)

    }

    // MARK: - Public API

    func sendMotorCommand(_ c: Character) {
        send(String(c))
    }

    func sendPan(angle: Int) {
        let clamped = max(0, min(180, angle))
        send(String(format: "P%03d", clamped))
    }

    func sendTilt(angle: Int) {
        let clamped = max(0, min(180, angle))
        send(String(format: "T%03d", clamped))
    }
}

extension BluetoothManager: CBCentralManagerDelegate {
    func centralManagerDidUpdateState(_ central: CBCentralManager) {


        switch central.state {
        case .poweredOn:

            // Scan for ALL devices; we’ll filter by name
            central.scanForPeripherals(withServices: nil, options: nil)

        case .unauthorized:

        case .poweredOff:

        case .resetting:

        case .unsupported:

        case .unknown:
 
        @unknown default:
            print("Unknown state")
        }
    }

    func centralManager(_ central: CBCentralManager,
                        didDiscover peripheral: CBPeripheral,
                        advertisementData: [String : Any],
                        rssi RSSI: NSNumber) {

        let advName = advertisementData[CBAdvertisementDataLocalNameKey] as? String
        let name = peripheral.name ?? advName ?? "Unknown"


        // print("    advData: \(advertisementData)")

        // Match on advertised name
        if name == "PicoRobot" {
            print("Found PicoRobot — connecting")
            robotPeripheral = peripheral
            robotPeripheral?.delegate = self
            central.stopScan()
            central.connect(peripheral, options: nil)
        }
    }

    func centralManager(_ central: CBCentralManager,
                        didConnect peripheral: CBPeripheral) {


        isConnected = true
        peripheral.discoverServices(nil)
    }

    func centralManager(_ central: CBCentralManager,
                        didFailToConnect peripheral: CBPeripheral,
                        error: Error?) {

    }

    func centralManager(_ central: CBCentralManager,
                        didDisconnectPeripheral peripheral: CBPeripheral,
                        error: Error?) {

        isConnected = false
        central.scanForPeripherals(withServices: nil, options: nil)
    }
}

extension BluetoothManager: CBPeripheralDelegate {
    func peripheral(_ peripheral: CBPeripheral,
                    didDiscoverServices error: Error?) {

        if let err = error {

            return
        }
        guard let services = peripheral.services else {

            return
        }

        for service in services {

            if service.uuid == serviceUUID {

                peripheral.discoverCharacteristics(nil, for: service)
            }
        }
    }

    func peripheral(_ peripheral: CBPeripheral,
                    didDiscoverCharacteristicsFor service: CBService,
                    error: Error?) {

        if let err = error {
            return
        }
        guard let chars = service.characteristics else {

            return
        }

        for char in chars {

            if char.uuid == charUUID {
                print(" Command characteristic ready")
                commandChar = char
            }
        }
    }
}
