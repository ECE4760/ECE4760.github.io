import SwiftUI

struct ContentView: View {
    @StateObject private var bt = BluetoothManager()

    var body: some View {
        TabView {
            ControlView()
                .environmentObject(bt)
                .tabItem {
                    Label("Control", systemImage: "gamecontroller")
                }

            ProgrammingModeView()
                .environmentObject(bt)
                .tabItem {
                    Label("Programming", systemImage: "list.bullet.rectangle")
                }
        }
    }
}

#Preview {
    ContentView()
}
