//
//  ControlView.swift
//  TimmyApp
//
//  Created by Junwoo Kwon on 12/11/25.
//


import SwiftUI

struct ControlView: View {
    @EnvironmentObject var bt: BluetoothManager

    @State private var panAngle: Double = 90
    @State private var tiltAngle: Double = 90

    @State private var selectedMode: RobotMode? = nil
    @State private var micEnabled: Bool = false

    var body: some View {
        VStack(spacing: 20) {
            Spacer()

            // Status bar
            HStack(spacing: 10) {
                Circle()
                    .fill(bt.isConnected ? Color.green : Color.red)
                    .frame(width: 10, height: 10)

                Text(bt.isConnected ? "Connected to PicoRobot"
                                    : "Searching for PicoRobot…")
                    .font(.subheadline.weight(.medium))

                Spacer()
            }
            .padding(10)
            .background(
                RoundedRectangle(cornerRadius: 12)
                    .fill(Color(.systemGray6))
            )

            // Mode controls
            ModeControlsView(selectedMode: $selectedMode,
                             micEnabled: $micEnabled)
                .environmentObject(bt)

            Divider()
                .padding(.vertical, 1)

            // Movement controls (D-pad)
            VStack(spacing: 8) {
                Text("Movement")
                    .font(.title3)

                DPadView()
                    .environmentObject(bt)
            }

            Divider()
                .padding(.vertical, 1)

            // Servo controls with 2D pad
            VStack(alignment: .leading, spacing: 8) {
                Text("Servos")
                    .font(.title3)

                Text("Pan: \(Int(panAngle))°, Tilt: \(Int(tiltAngle))°")
                    .font(.subheadline)
                    .foregroundColor(.secondary)

                ServoPadView(panAngle: $panAngle, tiltAngle: $tiltAngle)
                    .environmentObject(bt)
                    .frame(height: 150)
            }

            Spacer()
        }
        .padding()
    }
}
