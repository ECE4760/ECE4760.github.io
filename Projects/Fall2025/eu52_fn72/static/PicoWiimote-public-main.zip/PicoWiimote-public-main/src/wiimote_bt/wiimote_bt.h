#ifndef WIIMOTE_BT_H
#define WIIMOTE_BT_H

#ifdef __cplusplus
extern "C" {
#endif

void bluetooth_init(void); 
void bluetooth_rumble(bool rumble); 

#ifdef __cplusplus
}
#endif

#endif
