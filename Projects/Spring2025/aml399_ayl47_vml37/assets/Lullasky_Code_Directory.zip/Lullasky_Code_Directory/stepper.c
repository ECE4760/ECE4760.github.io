#include "motor_library.h"
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>

#include "pico/stdlib.h"
#include "pico/multicore.h"
#include "hardware/spi.h"
#include "hardware/sync.h"
#include "hardware/pio.h"
#include "hardware/dma.h"
#include "hardware/irq.h"
#include "hardware/clocks.h"
#include "pt_cornell_rp2040_v1_3.h"
#include "ws2812.pio.h"
#include "hardware/gpio.h"
#include "pico/time.h"
#include "pico/types.h"

// motor pin
#define MOTOR1_IN1 2

// button pins
#define BUTT 16
#define SONG_BUTT  17
#define D_BUTT  14

// onboard LED
#define LED_PIN 25

// Neopixels
#define NUM_LEDS 50
#define PIN_TX 6

// SPI pins
#define PIN_MISO 4
#define PIN_CS   9
#define PIN_SCK  10
#define PIN_MOSI 11
#define SPI_PORT spi1

// audio pins
#define LDAC     12

// Alarm IRQ definitions
#define ISR_GPIO 21
#define LED      25
#define ALARM_NUM 0 
#define ALARM_IRQ TIMER_IRQ_0
#define Fs 50000
#define DELAY 20
#define two32 4294967296.0
#define sine_table_size 256

// Fixed Point Functions
typedef signed int fix15;
#define multfix15(a,b) ((fix15)((((signed long long)(a)) * ((signed long long)(b))) >> 15))
#define float2fix15(a) ((fix15)((a) * 32768.0))
#define fix2int15(a) ((int)(a >> 15))
#define int2fix15(a) ((fix15)(a << 15))
#define divfix(a,b) ((fix15)((((signed long long)(a)) << 15) / (b)))

// DDS Variable Definitions
fix15 sin_table[sine_table_size];
volatile unsigned int phase_accum_main_0;
fix15 current_amplitude_0 = 0, attack_inc, decay_inc, max_amplitude = int2fix15(1);
int DAC_output_0;
uint16_t DAC_data_0;
volatile unsigned int STATE_0 = 0, count_0 = 0;
volatile int twinkle_counter = 0;
volatile int twinkle_sect = 0;

// Ramping definitions
#define ATTACK_TIME 250
#define DECAY_TIME 250
#define BEEP_DURATION 30000
#define BEEP_REPEAT_INTERVAL 50000

// color definitions
uint8_t base_color[3] = {255, 160, 200}; // pastel pink
uint8_t colors[7][3] = {
    {0xFF, 0x44, 0x44}, 
    {0xFF, 0x88, 0x33}, 
    {0xFF, 0xE6, 0x3C},
    {0x66, 0xE6, 0x4D}, 
    {0x33, 0xB5, 0xFF}, 
    {0x66, 0x33, 0xCC}, 
    {0xB3, 0x33, 0xFF}
};

// Ultrasonic Sensor Pin Definitions
uint TRIGGER_PIN = 19;
uint ECHO_PIN = 18;
#define ECHO_TIMEOUT_US 30000  // 30ms timeout for echo response
#define PULSE_TIMEOUT_US 30000 // 30ms timeout for pulse duration

// distance function for ultrasonic sensor
float measure_distance(void) {
    // Make sure trigger is low and settles
    gpio_put(TRIGGER_PIN, 0);
    sleep_ms(2); 
    
    // Send 10 ustrigger pulse
    gpio_put(TRIGGER_PIN, 1);
    sleep_us(10);  
    gpio_put(TRIGGER_PIN, 0);
    
    // Get current time
    absolute_time_t timeout_start = get_absolute_time();
    
    // Wait for echo pin to go high
    while (gpio_get(ECHO_PIN) == 0) {
        // If timed out (can't find echo)
        if (absolute_time_diff_us(timeout_start, get_absolute_time()) > ECHO_TIMEOUT_US) {
            printf("Timeout waiting for echo pin to go HIGH\n");
            return -1.0;  
        }
    }
    
    // Record the start time of echo 
    absolute_time_t echo_start = get_absolute_time();
    
    // Wait for echo pin to go low
    while (gpio_get(ECHO_PIN) == 1) {
        // If echo never goes low
        if (absolute_time_diff_us(echo_start, get_absolute_time()) > PULSE_TIMEOUT_US) {
            printf("Timeout waiting for echo pin to go LOW\n");
            return -1.0;  
        }
    }
    
    // Calculate duration of echo
    int64_t pulse_duration = absolute_time_diff_us(echo_start, get_absolute_time());
    
    // Calculate distance (distance = speed of sound * pulse duration)
    float distance_cm = (float)pulse_duration / 58.0;
    
    return distance_cm;
}


// Send color to pio machine controlling neopixel strip
static inline void put_pixel(uint32_t pixel_grb) {
    pio_sm_put_blocking(pio1, 0, pixel_grb << 8u);
}
// Create 32-bit GRB value for neopixel strip
static inline uint32_t urgb_u32(uint8_t r, uint8_t g, uint8_t b) {
    return ((uint32_t)(g) << 16) | ((uint32_t)(r) << 8) | (uint32_t)(b);
}

// Synthesizer initializations
int STATE = 0, song_state = 0, counter = 0, butt_pressed = 0, curr_param, prev_param, s_curr, s_prev;
volatile int music = 0; // 0 = music off, 1 = brahm's lullaby, 2 = twinkle, 3 = baby shark
int note_count = 0; 
float low_pass = 0;

float prev_distance, distance;
int motor_dir = 1;
static PT_THREAD(protothread_button(struct pt *pt)) {
    PT_BEGIN(pt);
    while (1) {
        distance = measure_distance();
        low_pass = low_pass + (((int)distance - (int)low_pass) >> 4);
        if ((low_pass < 60)&&(low_pass > 0)) {
            music = 1;
            note_count = 0;
            count_0 = 0;
            current_amplitude_0 = 0;
            phase_accum_main_0 = 0;
            
            if (music != 0) {
                timer_hw->alarm[ALARM_NUM] = timer_hw->timerawl + DELAY;
            }
        }

        curr_param = gpio_get(BUTT);
        s_curr = !gpio_get(SONG_BUTT);

        // Motor Button FSM
        if (STATE == 0){ 
            if (curr_param == 0){
                STATE = 0;
            }
            else{
                STATE = 1;
                prev_param = curr_param;
            }
        }
        // Button maybe pressed state
        else if (STATE == 1){
            // Transition to button pressed state
            if (curr_param == prev_param){
                STATE = 2;
                // Take Action, toggle button_state
                butt_pressed = !butt_pressed;
                
                if (butt_pressed == 1) {
                    motor_dir += 1;
                    motor_dir = (motor_dir == 3) ? 1 : motor_dir;
                    SET_SPEED_MOTOR_1(125000) ;
                    SET_DIRECTION_MOTOR_1(motor_dir);
                }
                else{
                    SET_SPEED_MOTOR_1(0) ;  
                } 
                
            }
            else{
                STATE = 0;
            }
        }
        // Button pressed state
        else if (STATE == 2){
            // If still same value, stay in button pressed
            if (curr_param == prev_param){
                STATE = 2;
            }
            // Transition to button maybe not pressed
            else{
                STATE = 3;
            }
        }
        // Button maybe not pressed
        else if (STATE == 3){
            // If same as possible, go back to button pressed state
            if (curr_param == prev_param){
                STATE = 2;
            }
            // Transition to button not pressed state
            else{
                STATE = 0;
            }
        }
        else{
            STATE = STATE;
        }

        // Music Button FSM
        if (song_state == 0) { // not pressed
            song_state = (s_curr == 1) ? 1 : 0;
            if (song_state == 1) s_prev = s_curr;
        } 
        else if (song_state == 1) { // maybe pressed
            if (s_curr == s_prev) {
                song_state = 2;
            } else song_state = 0;
        } 
        else if (song_state == 2) { // maybe not pressed
            song_state = (s_curr == s_prev) ? 2 : 3;
            if (song_state == 3) {
                music += 1;
                music = (music == 4) ? 0 : music;
                note_count = 0;
                twinkle_counter = 0;
                twinkle_sect = 0;
                count_0 = 0;
                if (music != 0) {
                    timer_hw->alarm[ALARM_NUM] = timer_hw->timerawl + DELAY;
                }
            }
        } 
        else if (song_state == 3) { // pressed
            song_state = (s_curr == s_prev) ? 2 : 0;
        }
        PT_YIELD_usec(3000);
    }
    PT_END(pt);
}

int twinkle_led = 0;
static int chase_index = 0;
int water_offset = 0;

static PT_THREAD(protothread_led(struct pt *pt)) {
    PT_BEGIN(pt);

    while (true) {
        uint8_t r = (uint8_t)(base_color[0]);
        uint8_t g = (uint8_t)(base_color[1]);
        uint8_t b = (uint8_t)(base_color[2]);
        if ((music == 2) && (twinkle_led == 1)) { // Twinkle Twinkle (random glitter effect)
            twinkle_led = 0;
                for (int i = 0; i < NUM_LEDS; i++) {
                    float brightness_scale = 0.5f + (rand() % 51) / 100.0f; // 0.5 to 1.0, adjusts light intensity
                    if (rand() % 100 < 15) {  // 15% chance pixel turns on
                        // pastel twinkling lights
                        int sparkle_color_index = rand() % 7; // pick a random color from presets
                        uint8_t r_twinkle = (uint8_t)(colors[sparkle_color_index][0] * brightness_scale);
                        uint8_t g_twinkle = (uint8_t)(colors[sparkle_color_index][1] * brightness_scale);
                        uint8_t b_twinkle = (uint8_t)(colors[sparkle_color_index][2] * brightness_scale);

                        put_pixel(urgb_u32(r_twinkle, g_twinkle, b_twinkle));
                    } else {
                        put_pixel(urgb_u32(0, 0, 0)); // if pixel not chosen turn off light
                    }
                }
        } 
        else if (music == 1) {
            for (int i = 0; i < NUM_LEDS; i++) {
                put_pixel(urgb_u32(r, g, b)); // Brahm's State ==> LEDs switching colors with music note
            }
        }
        else if (music == 0) { 
            for (int i = 0; i < NUM_LEDS; i++) {
                put_pixel(urgb_u32(0xFF,0xFF,0xFF)); // Off state ==> all LEDs are off
            }
        }
        else if ((music == 3) && (twinkle_led == 1)) { 
            twinkle_led = 0;
            // water effect 2
            for (int i = 0; i < NUM_LEDS; i++) {
                int intensity = (i + water_offset) % NUM_LEDS;
                uint8_t blue_level = 20 + (205 * intensity) / NUM_LEDS;
                put_pixel(urgb_u32(0, 0, blue_level));
            }
            water_offset = (water_offset + 40) % NUM_LEDS; // slowly move down
        }


        sleep_ms(20);
        PT_YIELD_usec(1000);
    }

    PT_END(pt);
}


void core1_entry() {
    pt_add_thread(protothread_button);
    pt_add_thread(protothread_led);
    pt_schedule_start;
}

// brahms lullaby
float notes_duration[] = {30000, 15000, 15000, 45000, 15000, 30000, 30000, 30000, 15000, 15000, 30000, 45000, 15000, 30000, 30000, 
                          15000, 15000, 60000, 15000, 15000, 60000, 15000, 15000, 15000, 15000, 30000, 30000, 60000 }; // quarter, eighth, dotted quarter note length

float note_frequencies[] = {0, 196.0, 196.0, 233.1, 196.0, 196.0, 233.1, 0, 196.0, 233.1, 311.1, 293.7, 261.6, 261.6, 233.1, 
                            174.6, 196.0, 207.7, 174.6, 196.0, 207.7, 174.6, 207.7, 293.7, 261.6, 233.1, 293.7, 311.1}; //G, Bb, Eb, D, C
       
// twinkle twinkle little star
float twinkle_duration[] = {30000, 30000, 30000, 30000, 30000, 30000, 60000 }; // quarter, eighth, dotted quarter note length

float twinkle_frequencies[4][7] = {
                    {261.626, 261.626, 391.995, 391.995, 440.0, 440.0, 391.995},
                    {349.228, 349.228, 329.628, 329.628, 293.665, 293.665, 261.626},
                    {391.995, 391.995, 349.228, 349.228, 329.628, 329.628, 293.665}, 
                    {391.995, 391.995, 349.228, 349.228, 329.628, 329.628, 293.665}
                    };

float shark_duration[] = {30000, 30000, 30000, 15000, 15000, 15000, 7500, 15000, 7500, 15000,
                          15000, 15000, 15000, 15000, 15000, 7500, 15000, 7500, 15000, 
                          15000, 15000, 15000, 15000, 15000, 7500, 15000, 7500, 15000, 
                          15000, 15000, 30000};
                        
float shark_frequencies[] = {0, 391.995, 440.0, 523.251, 523.251, 523.251, 523.251, 523.251, 523.251, 523.251,
                             391.995, 440.0, 523.251, 523.251, 523.251, 523.251, 523.251, 523.251, 523.251,
                             391.995, 440.0, 523.251, 523.251, 523.251, 523.251, 523.251, 523.251, 523.251,
                             523.251, 523.251, 493.883}; // G = 391.995, A = 440, C = 523.251, B = 493.883

int total_notes[] = {28, 43, 31};

// === Timer ISR for DAC Output ===
int note_done = 0;
int done_counter;

static void alarm_irq(void){ 
    gpio_put(ISR_GPIO, 1);
    hw_clear_bits(&timer_hw->intr, 1u << ALARM_NUM);
    timer_hw->alarm[ALARM_NUM] = timer_hw->timerawl + DELAY;
    // Brahms
    if (music == 1){
        if (note_count != 7) {
            phase_accum_main_0 += (int)(note_frequencies[note_count] * two32 / Fs);
            DAC_output_0 = fix2int15(multfix15(current_amplitude_0, sin_table[phase_accum_main_0 >> 24])) + 2048;

            if (count_0 < ATTACK_TIME) current_amplitude_0 += attack_inc;
            else if (count_0 > notes_duration[note_count] - DECAY_TIME) current_amplitude_0 -= decay_inc;

            DAC_data_0 = (0b1011000000000000 | (DAC_output_0 & 0xffff));
            spi_write16_blocking(SPI_PORT, &DAC_data_0, 1);
            count_0++;
        } 
        else {
            count_0++;
        }

        if (count_0 == notes_duration[note_count]) {
            count_0 = 0;
            note_count += 1;
            note_done = 1;
            current_amplitude_0 = 0;
            phase_accum_main_0 = 0;
    
            // Choose a new pastel bas+e color of neopixel LED
            base_color[0] = colors[(note_count % 7)][0];
            base_color[1] = colors[(note_count % 7)][1];
            base_color[2] = colors[(note_count % 7)][2];
        }
    } 
    // Twinkle Twinkle
    else if (music == 2){
        if (note_count == 0) { // rest on transition
            phase_accum_main_0 += (int)(0);
            DAC_output_0 = fix2int15(multfix15(current_amplitude_0, sin_table[phase_accum_main_0 >> 24])) + 2048;
    
            if (count_0 < ATTACK_TIME) current_amplitude_0 += attack_inc;
            else if (count_0 > 30000 - DECAY_TIME) current_amplitude_0 -= decay_inc;
    
            DAC_data_0 = (0b1011000000000000 | (DAC_output_0 & 0xffff));
            spi_write16_blocking(SPI_PORT, &DAC_data_0, 1);
            count_0++;
            if (count_0 == 30000) {
                count_0 = 0;
                note_count++;
                note_done = 1;
                current_amplitude_0 = 0;
                phase_accum_main_0 = 0;
    
            }
        } 
        else {
            phase_accum_main_0 += (int)(twinkle_frequencies[twinkle_sect][twinkle_counter] * two32 / Fs);
            DAC_output_0 = fix2int15(multfix15(current_amplitude_0, sin_table[phase_accum_main_0 >> 24])) + 2048;
    
            if (count_0 < ATTACK_TIME) current_amplitude_0 += attack_inc;
            else if (count_0 > twinkle_duration[twinkle_counter] - DECAY_TIME) current_amplitude_0 -= decay_inc;
    
            DAC_data_0 = (0b1011000000000000 | (DAC_output_0 & 0xffff));
            spi_write16_blocking(SPI_PORT, &DAC_data_0, 1);
            count_0++;
    
            if (count_0 == twinkle_duration[twinkle_counter]) {
                count_0 = 0;
                note_count++;
                twinkle_counter++;
                note_done = 1;
                current_amplitude_0 = 0;
                phase_accum_main_0 = 0;
                twinkle_led = 1;
    
                if (twinkle_counter == 7){
                    twinkle_counter = 0;
                    twinkle_sect++;
                    twinkle_sect = (twinkle_sect == 4) ? 0: twinkle_sect;
                }
            }
        }

    }
    else if(music == 3){
        phase_accum_main_0 += (int)(shark_frequencies[note_count] * two32 / Fs);
        DAC_output_0 = fix2int15(multfix15(current_amplitude_0, sin_table[phase_accum_main_0 >> 24])) + 2048;

        if (count_0 < ATTACK_TIME) current_amplitude_0 += attack_inc;
        else if (count_0 > shark_duration[note_count] - DECAY_TIME) current_amplitude_0 -= decay_inc;

        DAC_data_0 = (0b1011000000000000 | (DAC_output_0 & 0xffff));
        spi_write16_blocking(SPI_PORT, &DAC_data_0, 1);
        count_0++;
        
        if (count_0 == shark_duration[note_count]) {
            count_0 = 0;
            note_count++;
            note_done = 1;
            current_amplitude_0 = 0;
            phase_accum_main_0 = 0;
            twinkle_led += 1;
        } 
    }

    if (note_done == 1){
        done_counter += 1;
        if (done_counter == 7500){
            note_done = 0;
            done_counter = 0;
        }
    }
    
    if (note_count == total_notes[music - 1]){
        note_count = 0;
        twinkle_sect = 0;
        twinkle_counter = 0;
    }
    
    gpio_put(ISR_GPIO, 0);
}

static PT_THREAD(protothread_core_0(struct pt *pt)) {
    PT_BEGIN(pt);
    while (1) {
        gpio_put(LED, !gpio_get(LED));
        PT_YIELD_usec(500000);
    }
    PT_END(pt);
}

int main() {
    stdio_init_all();

    // Setup PIO LEDs
    PIO pio = pio1;
    int sm = 0;
    uint offset = pio_add_program(pio, &ws2812_program);
    ws2812_program_init(pio, sm, offset, PIN_TX, 600000, false);
    gpio_init(LED_PIN); gpio_set_dir(LED_PIN, GPIO_OUT);

    // SPI setup
    spi_init(SPI_PORT, 20000000);
    spi_set_format(SPI_PORT, 16, 0, 0, 0);
    gpio_set_function(PIN_MISO, GPIO_FUNC_SPI);
    gpio_set_function(PIN_SCK, GPIO_FUNC_SPI);
    gpio_set_function(PIN_MOSI, GPIO_FUNC_SPI);
    gpio_set_function(PIN_CS, GPIO_FUNC_SPI);

    // setup DAC
    gpio_init(LDAC); 
    gpio_set_dir(LDAC, GPIO_OUT); 
    gpio_put(LDAC, 0);

    // setup GPIO to check alarm irq timing
    gpio_init(ISR_GPIO); 
    gpio_set_dir(ISR_GPIO, GPIO_OUT);

    // setup onboard LED
    gpio_init(LED); 
    gpio_set_dir(LED, GPIO_OUT); 
    gpio_put(LED, 0);

    // setup buttons
    gpio_init(BUTT); 
    gpio_set_dir(BUTT, GPIO_IN); 
    gpio_pull_up(BUTT);

    gpio_init(SONG_BUTT); 
    gpio_set_dir(SONG_BUTT, GPIO_IN); 
    gpio_pull_up(SONG_BUTT);

    gpio_init(D_BUTT); 
    gpio_set_dir(D_BUTT, GPIO_IN); 
    gpio_pull_up(D_BUTT); 

    // setup the trigger pin in putput mode and echo pin to input mode
    gpio_init( TRIGGER_PIN );
    gpio_init( ECHO_PIN );
    gpio_set_dir( TRIGGER_PIN, GPIO_OUT );
    gpio_set_dir( ECHO_PIN, GPIO_IN );

    attack_inc = divfix(max_amplitude, int2fix15(ATTACK_TIME));
    decay_inc = divfix(max_amplitude, int2fix15(DECAY_TIME));
    for (int i = 0; i < sine_table_size; i++)
        sin_table[i] = float2fix15(2047 * sin((float)i * 6.283 / sine_table_size));

    // Timer IRQ setup
    hw_set_bits(&timer_hw->inte, 1u << ALARM_NUM);
    irq_set_exclusive_handler(ALARM_IRQ, alarm_irq);
    irq_set_enabled(ALARM_IRQ, true);

    setupMotor1(MOTOR1_IN1);
    SET_SPEED_MOTOR_1(0);

    // Start both cores
    multicore_reset_core1();
    multicore_launch_core1(core1_entry);

    pt_add_thread(protothread_core_0);
    pt_schedule_start;
}
